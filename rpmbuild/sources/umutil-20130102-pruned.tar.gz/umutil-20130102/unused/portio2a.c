/* ******************************COPYRIGHT******************************
 * (c) CROWN COPYRIGHT 1995, METEOROLOGICAL OFFICE, All Rights Reserved.
 *
 * Use, duplication or disclosure of this code is subject to the
 * restrictions as set forth in the contract.
 * 
 *                Meteorological Office
 *                London Road
 *                BRACKNELL
 *                Berkshire UK
 *                RG12 2SZ
 * 
 * If no contract has been raised with this copy of the code, the use,
 * duplication or disclosure of it is strictly prohibited. Permission
 * to do so must first be obtained in writing from the Head of 
 * Numerical Modelling at the above address.
 * ******************************COPYRIGHT******************************
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <errno.h>


#include <time.h>

     /* C language routines for portable version of UM */
     /*       Written by A.Dickinson 1/11/91           */
     /* Model    Modification history from version 3.0  */
     /* version  Date                                   */
     /* 3.1      15/01/93 Increase size of available    */
     /*          unit nos. from 1-100 to 1-199.         */
     /*          R.Rawlins                              */
     /*                                                 */
     /*          A range of C - Fortran interfaces      */
     /*          provided via *DEFS C_LOW & C_LOW_U.    */
     /*          See UM Doc Paper S5.                   */
     /*                                                 */
     /*          A.Dickinson 24/06/93                   */
     /*                                                 */
     /* 3.3      Error in dimension of array fno in     */
     /*          routine get_file corrected. Change type*/
     /*          in date_time to remove compilation     */
     /*          warnings. A.Dickinson 06/11/93         */
     /* 3.3       07/09/93 Set buffer in OPEN. R.Rawlins */
     /* 3.3      04/10/93 New routine FLUSH_BUFFER to   */
     /*          force buffer write. R. Rawlins         */
     /* 3.3       09/08/94 Include test in CLOSE to check*/
     /*           unit flag and by-pass close if unit    */
     /*           already closed or not yet opened.      */
     /*           Reset unit flag on normal close of     */
     /*           file. {close unit a then open unit b   */
     /*           then close unit a caused file pointer  */
     /*           for unit b to become unspecified.      */
     /*           R. Rawlins                             */
     /* 3.4      04/10/94 Improvement to code in getfile*/
     /*                   Tracey Smith                  */
  /* 3.5  23/03/95 Tidy up the interface between Fortran REALs */
  /*           and C float/double.                             */
  /*           Rename open and close to file_open + file_close */
  /*           T3D specific code for CHARACTER arguments       */
  /*           Change name of some routines for mpp code       */
  /*           Add routine FORT_GET_ENV to get environment     */
  /*           variables from Fortran                          */
  /*                Author : Paul Burton                       */
 /* 4.0 Error code argument added to setpos, close M.TURP */

   /*  Added perror call to BUFFIN and BUFFOUT */
   /*  Gordon Henderson */
  /* 4.1  11/04/96  FILE_OPEN: Check the return code from getenv    */
  /*                           and trap NULL                        */
  /*                FILE_CLOSE: Ditto                               */
  /*                GET_FILE: Checks getenv return code and if NULL */ 
  /*                          sets filename argument to blank       */
  /*                FORT_GET_ENV: Added code for T3D functionality  */
  /*      Paul Burton  */
  /*                                                           */
  /*           Make the necessary changes to use FFIO and      */
  /*           character variables correctly on all Cray       */
  /*           Platforms.                                      */
  /*                                                           */
  /*                Bob Carruthers, Cray Research U.K.         */
  /*                                                            */
  /* 4.4  17/06/97  Modify the write/print statements to use    */
  /*                a standard mechanism, set up via a #define  */
  /*                statement                                   */
  /*                  Author: Bob Carruthers, Cray Research     */
  /*                                                            */
  /* 4.4  17/06/97  Add code to accept and use the current      */
  /*                Length for a dumpfile                       */
  /*                  Author: Bob Carruthers, Cray Research     */
  /*                                                            */


  /*           Changes to GET_FILE to allow unit numbers     */
  /*           greater > 100 to be used as enviroment        */
  /*           variables for filenames.     Ian Edmond       */
  /* 4.5  01/04/98  Assorted mods to the C code:                */
  /*                BUFFIN32: New routine added, and check that */
  /*                          unit is open added to BUFFO32     */
  /*                SETPOS32: New routines added for setting/   */
  /*                GETPOS32: reading file pointer for 32bit    */
  /*                          word files                        */
  /*                                                            */
  /*                Authors: Bob Carruthers & Paul Burton       */
  /*                                                            */

  /*                                                            */
  /* 4.5  31/03/98  Modify various definitions to make porting  */
  /*                to platforms that fully support 32 and 64   */
  /*                integers easier.                            */
  /*                  Author: Bob Carruthers, Cray Research     */
  /*                                                            */
  /* 4.5  16/07/98  Add properties flag word for each unit -    */
  /*                initial use is to broadcasts in buffin for  */
  /*                the AC scheme.                              */
  /*                  Author: Bob Carruthers, Cray Research     */
  /*                                                            */
  /*                                                            */
  /* 4.5  17/08/98  Code to ensure that we do not over-index    */
  /*                character arrays in Fortran or C            */
  /*                  Author: Bob Carruthers, Cray Research     */
  /* 5.0  26/07/99  Fix error in declaration of fname in        */
  /*                FILE_OPEN and FILE_CLOSE                    */
  /*                Author: Paul Selwood                        */
  /* 5.5  28/02/03  Add portable data conversion routines:      */
  /*                IEEE2IBM, IBM2IEEE, IEEE2IEG, IEG2IEEE      */
  /*                MOVEBITS and MOVEBYTES.                     */
  /*                These replace the Cray-specific routines    */
  /*                CRI2IBM, IBM2CRI, CRI2IEG, IEG2CRI, MOVBIT  */
  /*                and STRMOV respectively.                    */
  /*                (Author: S.Carroll)               P.Dando   */

typedef double real;
typedef long integer;

/* Fortran REAL is equivalent to C double */

/* Define the function that outputs the text string for         */
/* messages.  Note that the trailing newline character is       */
/* to be supplied by the print routine, and is no longer        */
/* in the string.  Similarly, leading new lines are now handled */
/* by the print routine - typically a newline is inserted for   */
/* each change of unit.                                         */

#define CALL_MESSAGE_PRINT(text) fprintf(stdout, "%s\n", text);        \
 fflush(stdout)

static char message[256];

#define MAX_UNITS 200

integer *the_unit;


FILE *pf[MAX_UNITS]=
                     {NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
                      NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
                      NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
                      NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
                      NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
                      NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
                      NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
                      NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
                      NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
                      NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
                      NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
                      NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
                      NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
                      NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
                      NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
                      NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
                      NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
                      NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
                      NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
                      NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL
                     };

static integer io_position[MAX_UNITS];
int open_flag[MAX_UNITS] =
                     {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
                      1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
                      1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
                      1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
                      1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
                      1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
                      1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
                      1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
                      1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
                      1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};

/* Unit properies table - one word per unit, one bit per
   property at present */

integer file_properties[MAX_UNITS] =
                     {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                      0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                      0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                      0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                      0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                      0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                      0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                      0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                      0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                      0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

/* Define the bits used in the properies table */

#define BCAST 1

extern void clear_unit_bcast_flag_();


/****************************************************************/
/* The following global constants are required by the portable  */
/* data conversion routines.  These constants provide masks for */
/* for selectively extracting the sign, exponent and mantissa   */
/* parts from IEEE and IBM 32 and 64 bit reals and integers.    */
/* The constants are expressed here in hex format.  The         */
/* corresponding binary representations are given by the usual  */
/* relationships:                                               */
/*    0=0000, 1=0001, 2=0010,....., 9=1001, A=1010,....F=1111   */
/****************************************************************/

/* Format 1: IBM 32 bit floating point numbers                  */
#define ibm_sign_32   0x80000000
#define ibm_expo_32   0x7F000000
#define ibm_mant_32   0x00FFFFFF
#define ibm_mant_bits_32 24
#define ibm_expo_bits_32 7
#define ibm_expo_bias_32 64

/* Format 2: IBM 64 bit floating point numbers                  */
#define ibm_sign_64   0x8000000000000000LL
#define ibm_expo_64   0x7F00000000000000LL
#define ibm_mant_64   0x00FFFFFFFFFFFFFFLL
#define ibm_mant_bits_64 56
#define ibm_expo_bits_64 7
#define ibm_expo_bias_64 64

/* Format 3: IEEE 32 bit floating point numbers                 */
#define ieee_sign_32  0x80000000
#define ieee_expo_32  0x7F800000
#define ieee_mant_32  0x007FFFFF
#define ieee_mant_bits_32 23
#define ieee_expo_bits_32 8
#define ieee_expo_bias_32 127

/* Format 4: IEEE 64 bit floating point numbers                 */
#define ieee_sign_64  0x8000000000000000LL
#define ieee_expo_64  0x7FF0000000000000LL
#define ieee_mant_64  0x000FFFFFFFFFFFFFLL
#define ieee_mant_bits_64 52
#define ieee_expo_bits_64 11
#define ieee_expo_bias_64 1023

/* Format 6: IEEE 16 bit integers (two's complement)            */
#define ieee_int_sign_16  0x8000
#define ieee_int_mant_16  0x7FFF
#define ieee_int_mant_bits_16 15

/* Format 7: IEEE 32 bit integers (two's complement)            */
#define ieee_int_sign_32  0x80000000
#define ieee_int_mant_32  0x7FFFFFFF
#define ieee_int_mant_bits_32 31

/* Format 8: IEEE 64 bit integers (two's complement)            */
#define ieee_int_sign_64  0x8000000000000000LL
#define ieee_int_mant_64  0x7FFFFFFFFFFFFFFFLL
#define ieee_int_mant_bits_64 63


void
buffin_single_
(unit, array, maxlen, length, status)
integer *unit;      /* Fortran unit                         */
real array[];       /* Array into which data is read        */
integer *maxlen;    /* Number of real numbers to be read    */
integer *length;    /* Number of real numbers actually read */
real *status;       /* Return code                          */
{
int k;
  the_unit=unit;

  if(open_flag[*unit]== 0){
    *length = fread(array,sizeof(real),*maxlen,pf[*unit]);

        *status=-1.0;
        k=feof(pf[*unit]);
    if(k != 0)
    {
      perror("\nBUFFIN: Read Failed");
      sprintf(message,
       "BUFFIN: C I/O Error - Return code = %d", k);
      CALL_MESSAGE_PRINT(message);
      *status=0.0;
    }
        k=ferror(pf[*unit]);
    if(k != 0)
    {
      perror("\nBUFFIN: Read Failed");
      sprintf(message,
       "BUFFIN: C I/O Error - Return code = %d", k);
      CALL_MESSAGE_PRINT(message);
      *status=1.0;
    }
   }
   else
        *status=3.0;

    io_position[*unit]=io_position[*unit]+*length;
}

void
buffout_single_
(unit, array, maxlen, length, status)
integer *unit;      /* Fortran unit                            */
real array[];       /* Array from which data is written        */
integer *maxlen;    /* Number of real numbers to be written    */
integer *length;    /* Number of real numbers actually written */
real *status;       /* Return code                             */
{
int k;
  the_unit=unit;

  if(open_flag[*unit]== 0){
    *length = fwrite(array,sizeof(real),*maxlen,pf[*unit]);

        *status=-1.0;
        k=feof(pf[*unit]);
    if(k != 0)
    {
      perror("\nBUFFOUT: Write Failed");
      sprintf(message,
       "BUFFOUT: C I/O Error - Return code = %d", k);
      CALL_MESSAGE_PRINT(message);
      *status=0.0;
    }
        k=ferror(pf[*unit]);
    if(k != 0)
    {
      perror("\nBUFFOUT: Write Failed");
      sprintf(message,
       "BUFFOUT: C I/O Error - Return code = %d", k);
      CALL_MESSAGE_PRINT(message);
      *status=1.0;
    }
   }
   else
        *status=3.0;

    io_position[*unit]=io_position[*unit]+*length;
}

void
setpos_single_
(unit, word_address,err)
integer *unit;      /* Fortran unit                         */
integer *word_address; /* Number of words into file            */
integer *err;          /* Error checking, err = 0 no errors, 
                                          err = 1 errors */
{
int k;
integer byte_address;
  the_unit=unit;

    byte_address=(*word_address)*sizeof(real);
    k = fseek(pf[*unit],byte_address,SEEK_SET);
    *err = 0;
    if(k!=0){
      perror("\nSETPOS: Seek Failed");
      sprintf(message,
       "SETPOS: Unit %d to Word Address %d Failed with Error Code %d",
       (int) *unit, (int) *word_address, k);
      CALL_MESSAGE_PRINT(message);
         *err = 1;
         abort();
    }
   io_position[*unit]=*word_address;

}

void
open_single_
(unit,file_name, char_len,intent,environ_var_flag,err)
char file_name[]; /* File name or environment variable    */
integer *unit;       /* Fortran unit                         */
integer *char_len;   /* No of chars in file name             */
integer *intent    ; /* =0 read only,!=0 read and write      */
integer *environ_var_flag; /* =0 file name in environment var, */
                     /*!=0 explicit file name            */
integer *err;        /* =0 file opened,                  */
                     /*!=0 file not opened               */
{
   char *fname;
   char *gname;
   int i;

   int readonly = 0;

   enum   filestat { old, new };
   enum   filestat filestatus;


   fname = calloc(*char_len + 1, 1);
   the_unit=unit;
   pf[*unit] = NULL;
/* convert file name to C format */

   strncpy( fname, file_name, *char_len );
   fname[ *char_len ] = '\0';
   sscanf( fname, "%s", fname );


   if ( *environ_var_flag == 0 )  /* File name held in environ var */
   {  gname = getenv( fname );
      if ( gname == NULL ) {
        sprintf(message,
         "OPEN:  WARNING: Environment variable %s not set",
         fname);
        CALL_MESSAGE_PRINT(message);
        open_flag[*unit]=1;
        *err=1;
        free (fname);
        return;
      }
   }
   else                           /* get file name from argmt fname */
      gname = fname;


   /* Check if file exists */

   if ( access( gname, 0 ) == 0 )  {   /* file exists */

      sprintf(message,
       "OPEN:  File %s to be Opened on Unit %d Exists",
       gname, (int) *unit );
      filestatus = old;
   }
   else  {   /* non-existent file */

      sprintf(message,
       "OPEN:  File %s to be Opened on Unit %d does not Exist",
       gname, (int) *unit);
      CALL_MESSAGE_PRINT(message);
      filestatus = new;
   }


   if ( filestatus == old )  {

      if ( *intent == readonly )  {

         if ( ( pf[*unit] = fopen( gname, "rb" ) ) == NULL )  {

            perror("OPEN:  File Open Failed");
            sprintf(message,
              "OPEN:  Unable to Open File %s for Reading", gname );
            CALL_MESSAGE_PRINT(message);
         }
      }
      else  {   /*  *intent == read_and_write )  */

         if ( ( pf[*unit] = fopen( gname, "r+b" ) ) == NULL )  {

            perror("OPEN:  File Open Failed");
            sprintf(message,
              "OPEN:  Unable to Open File %s for Read/Write", gname );
            CALL_MESSAGE_PRINT(message);
         }
      }
   }


/* New file - check for write */
   if ( filestatus == new )  {

/* Initialise the file control word to NULL */
      pf[*unit] = NULL;

      if ( *intent == readonly )  {
         sprintf(message, "OPEN:  **WARNING: FILE NOT FOUND" );
         CALL_MESSAGE_PRINT(message);
         sprintf(message,
          "OPEN:  Ignored Request to Open File %s for Reading",
           gname );
         CALL_MESSAGE_PRINT(message);
      }
      else  {        /*  *intent == read_and_write   */

/* File size not given - just open the file normally */
          if ( ( pf[*unit] = fopen( gname, "w+b" ) ) == NULL )  {

            perror("OPEN:  File Creation Failed");
            sprintf(message,
             "OPEN:  Unable to Open File %s for Read/Write", gname );
            CALL_MESSAGE_PRINT(message);
          }
          else  {
            sprintf(message, "OPEN:  File %s Created on Unit %d",
                     gname, (int) *unit );
            CALL_MESSAGE_PRINT(message);
          }
      }
   }



   /* Set error code and open flag used by buffin and buffout */

   if( pf[*unit] == NULL )  {

      *err = 1;
      open_flag[*unit]=1;
   }
   else  {
      if ( setvbuf( pf[*unit], NULL, _IOFBF, BUFSIZ ) != 0 )  {
         perror("\n**Warning: setvbuf failed");
         *err=1;
         open_flag[*unit]=1;
       }
       else
       {
         *err = 0;
         open_flag[*unit]=0;

/*    set buffer to default size to force buffer alloc on heap */
  /*  setvbuf(pf[*unit],NULL,_IOFBF,BUFSIZ);  See above */
        }
   }
   io_position[*unit]=0;

   clear_unit_bcast_flag_(unit);

free (fname);
}



void
close_single_
(unit,file_name,char_len,environ_var_flag,delete,err)
char file_name[];    /* File name or environment variable    */
integer *unit;       /* Fortran unit                         */
integer *char_len;   /* No of chars in file name             */
integer *delete;     /* =0 do not delete file,!=0 delete file*/
integer *environ_var_flag; /* =0 file name in environment var, */
                           /*!=0 explicit file name            */
integer *err; /* ERROR CHECKING err = 0 no errors, err = 1 Errors */
{
char *fname;
char *gname;
int i;
int k;

the_unit=unit;
fname = calloc(*char_len + 1, 1);
/* first check to see if unit has been closed already (or not opened)*/
if(open_flag[*unit]== 0){    /* unit currently open  */

/* close file */
      k=fclose(pf[*unit]);

/* convert file name to C format */
        strncpy(fname,file_name,*char_len);
        fname[*char_len] = '\0';
        for (i=0; i<*char_len; i++){

            if (fname[i] == ' '){
               fname[i] = '\0';
               break;
            }
         }

        if(*environ_var_flag == 0)
          { gname = getenv( fname );
            if ( gname == NULL ) {
            open_flag[*unit]=1;
            *err=1;
            free( fname );
            return;
            }
          }
        else
          gname=fname;

      if(k==0){

/* delete file */
        if(*delete != 0){
          k=remove(gname);
          if( k != 0){
            *err = 1;
            abort();
          }
          else{  /*normal end to delete so:*/
            open_flag[*unit]=1;     /* set unit flag to closed */
            *err = 0;
          }

        }
        else{
/* file closed */
           open_flag[*unit]=1;     /* set unit flag to closed */
        }
      }
/* file not closed */
}   /* end of test for unit already closed */

else {
/* unit either closed already or not open yet */
  sprintf(message,
   "CLOSE: WARNING: Unit %d Not Opened", (int) *unit);
  CALL_MESSAGE_PRINT(message);
}

free( fname );
}


void
date_time_
(year,month,day,hour,minute,second)
integer *year;       /* year                  */
integer *month;      /* month   Current date  */
integer *day;        /* day      and time     */
integer *hour;       /* hour                  */
integer *minute;     /* minute                */
integer *second;     /* second                */

{
char s[5];
time_t t,*r,a;
    r=&a;
    t=time(r);
    strftime(s,5,"%Y",localtime(r));
    *year=atoi(s);
    strftime(s,5,"%m",localtime(r));
    *month=atoi(s);
    strftime(s,5,"%d",localtime(r));
    *day=atoi(s);
    strftime(s,5,"%H",localtime(r));
    *hour=atoi(s);
    strftime(s,5,"%M",localtime(r));
    *minute=atoi(s);
    strftime(s,5,"%S",localtime(r));
    *second=atoi(s);
}
void
shell_
(command,command_len)
char command  []; /* Command to be executed               */
integer *command_len; /* No of chars in command               */
{
char *fname;
int i;

/* convert file name to C format */

fname = calloc( *command_len + 1, 1);
strncpy(fname,command,*command_len);
fname[*command_len]='\0';

/* execute command */
        i=system(fname);

free( fname );
}

void
buffo32_
(unit, array, maxlen, length, status)
integer *unit;     /* Fortran unit                            */
real array[];      /* Array from which data is written        */
integer *maxlen;   /* Number of real numbers to be written    */
integer *length;   /* Number of real numbers actually written */
real *status;      /* Return code                             */
{
int k;


    if (open_flag[*unit]==0){
    *length = fwrite(array,4,*maxlen,pf [*unit]);

        *status=-1.0;
        k=feof(pf[*unit]);
    if(k != 0)
    {
      printf("C I/O Error: failed in BUFFO32\n");
      printf("Return code = %d\n",k);
      *status=0.0;
    }
        k=ferror(pf[*unit]);
    if(k != 0)
    {
      printf("C I/O Error: failed in BUFFO32\n");
      printf("Return code = %d\n",k);
      *status=1.0;
      }
    }
      else
        *status=3.0;

}

void
buffin32_
(unit, array, maxlen, length, status)
integer *unit;     /* Fortran unit                         */
real array[];      /* Array from which data is read        */
integer *maxlen;   /* Number of real numbers to be read    */
integer *length;   /* Number of real numbers actually read */
real *status;      /* Return code                          */
{
int k;

    if (open_flag[*unit]==0){

      *length = fread(array,4,*maxlen,pf [*unit]);

      *status=-1.0;
      k=feof(pf[*unit]);
      if(k != 0)
      {
        printf("C I/O Error: failed in BUFFIN32\n");
        printf("Return code = %d\n",k);
        *status=0.0;
      }
      k=ferror(pf[*unit]);
      if(k != 0)
      {
        printf("C I/O Error: failed in BUFFIN32\n");
        printf("Return code = %d\n",k);
        *status=1.0;
      }
    }
    else
      *status=3.0;
}

void
buffin8_
(unit, array, maxlen, length, status)
integer *unit;     /* Fortran unit                         */
char array[];      /* Array into which data is read        */
integer *maxlen;   /* Number of bytes to be read           */
integer *length;   /* Number of bytes actually read        */
real *status;      /* Return code                          */
{
int k;

  if(open_flag[*unit]== 0){
    *length = fread(array,1,*maxlen,pf[*unit]);

        *status=-1.0;
        k=feof(pf[*unit]);
    if(k != 0)
    {
      printf("C I/O Error: failed in BUFFIN8\n");
      printf("Return code = %d\n",k);
      *status=0.0;
    }
        k=ferror(pf[*unit]);
    if(k != 0)
    {
      printf("C I/O Error: failed in BUFFIN8\n");
      printf("Return code = %d\n",k);
      *status=1.0;
    }
   }
   else
        *status=3.0;

}

void
buffou8_
(unit, array, maxlen, length, status)
integer *unit;     /* Fortran unit                            */
char   array[];    /* Array from which data is written        */
integer *maxlen;   /* Number of bytes to be written           */
integer *length;   /* Number of bytes actually written        */
real *status;      /* Return code                             */
{
int k;

  if(open_flag[*unit]== 0){
    *length = fwrite(array,1,*maxlen,pf[*unit]);

        *status=-1.0;
        k=feof(pf[*unit]);
    if(k != 0)
    {
      printf("C I/O Error: failed in BUFFOU8\n");
      printf("Return code = %d\n",k);
      *status=0.0;
    }
        k=ferror(pf[*unit]);
    if(k != 0)
    {
      printf("C I/O Error: failed in BUFFOU8\n");
      printf("Return code = %d\n",k);
      *status=1.0;
    }
   }
   else
        *status=3.0;

}
void
setpos8_
(unit, byte_address)
integer *unit;     /* Fortran unit                         */
integer *byte_address; /* Number of bytes into file            */
{
int k;

    k = fseek(pf[*unit],*byte_address,SEEK_SET);
    if(k!=0){
         printf("ERROR detected in SETPOS\n");
         printf("word_address = %d\n", (int) *byte_address);
         printf("Return code from fseek = %d\n",k);
    }
}

void
getpos8_
(unit, byte_address)
integer *unit;     /* Fortran unit                         */
integer *byte_address; /* Number of bytes into file            */ 
{

    *byte_address = ftell(pf[*unit]);


}
void
setpos32_
(unit,word32_address,err)

integer *unit;            /* Fortran unit                         */
integer *word32_address;  /* Number of 32bit words into the file  */
integer *err;             /* 0: no error
                             1: error occured                     */

{
int k;
integer byte_address;

  *err=0;
  if (open_flag[*unit]==0) {
    byte_address=(*word32_address)*4;

    k=fseek(pf[*unit],byte_address,SEEK_SET);

    if (k != 0) {
      k=errno;
      perror("\nSETPOS32: Seek failed");
      sprintf(message,
        "SETPOS32: Unit %d to 32bit Word Address %d failed. Error: %d",
        (int) *unit, (int) *word32_address, k);
      the_unit=unit;
      CALL_MESSAGE_PRINT(message);
      *err=1;
      abort();
    }

  }
}

void
getpos32_
(unit,word32_address)

integer *unit;            /* Fortran unit                         */
integer *word32_address;  /* Number of 32bit words into the file  */

{
int byte_address;

  if (open_flag[*unit]==0) {
    byte_address=ftell(pf[*unit]);
    *word32_address = byte_address/4;
  }
}

void
getpos_
(unit, word_address)
integer *unit;     /* Fortran unit                         */
integer *word_address; /* Number of words into file            */
{
long byte_address;

   the_unit=unit;
     byte_address = ftell(pf[*unit]);
    *word_address = byte_address/sizeof(real);
      if(*word_address != io_position[*unit]) {
        sprintf(message,
         "GETPOS: IO_POSITION is %d, but FTELL gives %d",
         (int) io_position[*unit], (int) *word_address);
        the_unit=unit;
        CALL_MESSAGE_PRINT(message);
        abort();
      }

}

void
word_length_
(length)
integer *length;  /* Word length used by hardware         */
{

    *length=sizeof(real);

}
void
get_file_
(unit,filename,file_len,err)
char filename[]; /* File name                           */
integer *file_len; /* Dimension of filename               */
integer  *unit;    /* Fortran unit number                 */
integer  *err; /* Error checking err = 0 no errors, err = 1 errors */
{
char fname[16];
char fno[4];
char *gname;
int i;
int k;

the_unit=unit;
/* construct environment variable name         */
/* in form UNITnn, where nn is Fortran unit no */

       if ( *unit < 100){
       strcpy (fname, "UNIT");
       sprintf(fno,"%02i", (int) *unit);
       strcat(fname,fno);
       fname[6]='\0';
       }
       else{
       strcpy (fname, "UNIT");
       sprintf(fno,"%03i", (int) *unit);
       strcat(fname,fno);
       fname[7]='\0';
       }

/* get file name stored in environment variable UNITnn */
       gname=getenv(fname);
       if ( gname == NULL) {
         sprintf(message,
          "GET_FILE: Environment Variable %s not Set", fname);
         CALL_MESSAGE_PRINT(message);
         filename[0] = '\0';
         for (i=1; i<*file_len; i++){
                filename[i] = ' ';
         }
         return;               
       }
       k=strlen(gname);
       if(k >  *file_len){
         sprintf(message,
          "GET_FILE: File Name too long for Allocated Storage");
         CALL_MESSAGE_PRINT(message);
         sprintf(message,
          "GET_FILE: Environment Variable %s", fname);
         CALL_MESSAGE_PRINT(message);
         sprintf(message,
          "GET_FILE: File Name %s", gname);
         CALL_MESSAGE_PRINT(message);
         *err = 1;
         abort();
       }

/* convert file name to Fortran format */
          *err = 0;
          strncpy(filename,gname,k);
          for (i=k; i<*file_len; i++){
               filename[i] = ' ';
           }


}
void
abort_()
{
  abort();
}
     /*          Force i/o buffer to be written to file */
     /*          explicitly to prevent continuation run */
     /*          problems following 'hard' failures.    */
void
flush_buffer_
(unit, icode)
integer  *unit     ;  /* Fortran unit number             */
integer  *icode    ;  /* Integer return code             */
{
int  i         ;
  if(open_flag[*unit]== 0){
      i =   fflush(pf[*unit]);
      *icode = i;
  }
  else {
    if(pf[*unit] != NULL) {
      sprintf(message,
       "FLUSH_BUFFER: File Pointer for Unopened Unit %d is %16X",
       (int) *unit, (unsigned long) pf[*unit]);
      the_unit=unit;
      CALL_MESSAGE_PRINT(message);
      abort();
    }
  }
}
void
fort_get_env_
(env_var_name,ev_len,ev_contents,cont_len,ret_code)
char *env_var_name;  /* Name of environment variable   */
integer *ev_len;     /* length of name                 */
char *ev_contents;   /* contents of environment variable */
integer *cont_len;   /* length of contents              */
integer *ret_code;   /* return code: 0=OK  -1=problems  */

{
        integer minus_one=-1;

        char *c_env_var_name;

        char *value;
        int len,i;

        c_env_var_name = calloc(*ev_len + 1, 1);
        the_unit=&minus_one;
        strncpy(c_env_var_name,env_var_name,*ev_len);
        c_env_var_name[*ev_len]='\0';
        sscanf(c_env_var_name,"%s",c_env_var_name);

        value=getenv(c_env_var_name);
        if (value==NULL){
          *ret_code=-1;
          free( c_env_var_name );
          return;}
        else{
          *ret_code=0;}

        len=strlen(value);
        if (len > *cont_len){
         sprintf(message,
          "FORT_GET_ENV: Value too long for Allocated Storage");
         CALL_MESSAGE_PRINT(message);
         sprintf(message,
          "FORT_GET_ENV: Environment Variable %s",
          c_env_var_name);
         CALL_MESSAGE_PRINT(message);
         sprintf(message,
          "FORT_GET_ENV: Value %s", value);
         CALL_MESSAGE_PRINT(message);
                abort();
        }

        strncpy(ev_contents,value,len);
        for (i=len; i<*cont_len; i++){
                ev_contents[i]=' ';
        }
free( c_env_var_name );

}

void
CLOSE_ALL_FILES
()
{
}

void
FLUSH_ALL_FILES
()
{
}

/*                                                              */
/* Entry to accept the current File length prior                */
/* to an open request                                           */
/*                                                              */
void
set_dumpfile_length_
(unit, length)
integer *unit;
integer *length;
{
}
void
clear_unit_bcast_flag_
(unit)
integer *unit;
{
  integer minus_one=-1;

  file_properties[*unit]=(minus_one ^ BCAST) & file_properties[*unit];

}

void
set_unit_bcast_flag_
(unit)
integer *unit;
{

  file_properties[*unit]=BCAST | file_properties[*unit];

}


void
find_unit_bcast_flag_
(unit, flag)
integer *unit;
integer *flag; /* non-zero if set, otherwise 0 */
{

  *flag=BCAST & file_properties[*unit];

}



/****************************************************************/
/* The following function is to be called from Fortan.  It      */
/* provides a portable version of Cray routine CRI2IEG -        */
/* interface to read_number/write_number                        */
/****************************************************************/
void
ieee2ieg_
(type, num, ieg_num_out, offset_out, cri_num_in, stride,
    size_num_in, size_num_out)
integer *type, *num, *offset_out, *stride, *size_num_in, *size_num_out;
integer ieg_num_out[], cri_num_in[];
{
/* Prototype functions */
void read_number();
void write_number();
/* Local variables */
int i;
int type_num_in, type_num_out, offset;
/* Variables in calls to read/write_number */
integer sign, expo, mant, mant_bits_read;

/* Convert Cray offset to my offset */
 offset = 64 - (int) *offset_out - (int) *size_num_out;

/* Cray fortran uses IEEE data types */
/* Decide which data types are used */
if ((int) *type == 2){
  switch ((int) *size_num_in){               /* IEEE integer in */
    case 16:  type_num_in = 6;  break;
    case 32:  type_num_in = 7;  break;
    case 64:  type_num_in = 8;  break;
  }
  switch ((int) *size_num_out){              /* IEEE integer out */
    case 16:  type_num_out = 6;  break;
    case 32:  type_num_out = 7;  break;
    case 64:  type_num_out = 8;  break;
  }
}
else if ((int) *type == 3){
  switch ((int) *size_num_in){               /* real IEEE in */
    case 32:  type_num_in = 3;  break;
    case 64:  type_num_in = 4;  break;
  }
  switch ((int) *size_num_out){              /* real IEEE out */
    case 32:  type_num_out = 3;  break;
    case 64:  type_num_out = 4;  break;
  }
}
/*else*/ /* ERROR - unsupported type */

/* Loop over all values converting them as we go along */
for (i=0; i < *num; i++){
  read_number(type_num_in, (int) *size_num_in, 0, cri_num_in[i],
             &sign, &expo, &mant, &mant_bits_read);
  write_number(type_num_out, (int) *size_num_out, offset,
             &ieg_num_out[i], sign,  expo,  mant,  mant_bits_read);
}
}

/****************************************************************/
/* The following function is to be called from Fortan.  It      */
/* provides a portable version of Cray routine IEG2CRI -        */
/* interface to read_number/write_number                        */
/****************************************************************/
void
ieg2ieee_
(type, num, ieg_num_in, offset_in, cri_num_out, stride,
    size_num_out, size_num_in)
integer *type, *num, *offset_in,  *stride, *size_num_in, *size_num_out;
integer ieg_num_in[], cri_num_out[];
{
/* Prototype functions */
void read_number();
void write_number();
/* Local variables */
int i;
int type_num_in, type_num_out, offset;
/* Variables in calls to read/write_number */
integer sign, expo, mant, mant_bits_read;

/* Convert Cray offset to my offset */
 offset = 64 - (int) *offset_in - (int) *size_num_in;

/* Cray fortran uses IEEE data types */
/* Decide which data types are used */
if ((int) *type == 2){
  switch ((int) *size_num_in){               /* IEEE integer in */
    case 16:  type_num_in = 6;  break;
    case 32:  type_num_in = 7;  break;
    case 64:  type_num_in = 8;  break;
  }
  switch ((int) *size_num_out){              /* IEEE integer out */
    case 16:  type_num_out = 6;  break;
    case 32:  type_num_out = 7;  break;
    case 64:  type_num_out = 8;  break;
  }
}
else if ((int) *type == 3){
  switch ((int) *size_num_in){               /* real IEEE in */
    case 32:  type_num_in = 3;  break;
    case 64:  type_num_in = 4;  break;
  }
  switch ((int) *size_num_out){              /* real IEEE out */
    case 32:  type_num_out = 3;  break;
    case 64:  type_num_out = 4;  break;
  }
}
/*else*/ /* ERROR - unsupported type */

/* Loop over all values converting them as we go along */
for (i=0; i<*num; i++){
  read_number(type_num_in, (int) *size_num_in, offset, ieg_num_in[i],
                     &sign, &expo, &mant, &mant_bits_read);
  write_number(type_num_out, (int) *size_num_out, 0, &cri_num_out[i],
                      sign,  expo,  mant,  mant_bits_read);
}
}

/****************************************************************/
/* The following function is to be called from Fortan.  It      */
/* provides a portable version of Cray routine CRI2IBM -        */
/* interface to read_number/write_number                        */
/****************************************************************/
void
ieee2ibm_
(type, num, ibm_num_out, offset_out, cri_num_in, stride,
    size_num_in, size_num_out)
integer *type, *num, *offset_out, *stride, *size_num_in, *size_num_out;
integer ibm_num_out[], cri_num_in[];
{
/* Prototype functions */
void read_number();
void write_number();
/* local variables */
int i;
int type_num_in, type_num_out, offset;
/* Variables in calls to read/write_number */
integer sign, expo, mant, mant_bits_read;

/* Convert Cray offset to my offset */
 offset = 64 - (int) *offset_out - (int) *size_num_out;

/* Cray fortran uses IEEE data types */
/* decide which data types are used */
if ((int) *type == 2){
  switch ((int) *size_num_in){               /* IEEE integer in */
    case 16:  type_num_in = 6;  break;
    case 32:  type_num_in = 7;  break;
    case 64:  type_num_in = 8;  break;
  }
  switch ((int) *size_num_out){              /* IEEE integer out */
    case 16:  type_num_out = 6;  break;
    case 32:  type_num_out = 7;  break;
    case 64:  type_num_out = 8;  break;
  }
}
else if ((int) *type == 3){
  switch ((int) *size_num_in){               /* real IEEE in */
    case 32:  type_num_in = 3;  break;
    case 64:  type_num_in = 4;  break;
  }
  switch ((int) *size_num_out){              /* real IBM out */
    case 32:  type_num_out = 1;  break;
    case 64:  type_num_out = 2;  break;
  }
}

/*else*/ /* ERROR - unsupported type */

/* Loop over all values converting them as we go along */
for (i=0; i < *num; i++){
  read_number(type_num_in, (int) *size_num_in, 0, cri_num_in[i],
            &sign, &expo, &mant, &mant_bits_read);
  write_number(type_num_out, (int) *size_num_out, offset,
            &ibm_num_out[i], sign, expo, mant, mant_bits_read);
}
}

/****************************************************************/
/* The following function is to be called from Fortan.  It      */
/* provides a portable version of Cray routine IBM2CRI -        */
/* interface to read_number/write_number                        */
/****************************************************************/
void
ibm2ieee_
(type, num, ibm_num_in, offset_in, cri_num_out, stride,
size_num_out, size_num_in)
integer *type, *num, *offset_in, *stride, *size_num_in, *size_num_out;
integer ibm_num_in[], cri_num_out[];
{
/* Prototype functions */
void read_number();
void write_number();
/* Local variables */
int i;
int type_num_in, type_num_out, offset;
/* Variables in calls to read/write_number */
integer sign, expo, mant, mant_bits_read;

/* Convert Cray offset to my offset */
 offset = 64 - (int) *offset_in - (int) *size_num_in;

/* Cray fortran uses IEEE data types */
/* Decide which data types are used */
if ((int) *type == 2){
  switch ((int) *size_num_in){                  /* IEEE integer in */
    case 16:  type_num_in = 6;  break;
    case 32:  type_num_in = 7;  break;
    case 64:  type_num_in = 8;  break;
  }
  switch ((int) *size_num_out){                 /* IEEE integer out */
    case 16:  type_num_out = 6;  break;
    case 32:  type_num_out = 7;  break;
    case 64:  type_num_out = 8;  break;
  }
}
else if ((int) *type == 3){
  switch ((int) *size_num_in){                  /* real IBM in */
    case 32:  type_num_in = 1;  break;
    case 64:  type_num_in = 2;  break;
  }
  switch ((int) *size_num_out){                 /* real IEEE out */
    case 32:  type_num_out = 3;  break;
    case 64:  type_num_out = 4;  break;
  }
}
/*else*/ /* ERROR - unsupported type */

/* Loop over all values converting them as we go along */
for (i=0; i<*num; i++){
  read_number(type_num_in, (int) *size_num_in, offset, ibm_num_in[i],
                     &sign, &expo, &mant, &mant_bits_read);
  write_number(type_num_out, (int) *size_num_out, 0, &cri_num_out[i],
                      sign,  expo,  mant,  mant_bits_read);
}
}

/****************************************************************/
/* The following function is to be called from C.  It           */
/* reads in numbers of different types:                         */
/* real/integer, IBM or IEEE  with offsets/packed etc           */
/* Called from the portable data conversion routines            */
/****************************************************************/
void read_number
(format,size,offset,in_number,out_sign,out_expo,out_mant,mant_bits_read)
int format, size, offset;
integer in_number;
integer *out_sign, *out_expo, *out_mant, *mant_bits_read;
{

integer expo_bits, expo_bias;
integer sign_mask, expo_mask, mant_mask, in_number_mask;
integer one ;
int i, first_bit;

switch (format){
  case 1:
    /* format 1 IBM 32 bits */
    sign_mask =      ibm_sign_32;
    expo_mask =      ibm_expo_32;
    expo_bits =      ibm_expo_bits_32;
    expo_bias =      ibm_expo_bias_32;
    mant_mask =      ibm_mant_32;
    *mant_bits_read = ibm_mant_bits_32;
  break;

  case 2:
    /* format 2 IBM 64 bits */
    sign_mask =      ibm_sign_64;
    expo_mask =      ibm_expo_64;
    expo_bits =      ibm_expo_bits_64;
    expo_bias =      ibm_expo_bias_64;
    mant_mask =      ibm_mant_64;
    *mant_bits_read = ibm_mant_bits_64;
  break;

  case 3:
    /* format 3  IEEE 32 bits */
    sign_mask =      ieee_sign_32;
    expo_mask =      ieee_expo_32;
    expo_bits =      ieee_expo_bits_32;
    expo_bias =      ieee_expo_bias_32;
    mant_mask =      ieee_mant_32;
    *mant_bits_read = ieee_mant_bits_32;
  break;

  case 4:
    /* format 4  IEEE 64 bits */
    sign_mask =      ieee_sign_64;
    expo_mask =      ieee_expo_64;
    expo_bits =      ieee_expo_bits_64;
    expo_bias =      ieee_expo_bias_64;
    mant_mask =      ieee_mant_64;
    *mant_bits_read = ieee_mant_bits_64;
  break;

  case 6:
    /* format 6 IEEE 16 bit integers */
    sign_mask =      ieee_int_sign_16;
    mant_mask =      ieee_int_mant_16;
    *mant_bits_read = ieee_int_mant_bits_16;
    expo_bits = 0;
    expo_bias = 0;
  break;

  case 7:
    /* format 7 IEEE 32 bit integers */
    sign_mask =      ieee_int_sign_32;
    mant_mask =      ieee_int_mant_32;
    *mant_bits_read = ieee_int_mant_bits_32;
    expo_bits = 0;
    expo_bias = 0;
  break;

  case 8:
    /* format 8 IEEE 64 bit integers */
    sign_mask =      ieee_int_sign_64;
    mant_mask =      ieee_int_mant_64;
    *mant_bits_read = ieee_int_mant_bits_64;
    expo_bits = 0;
    expo_bias = 0;
  break;
}

if ( offset != 0 || size != (*mant_bits_read + expo_bits + 1)
     || (64 - offset -size != 0) ){
  /* For offsets and size differences */

  /* shift number to right and clear off any other data in string */
  in_number = in_number >> offset;
  one = 1 ;
  in_number_mask = ( (one << size) - 1 );
  in_number = in_number & in_number_mask;

  /* sign_mask */
  one = 1 ;
  sign_mask = one << (size - 1);
}


/* For all types of nos */

/* Extract 1 bit sign and remove trailing 0s*/
  *out_sign= (in_number & sign_mask) >> (*mant_bits_read + expo_bits);

/* mantissa and expo */

if ((in_number & mant_mask) == 0 && (in_number & expo_mask) == 0) {
  *out_mant = 0 ;
  *out_expo = 0 ;
}
else{
if( format == 1 || format ==2 ){

  /* IBM type numbers */

  /*  find first non-zero bit
  (up to first three leading bits could be 0 from IBM)*/
  first_bit = 0;
  for (i = 1; first_bit == 0; i++){
    if(((in_number & mant_mask) >> (*mant_bits_read - i)) & 1  == 1){
      first_bit = i;
    }
    if(i == *mant_bits_read) first_bit = *mant_bits_read;
  }

  /* shift mantissa to be of the form 1.fraction
     and scale expo appropriately */
  *out_mant = (in_number & mant_mask) << first_bit;

  /*  IBM type - scale base 16 exponent to decimal and then correct
  for normalised mantissa */

  *out_expo =((((in_number & expo_mask) >> *mant_bits_read)
                - expo_bias) * 4) - first_bit;

  /* added extra bit to mantissa forming 1.frac */
  *mant_bits_read = *mant_bits_read + 1;

}
else if(format == 3 || format == 4){

  /* IEEE floating point number */

  /* For IEEE number, add in 1 above fractional mantissa */
  one = 1 ;
  one = one << *mant_bits_read ;

  *out_mant= (in_number & mant_mask) | one ;

  /* just expo, removes trailing 0s, removes offset*/
  *out_expo= ((in_number & expo_mask) >> *mant_bits_read ) - expo_bias;

  /* mant has grown by one bit */
  *mant_bits_read = *mant_bits_read + 1;
}
else {
/* For integers */
  *out_mant = mant_mask & in_number;
  *out_expo = 0;
}
}
/* NB - DATA FROM READ TO WRITE
sign:  1 bit representing sign of mantissa 0=+, 1=-
expo:  without any offset
mantissa: explicit 1 before fraction, normalised
mant_bits_read:  no. of bits in mantissa
offset:POSITIVE, no. of bits to left integer number is offset in string
size:  bit size of number read / wrote */

}

/****************************************************************/
/* The following function is to be called from C.  It           */
/* write out numbers of different types:                        */
/* real/integer, IBM or IEEE with offsets/packed etc            */
/* Called from the portable data conversion routines            */
/****************************************************************/
void write_number
(format,size,offset,out_number,in_sign,in_expo,in_mant,mant_bits_read)
int format, size, offset;
integer *out_number;
integer in_sign, in_expo, in_mant, mant_bits_read;
{
integer mant_bits_write, expo_bits_write;
integer sign_mask, expo_mask, mant_mask;
integer sign, mant, expo, conv_number, conv_number_mask;
integer first_bit, temp;
integer one, add_one ;
integer mant_bits_diff, expo_bias;
int i, expo_diff;

switch(format){
  case 1:
    /* format 1 IBM 32 bit */
    sign= in_sign << 31;
    mant_bits_write= ibm_mant_bits_32;
    expo_bits_write= ibm_expo_bits_32;
    sign_mask= ibm_sign_32;
    expo_mask= ibm_expo_32;
    mant_mask= ibm_mant_32;
    expo_bias= ibm_expo_bias_32;
  break;

  case 2:
    /* format 2 IBM 64 bit */
    sign= in_sign << 63;
    mant_bits_write= ibm_mant_bits_64;
    expo_bits_write= ibm_expo_bits_64;
    sign_mask= ibm_sign_64;
    expo_mask= ibm_expo_64;
    mant_mask= ibm_mant_64;
    expo_bias= ibm_expo_bias_64;
  break;

  case 3:
    /* format 3 IEEE 32 bit */
    sign= in_sign << 31;
    mant_bits_write= ieee_mant_bits_32;
    expo_bits_write= ieee_expo_bits_32;
    sign_mask= ieee_sign_32;
    expo_mask= ieee_expo_32;
    mant_mask= ieee_mant_32;
    expo_bias= ieee_expo_bias_32;
  break;

  case 4:
    /* format 4 IEEE 64 bit */
    sign= in_sign << 63;
    mant_bits_write= ieee_mant_bits_64;
    expo_bits_write= ieee_expo_bits_64;
    sign_mask= ieee_sign_64;
    expo_mask= ieee_expo_64;
    mant_mask= ieee_mant_64;
    expo_bias= ieee_expo_bias_64;
  break;

  case 6:
    /* format 6 IEEE 16 bit integers */
    sign= in_sign << ieee_int_mant_bits_16;
    mant_bits_write= ieee_int_mant_bits_16;
    expo_bits_write= 0;
    expo_mask= 0;
    expo_bias= 0;
    sign_mask= ieee_int_sign_16;
    mant_mask= ieee_int_mant_16;
  break;

  case 7:
    /* format 7 IEEE 32 bit integers */
    sign= in_sign << ieee_int_mant_bits_32;
    mant_bits_write= ieee_int_mant_bits_32;
    expo_bits_write= 0;
    expo_mask= 0;
    expo_bias= 0;
    sign_mask= ieee_int_sign_32;
    mant_mask= ieee_int_mant_32;
  break;

  case 8:
    /* format 8 IEEE 64 bit integers */
    sign= in_sign << ieee_int_mant_bits_64;
    mant_bits_write= ieee_int_mant_bits_64;
    expo_bits_write= 0;
    expo_mask= 0;
    expo_bias= 0;
    sign_mask= ieee_int_sign_64;
    mant_mask= ieee_int_mant_64;
  break;

}

if ( in_mant == 0 && in_expo == 0 ) {
  mant = 0 ;
  expo = 0 ;
}
else {
/* write for real types - formats 1-4 inclusive */

if(format == 1 || format == 2){
  /* IBM numbers - reposition mantissa and re-scale expo to base 16 */

  /*  Find base 16 expo closest to but just larger than in_expo */

  if ( in_expo >= -4 ) {
    expo = in_expo/4 + 1 ;

    if (in_expo < 0) {
      /* Correct exponent for negative powers of 2 */
      expo-- ;
    }

    expo_diff = in_expo - 4*expo ;
  }
  else {
    expo = in_expo/4 ;
    expo_diff = in_expo - 4*expo ;
    if (expo_diff == 0){
      expo++ ;
      expo_diff = in_expo - 4*expo ;
    }
  }
  mant = in_mant >> ( 0 - expo_diff ) ;

  /* mant has shrunk back again, lose extra bit */

  mant_bits_read--;
  expo = expo + expo_bias;

  /* Truncate/grow mantissa as appropriate to write_number format */
  mant_bits_diff = mant_bits_write - mant_bits_read;

  /* check for rounding */
  add_one = 0 ;
  if (mant_bits_diff < 0) {
    mant = (mant >> (0 - mant_bits_diff - 1) ) ;
    if (  mant & 1  == 1 ) {
      add_one = 1 ;
    }
    mant = (mant >> 1) + add_one ;
  }
  else if(mant_bits_diff > 0) mant = ( mant << mant_bits_diff );
  else                        mant = mant;

}
else if (format == 3 || format == 4 ){

  /* For IEEE numbers knock off the 1 before the decimal -
  mantissa is only the fraction and take one from mant_bits_read, as
  it effectively shrinks one bit */

  one = 1 ;
  mant = in_mant ^ (one << (mant_bits_read - 1) );
  mant_bits_read--;

  expo = in_expo + expo_bias;

  /* truncate/grow mantissa as appropriate to write_number format */
  mant_bits_diff = mant_bits_write - mant_bits_read;

  /* check for rounding */
  add_one = 0 ;
  if (mant_bits_diff < 0) {
    mant = (mant >> (0 - mant_bits_diff - 1) ) ;
    if (  mant & 1  == 1 ) {
      add_one = 1 ;
    }
    mant = (mant >> 1) + add_one ;
  }
  else if(mant_bits_diff > 0) mant = (mant << mant_bits_diff );
  else                        mant = mant;

}

else if(format>5){

  /* Write for integer types - formats 6-8 inclusive */
  /* NB integers are written in two's complement form.
     The Most Sig Bit contains sign info (0=+).
     Neg numbers are converse of their pos opposite + 1  */

  /* Positive integers */
  first_bit=0;
  if (in_sign == 0){
    /* Find first data bit */
    for (i=1;first_bit==0;i++){
      if (( in_mant >> (mant_bits_read - i) ) & 1  == 1) first_bit = i;
      if (i == mant_bits_read) first_bit = mant_bits_read;
    }
  }

  /* Negetive integers */
  else{
    /* Find first data bit */
    temp = 0;
    for (i=1;first_bit==0;i++){
      if ( (in_mant >> (mant_bits_read - i)) < ( (temp<<1) + 1) )
          first_bit = i;
      temp = in_mant >> (mant_bits_read - i);
      if (i == mant_bits_read) first_bit = mant_bits_read;
    }
  }

  /* Shrink/truncate as appropriate */
  mant = in_mant & mant_mask;

  /* If no is negative add ones above Most Sigit Bit to fill out two's
    complement form*/
  /* Only need to fill out bits before bit 0 and bit mant_bits_read */

  if(in_sign != 0  &&  mant_bits_write > mant_bits_read){
    one = 1 ;
    mant = mant | ( ( (one << (mant_bits_write - mant_bits_read)) - 1 )
                                << mant_bits_read ) ;
    /* replace sign bit on mant */
    /* mant = mant | ( one << (mant_bits_read - 1) ); */
  }

  /* Warn if siginificant bits are lost
  mant_bits_diff = mant_bits_write - mant_bits_read;
  if ( (mant_bits_diff + first_bit) > 1) WARN
  */

  /* Null unused expo for build up number */
  expo = 0;
}
}

/* Build up converted number */
sign= sign_mask & sign;
mant= mant_mask & mant;
expo= expo_mask & (expo << (mant_bits_write) );
conv_number= sign | expo | mant;

/* Dealing with different sizes and offsets within the longer
   data type */
/* i.e.,  format = 32 bit int, but size = 8, offset = 8 */
/*  ----------------11111111--------  */
/*  32 bit data     8b size  8b offest
    ^ this kind of packing is used in the UM */

  if (offset != 0 || size != (mant_bits_write + expo_bits_write + 1)
      || (64 - offset - size) != 0) {
  /* create mask for converted number */
    one = 1;
    conv_number_mask = (one << size) - 1;
  }
  else {
    conv_number_mask = -1 ;
  }

  /* apply offset to mask and number */
  conv_number_mask = conv_number_mask << offset;
  conv_number = conv_number << offset;

  /* write in the correct place within the original string */
  *out_number = conv_number | ( *out_number & (~conv_number_mask) );

}

/****************************************************************/
/* The following function is to be called from Fortan.  It      */
/* provides a portable version of Cray routine STRMOV -         */
/* mirrored parameters and functionality: shifts bytes from     */
/* one variable to another.                                     */
/****************************************************************/
void
movebytes_
(src,isb,num,dest,idb)
integer src[], *isb, *num, dest[], *idb;
/* src:  source variable
   isb:  starting byte of moved byte, bytes numbered from 1 from left
   num:  number of bytes moved
   dest: destianation variable
   idb:  starting byte in destination variable */
/* MOVEBYTES assumes kind=8 ie 64bit data */
{
  /* Local variables */
  integer  bytes, bytes_mask, dest_temp, one;
  integer  nbytes_moved, nbytes_to_move, num_left ;
  integer  src_start, dest_start ;
  int      src_index, dest_index ;
  int      i ;

  nbytes_moved = 0 ;
  num_left = *num ;
  src_index = 0 ;
  dest_index = 0 ;
  src_start = *isb ;
  dest_start = *idb ;

  /* Check which element we're reading from and adjust accordingly */
  if (src_start > 8) {
    src_index = src_start/8 ;
    src_start = src_start - 8 * src_index ;
  }

  /* Check which element we're writing to and adjust accordingly */
  if (dest_start > 8) {
    dest_index = dest_start/8 ;
    dest_start = dest_start - 8 * dest_index ;
  }

  for (i=0 ; num_left > 0 ; i++) {

    /* First, set the nbytes_to_move to the number of bytes in
       src[src_index] between byte=src_start and byte=8 */

    nbytes_to_move = 8 - src_start + 1;

    /* Check whether nbytes_to_move is greater than the number
       left to be moved.  If it is, then set equal to num_left */

    if (nbytes_to_move > num_left) nbytes_to_move = num_left ;

    /* Check whether there is enough room in dest[dest_index]
       between byte=dest_start and byte=64 to insert nbytes_to_move
       and, if not, then set equal to the number of bytes available */

    if (nbytes_to_move > (8 - dest_start + 1) ) {
       nbytes_to_move = 8 - dest_start + 1 ;
    }

    /* if (nbytes_to_move > (8 - src_start + 1) ) {
       nbytes_to_move = 8 - src_start + 1;
    } */

    /* Move nbytes_to_move bytes from src_start in *src to dest_start
       in *dest  */

    /* make mask of same length as bits */

    if (nbytes_to_move == 8) {
    /* This is effectively a copy dest[dest_index] = src[src_index] */
      bytes_mask = -1 ;
    }
    else{
      bytes_mask = 0;
      one = 1 ;
      bytes_mask = (one << (8 * nbytes_to_move) ) - 1;
    }

    /* grab bits from src */
    bytes =
      (src[src_index] >> (64 - (8*(src_start-1)) - (8*nbytes_to_move)))
      & bytes_mask;

    /* put bits in dest */
    dest_temp = dest[dest_index]  &
      ( ~(bytes_mask << ( 64 - (8 * (dest_start-1) )
                                          - (8 * nbytes_to_move) ) ) );
    dest[dest_index] =  dest_temp |
     ( bytes << ( 64 - (8 * (dest_start-1) ) - (8 * nbytes_to_move) ) );

    /* Update number of bytes moved and number left to move */

    nbytes_moved = nbytes_moved + nbytes_to_move ;
    num_left = num_left - nbytes_to_move ;

    /* Update src_start ready for move of next chunk and check
       whether we've moved onto the next data element  */

    src_start = src_start + nbytes_to_move ;

    if (src_start > 8) {
      src_start = src_start - 8 ;
      src_index++ ;
    }

    /* Update dest_start ready for move of next chunk and check
       whether we've moved onto the next data element  */

    dest_start = dest_start + nbytes_to_move ;

    if (dest_start > 8) {
      dest_start = dest_start - 8 ;
      dest_index++ ;
    }
  }
}

/****************************************************************/
/* The following function is to be called from Fortan.  It      */
/* provides a portable version of Cray routine MOVBIT -         */
/* mirrored parameters and functionality: shifts bytes from     */
/* one variable to another.                                     */
/****************************************************************/
void
movebits_
(src,isb,num,dest,idb)
integer src[], *isb, *num, dest[], *idb;
/* src:  source variable
   isb:  starting bit of moved bits, bits numbered from 1 from left
   num:  number of bits moved
   dest: destianation variable
   idb:  starting bit in destination variable */

/* MOVBIT assumes kind=8 ie 64bit data */
{
  /* Local variables */

  integer  bits, bits_mask, dest_temp, one;
  integer  nbits_moved, nbits_to_move, num_left ;
  integer  src_start, dest_start ;
  int      src_index, dest_index ;
  int      i ;

  nbits_moved = 0 ;
  num_left = *num ;
  src_index = 0 ;
  dest_index = 0 ;
  src_start = *isb ;
  dest_start = *idb ;

  /* Check which element we're reading from and adjust accordingly */
  if (src_start > 64) {
    src_index = src_start/64 ;
    src_start = src_start - 64 * src_index ;
  }

  /* Check which element we're writing to and adjust accordingly */
  if (dest_start > 64) {
    dest_index = dest_start/64 ;
    dest_start = dest_start - 64 * dest_index ;
  }

  for (i=0 ; num_left > 0 ; i++) {

    /* First, set the nbits_to_move to the number of bits in
       src[src_index] between bit=src_start and bit=64 */

    nbits_to_move = 64 - src_start + 1;

    /* Check whether nbits_to_move is greater than the number
       left to be moved.  If it is, then set equal to num_left */

    if (nbits_to_move > num_left) nbits_to_move = num_left ;

    /* Check whether there is enough room in dest[dest_index]
       between bit=dest_start and bit=64 to insert nbits_to_move
       and, if not, then set equal to the number of bits available */

    if (nbits_to_move > (64 - dest_start + 1) ) {
       nbits_to_move = 64 - dest_start + 1 ;
    }

    /* if (nbits_to_move > (64 - src_start + 1) ) {
       nbits_to_move = 64 - dest_start + 1;
    } */

    /* Move nbits_to_move bits from src_start in *src to dest_start
       in *dest  */

    /* make mask of same length as bits */

    if (nbits_to_move == 64) {
    /*  This is effectively a copy: dest[dest_index]=src[src_index] */
      bits_mask = -1 ;
    }
    else{
      bits_mask = 0;
      one = 1 ;
      bits_mask = (one << nbits_to_move) - 1;
    }

    /* grab bits from src */
    bits = (src[src_index] >> ( 64 - src_start - nbits_to_move + 1) )
         & bits_mask;

    /* put bits in dest */
    dest_temp = dest[dest_index]
         & ( ~(bits_mask << ( 64 - dest_start - nbits_to_move +1)) );
    dest[dest_index] =  dest_temp |
                ( bits << ( 64 - dest_start - nbits_to_move +1) );

    /* Update number of bits moved and number left to move */

    nbits_moved = nbits_moved + nbits_to_move ;
    num_left = num_left - nbits_to_move ;

    /* Update src_start ready for move of next chunk and check
       whether we've moved onto the next data element  */

    src_start = src_start + nbits_to_move ;

    if (src_start > 64) {
      src_start = src_start - 64 ;
      src_index++ ;
    }

    /* Update dest_start ready for move of next chunk and check
       whether we've moved onto the next data element  */

    dest_start = dest_start + nbits_to_move ;

    if (dest_start > 64) {
      dest_start = dest_start - 64 ;
      dest_index++ ;
    }
  }
}
void
ieee2ibmx_
(type, num, ibm_num_out, offset_out, cri_num_in, stride,
    size_num_in, size_num_out)
integer *type, *num, *offset_out, *stride, *size_num_in, *size_num_out;
integer ibm_num_out[], cri_num_in[];
{
/* Prototype functions */
void read_numberx();
void write_numberx();
/* local variables */
int i;
int type_num_in, type_num_out, offset;
/* Variables in calls to read/write_number */
integer sign, expo, mant, mant_bits_read;

/* Convert Cray offset to my offset */
 offset = 64 - (int) *offset_out - (int) *size_num_out;

/* Cray fortran uses IEEE data types */
/* decide which data types are used */
if ((int) *type == 2){
  switch ((int) *size_num_in){               /* IEEE integer in */
    case 16:  type_num_in = 6;  break;
    case 32:  type_num_in = 7;  break;
    case 64:  type_num_in = 8;  break;
  }
  switch ((int) *size_num_out){              /* IEEE integer out */
    case 16:  type_num_out = 6;  break;
    case 32:  type_num_out = 7;  break;
    case 64:  type_num_out = 8;  break;
  }
}
else if ((int) *type == 3){
  switch ((int) *size_num_in){               /* real IEEE in */
    case 32:  type_num_in = 3;  break;
    case 64:  type_num_in = 4;  break;
  }
  switch ((int) *size_num_out){              /* real IBM out */
    case 32:  type_num_out = 1;  break;
    case 64:  type_num_out = 2;  break;
  }
}

/*else*/ /* ERROR - unsupported type */

/* Loop over all values converting them as we go along */
for (i=0; i < *num; i++){
  read_numberx(type_num_in, (int) *size_num_in, 0, cri_num_in[i],
            &sign, &expo, &mant, &mant_bits_read);
  write_numberx(type_num_out, (int) *size_num_out, offset,
            &ibm_num_out[i], sign, expo, mant, mant_bits_read);
}
}

/****************************************************************/
/* The following function is to be called from C.  It           */
/* reads in numbers of different types:                         */
/* real/integer, IBM or IEEE  with offsets/packed etc           */
/* Called from the portable data conversion routines            */
/****************************************************************/
void read_numberx
(format,size,offset,in_number,out_sign,out_expo,out_mant,mant_bits_read)
int format, size, offset;
integer in_number;
integer *out_sign, *out_expo, *out_mant, *mant_bits_read;
{

integer expo_bits, expo_bias;
integer sign_mask, expo_mask, mant_mask, in_number_mask;
integer one ;
int i, first_bit;

switch (format){
  case 1:
    /* format 1 IBM 32 bits */
    sign_mask =      ibm_sign_32;
    expo_mask =      ibm_expo_32;
    expo_bits =      ibm_expo_bits_32;
    expo_bias =      ibm_expo_bias_32;
    mant_mask =      ibm_mant_32;
    *mant_bits_read = ibm_mant_bits_32;
  break;

  case 2:
    /* format 2 IBM 64 bits */
    sign_mask =      ibm_sign_64;
    expo_mask =      ibm_expo_64;
    expo_bits =      ibm_expo_bits_64;
    expo_bias =      ibm_expo_bias_64;
    mant_mask =      ibm_mant_64;
    *mant_bits_read = ibm_mant_bits_64;
  break;

  case 3:
    /* format 3  IEEE 32 bits */
    sign_mask =      ieee_sign_32;
    expo_mask =      ieee_expo_32;
    expo_bits =      ieee_expo_bits_32;
    expo_bias =      ieee_expo_bias_32;
    mant_mask =      ieee_mant_32;
    *mant_bits_read = ieee_mant_bits_32;
  break;

  case 4:
    /* format 4  IEEE 64 bits */
    sign_mask =      ieee_sign_64;
    expo_mask =      ieee_expo_64;
    expo_bits =      ieee_expo_bits_64;
    expo_bias =      ieee_expo_bias_64;
    mant_mask =      ieee_mant_64;
    *mant_bits_read = ieee_mant_bits_64;
  break;

  case 6:
    /* format 6 IEEE 16 bit integers */
    sign_mask =      ieee_int_sign_16;
    mant_mask =      ieee_int_mant_16;
    *mant_bits_read = ieee_int_mant_bits_16;
    expo_bits = 0;
    expo_bias = 0;
  break;

  case 7:
    /* format 7 IEEE 32 bit integers */
    sign_mask =      ieee_int_sign_32;
    mant_mask =      ieee_int_mant_32;
    *mant_bits_read = ieee_int_mant_bits_32;
    expo_bits = 0;
    expo_bias = 0;
  break;

  case 8:
    /* format 8 IEEE 64 bit integers */
    sign_mask =      ieee_int_sign_64;
    mant_mask =      ieee_int_mant_64;
    *mant_bits_read = ieee_int_mant_bits_64;
    expo_bits = 0;
    expo_bias = 0;
  break;
}

if ( offset != 0 || size != (*mant_bits_read + expo_bits + 1)
     || (64 - offset -size != 0) ){
  /* For offsets and size differences */

  /* shift number to right and clear off any other data in string */
  in_number = in_number >> offset;
  one = 1 ;
  in_number_mask = ( (one << size) - 1 );
  in_number = in_number & in_number_mask;

  /* sign_mask */
  one = 1 ;
  sign_mask = one << (size - 1);
}


/* For all types of nos */

/* Extract 1 bit sign and remove trailing 0s*/
  *out_sign= (in_number & sign_mask) >> (*mant_bits_read + expo_bits);

/* mantissa and expo */

if ((in_number & mant_mask) == 0 && (in_number & expo_mask) == 0) {
  *out_mant = 0 ;
  *out_expo = 0 ;
}
else{
if( format == 1 || format ==2 ){

  /* IBM type numbers */

  /*  find first non-zero bit
  (up to first three leading bits could be 0 from IBM)*/
  first_bit = 0;
  for (i = 1; first_bit == 0; i++){
    if(((in_number & mant_mask) >> (*mant_bits_read - i)) & 1  == 1){
      first_bit = i;
    }
    if(i == *mant_bits_read) first_bit = *mant_bits_read;
  }

  /* shift mantissa to be of the form 1.fraction
     and scale expo appropriately */
  *out_mant = (in_number & mant_mask) << first_bit;

  /*  IBM type - scale base 16 exponent to decimal and then correct
  for normalised mantissa */

  *out_expo =((((in_number & expo_mask) >> *mant_bits_read)
                - expo_bias) * 4) - first_bit;

  /* added extra bit to mantissa forming 1.frac */
  *mant_bits_read = *mant_bits_read + 1;

}
else if(format == 3 || format == 4){

  /* IEEE floating point number */

  /* For IEEE number, add in 1 above fractional mantissa */
  one = 1 ;
  one = one << *mant_bits_read ;

  *out_mant= (in_number & mant_mask) | one ;

  /* just expo, removes trailing 0s, removes offset*/
  *out_expo= ((in_number & expo_mask) >> *mant_bits_read ) - expo_bias;

  /* mant has grown by one bit */
  *mant_bits_read = *mant_bits_read + 1;
}
else {
/* For integers */
  *out_mant = mant_mask & in_number;
  *out_expo = 0;
}
}
/* NB - DATA FROM READ TO WRITE
sign:  1 bit representing sign of mantissa 0=+, 1=-
expo:  without any offset
mantissa: explicit 1 before fraction, normalised
mant_bits_read:  no. of bits in mantissa
offset:POSITIVE, no. of bits to left integer number is offset in string
size:  bit size of number read / wrote */

}

/****************************************************************/
/* The following function is to be called from C.  It           */
/* write out numbers of different types:                        */
/* real/integer, IBM or IEEE with offsets/packed etc            */
/* Called from the portable data conversion routines            */
/****************************************************************/
void write_numberx
(format,size,offset,out_number,in_sign,in_expo,in_mant,mant_bits_read)
int format, size, offset;
integer *out_number;
integer in_sign, in_expo, in_mant, mant_bits_read;
{
integer mant_bits_write, expo_bits_write;
integer sign_mask, expo_mask, mant_mask;
integer sign, mant, expo, conv_number, conv_number_mask;
integer first_bit, temp;
integer one, add_one ;
integer mant_bits_diff, expo_bias;
int i, expo_diff;

switch(format){
  case 1:
    /* format 1 IBM 32 bit */
    sign= in_sign << 31;
    mant_bits_write= ibm_mant_bits_32;
    expo_bits_write= ibm_expo_bits_32;
    sign_mask= ibm_sign_32;
    expo_mask= ibm_expo_32;
    mant_mask= ibm_mant_32;
    expo_bias= ibm_expo_bias_32;
  break;

  case 2:
    /* format 2 IBM 64 bit */
    sign= in_sign << 63;
    mant_bits_write= ibm_mant_bits_64;
    expo_bits_write= ibm_expo_bits_64;
    sign_mask= ibm_sign_64;
    expo_mask= ibm_expo_64;
    mant_mask= ibm_mant_64;
    expo_bias= ibm_expo_bias_64;
  break;

  case 3:
    /* format 3 IEEE 32 bit */
    sign= in_sign << 31;
    mant_bits_write= ieee_mant_bits_32;
    expo_bits_write= ieee_expo_bits_32;
    sign_mask= ieee_sign_32;
    expo_mask= ieee_expo_32;
    mant_mask= ieee_mant_32;
    expo_bias= ieee_expo_bias_32;
  break;

  case 4:
    /* format 4 IEEE 64 bit */
    sign= in_sign << 63;
    mant_bits_write= ieee_mant_bits_64;
    expo_bits_write= ieee_expo_bits_64;
    sign_mask= ieee_sign_64;
    expo_mask= ieee_expo_64;
    mant_mask= ieee_mant_64;
    expo_bias= ieee_expo_bias_64;
  break;

  case 6:
    /* format 6 IEEE 16 bit integers */
    sign= in_sign << ieee_int_mant_bits_16;
    mant_bits_write= ieee_int_mant_bits_16;
    expo_bits_write= 0;
    expo_mask= 0;
    expo_bias= 0;
    sign_mask= ieee_int_sign_16;
    mant_mask= ieee_int_mant_16;
  break;

  case 7:
    /* format 7 IEEE 32 bit integers */
    sign= in_sign << ieee_int_mant_bits_32;
    mant_bits_write= ieee_int_mant_bits_32;
    expo_bits_write= 0;
    expo_mask= 0;
    expo_bias= 0;
    sign_mask= ieee_int_sign_32;
    mant_mask= ieee_int_mant_32;
  break;

  case 8:
    /* format 8 IEEE 64 bit integers */
    sign= in_sign << ieee_int_mant_bits_64;
    mant_bits_write= ieee_int_mant_bits_64;
    expo_bits_write= 0;
    expo_mask= 0;
    expo_bias= 0;
    sign_mask= ieee_int_sign_64;
    mant_mask= ieee_int_mant_64;
  break;

}

if ( in_mant == 0 && in_expo == 0 ) {
  mant = 0 ;
  expo = 0 ;
}
else {
/* write for real types - formats 1-4 inclusive */

if(format == 1 || format == 2){
  /* IBM numbers - reposition mantissa and re-scale expo to base 16 */

  /*  Find base 16 expo closest to but just larger than in_expo */

  if ( in_expo >= -4 ) {
    expo = in_expo/4 + 1 ;

    if (in_expo < 0) {
      /* Correct exponent for negative powers of 2 */
      expo-- ;
    }

    expo_diff = in_expo - 4*expo ;
  }
  else {
    expo = in_expo/4 ;
    expo_diff = in_expo - 4*expo ;
    if (expo_diff == 0){
      expo++ ;
      expo_diff = in_expo - 4*expo ;
    }
  }
  mant = in_mant >> ( 0 - expo_diff ) ;

  /* mant has shrunk back again, lose extra bit */

  mant_bits_read--;
  expo = expo + expo_bias;

  /* Truncate/grow mantissa as appropriate to write_number format */
  mant_bits_diff = mant_bits_write - mant_bits_read;

  /* check for rounding */
  add_one = 0 ;
  if (mant_bits_diff < 0) {
    mant = (mant >> (0 - mant_bits_diff - 1) ) ;
    if (  mant & 1  == 1 ) {
      add_one = 1 ;
    }
    mant = (mant >> 1) + add_one ;
  }
  else if(mant_bits_diff > 0) mant = ( mant << mant_bits_diff );
  else                        mant = mant;

}
else if (format == 3 || format == 4 ){

  /* For IEEE numbers knock off the 1 before the decimal -
  mantissa is only the fraction and take one from mant_bits_read, as
  it effectively shrinks one bit */

  one = 1 ;
  mant = in_mant ^ (one << (mant_bits_read - 1) );
  mant_bits_read--;

  expo = in_expo + expo_bias;

  /* truncate/grow mantissa as appropriate to write_number format */
  mant_bits_diff = mant_bits_write - mant_bits_read;

  /* check for rounding */
  add_one = 0 ;
  if (mant_bits_diff < 0) {
    mant = (mant >> (0 - mant_bits_diff - 1) ) ;
    if (  mant & 1  == 1 ) {
      add_one = 1 ;
    }
    mant = (mant >> 1) + add_one ;
  }
  else if(mant_bits_diff > 0) mant = (mant << mant_bits_diff );
  else                        mant = mant;

}

else if(format>5){

  /* Write for integer types - formats 6-8 inclusive */
  /* NB integers are written in two's complement form.
     The Most Sig Bit contains sign info (0=+).
     Neg numbers are converse of their pos opposite + 1  */

  /* Positive integers */
  first_bit=0;
  if (in_sign == 0){
    /* Find first data bit */
    for (i=1;first_bit==0;i++){
      if (( in_mant >> (mant_bits_read - i) ) & 1  == 1) first_bit = i;
      if (i == mant_bits_read) first_bit = mant_bits_read;
    }
  }

  /* Negetive integers */
  else{
    /* Find first data bit */
    temp = 0;
    for (i=1;first_bit==0;i++){
      if ( (in_mant >> (mant_bits_read - i)) < ( (temp<<1) + 1) )
          first_bit = i;
      temp = in_mant >> (mant_bits_read - i);
      if (i == mant_bits_read) first_bit = mant_bits_read;
    }
  }

  /* Shrink/truncate as appropriate */
  mant = in_mant & mant_mask;

  /* If no is negative add ones above Most Sigit Bit to fill out two's
    complement form*/
  /* Only need to fill out bits before bit 0 and bit mant_bits_read */

  if(in_sign != 0  &&  mant_bits_write > mant_bits_read){
    one = 1 ;
    mant = mant | ( ( (one << (mant_bits_write - mant_bits_read)) - 1 )
                                << mant_bits_read ) ;
    /* replace sign bit on mant */
    /* mant = mant | ( one << (mant_bits_read - 1) ); */
  }

  /* Warn if siginificant bits are lost
  mant_bits_diff = mant_bits_write - mant_bits_read;
  if ( (mant_bits_diff + first_bit) > 1) WARN
  */

  /* Null unused expo for build up number */
  expo = 0;
}
}

/* Build up converted number */
sign= sign_mask & sign;
mant= mant_mask & mant;
expo= expo_mask & (expo << (mant_bits_write) );
conv_number= sign | expo | mant;

/* Dealing with different sizes and offsets within the longer
   data type */
/* i.e.,  format = 32 bit int, but size = 8, offset = 8 */
/*  ----------------11111111--------  */
/*  32 bit data     8b size  8b offest
    ^ this kind of packing is used in the UM */

  if (offset != 0 || size != (mant_bits_write + expo_bits_write + 1)
      || (64 - offset - size) != 0) {
  /* create mask for converted number */
    one = 1;
    conv_number_mask = (one << size) - 1;
  }
  else {
    conv_number_mask = -1 ;
  }

  /* apply offset to mask and number */
  conv_number_mask = conv_number_mask << offset;
  conv_number = conv_number << offset;

  /* write in the correct place within the original string */
  *out_number = conv_number | ( *out_number & (~conv_number_mask) );

}

