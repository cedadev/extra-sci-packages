Member:  @FCODES             Table of field codes used by the PP-package
   pp[     ] = "         Copy on $UMDOC/ppcodes.txt on (NWP) HP system";
   pp[     ] = "              ( MOWW http://fr0800/umdoc/ppcodes.txt )";
   pp[11:40] = "04/02/97";
   pp[     ] = "      LBFC     TABLE OF PP-PACKAGE FIELD CODES";
   pp[     ] = "      ~~~~     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~";

   Listed below are the main field codes used by the PP-package.
   There is no connection between ranges of codes reserved below
   and UM submodels.  The same list is also used for the coding of
   the vertical co-ordinate type in field headers and for
   indicators in the Unified Model.

   pp[    1] = "- 200 are to be used for general meteorological variables.";
   pp[  201] = "- 350 Originally local codes used by MET O 20.";
   pp[     ] = "      Now incorporated, with some alterations, in the";
   pp[     ] = "      official list for use by the Atmospheric (Unified) Model.";
   pp[  351] = "- 400 Wave/ Reserved for operational wave model.";
   pp[  401] = "- 450   MA/ Reserved for middle atmosphere, not tracer variables";
   pp[  451] = "- 499 MAtr/ Reserved for middle atmosphere tracer variables";
   pp[  500] = "- 600 MAUA/ Reserved for middle atmosphere UARS chemicals";
   pp[  601] = "- 699 OCtr/ Reserved for Ocean model: tracer points";
   pp[  700] = "- 799 OCuv/ Reserved for Ocean model: u,v,points";
   pp[  800] = "- 849  OCE/ Reserved for Ocean model: other";
   pp[     ] = "              831-832 are not on the tracer or velocity grids.";
   pp[  850] = "- 890   OA/ Reserved for Ocean model: assimilation";
   pp[  891] = "- 999  OCE/ Reserved for Ocean model: other";
   pp[ 1000] = "- 1300        Reserved for new atmospheric dynamics (Mawson)";
   pp[ 1301] = "- 1339        Reserved for further Atmospheric (Unified) Model codes";
   pp[ 1340] = "- 1369        Reserved for VAR";
   pp[ 1370] = "- 1379 SO4  Reserved for SO4 aerosol items";
   pp[ 1380] = "- 1599        Reserved for further Atmospheric (Unified) Model codes";
   pp[ 1600] = "- 1699        Reserved for further general meteorological variables";

   IMPORTANT
   ~~~~~~~~~
   New field codes can only be allocated by the PP-package manager -
   Mike Hatton (NWP Division) EM mjhatton@meto.gov.uk

   NOTES:
   ~~~~~~
(a)  Field codes 30 to 34 are used to indicate cloud AMOUNTS by coding
     zero for the vertical co-ordinate type.  When a vertical
     co-ordinate type in the range 135 to 138 is coded, these field
     codes represent the upper or lower boundaries of clouds or
     contrails.

(b)  Some of the original M20 fields were duplicates of existing fields
     and have been removed, others have been re-defined to conform to
     official PP standards.

(c)  Type I clear-sky quantities are those from those points
     and times when no clouds are in fact present.
     Type II are those that would be produced everywhere
     in the absence of clouds but with no other changes.
     These definitions were interchanged up to 10 Sept 1993.
     The wording was revised at this date.

(d)  Codes inset have not been approved but are in STASHmaster for the
     present.

 ---------------------------------------------------------------

   pp[   0 ] = "Unspecified";
   pp[   1 ] = "Height";
   pp[   2 ] = "Depth";
   pp[   3 ] = "Geopotential (= g*height)";
   pp[   4 ] = "ICAO height";
   pp[   5 ] = "Boundary layer height";
   pp[   6 ] = "Non-dimensional soil model level";
   pp[   7 ] = "Exner pressure";
   pp[   8 ] = "Pressure";
   pp[   9 ] = "Hybrid";
   pp[  10 ] = "Sigma (= p/surface p)";
   pp[  11 ] = "T*u";
   pp[  12 ] = "T*v";
   pp[  13 ] = "T**2";
   pp[  14 ] = "T*omega";
   pp[  15 ] = "Height**2";
   pp[  16 ] = "Temperature T";
   pp[  17 ] = "Dew point temperature";
   pp[  18 ] = "Dew point depression";
   pp[  19 ] = "Potential temperature";
   pp[  20 ] = "Maximum temperature";
   pp[  21 ] = "Minimum temperature";
   pp[  22 ] = "Wet bulb potential temperature";
   pp[  23 ] = "Soil temperature (levels 2,3,4)";
   pp[  24 ] = "d theta/dt";
   pp[  25 ] = "Visibility";
   pp[  26 ] = "Brunt-Vaisala Frequency N";
   pp[  27 ] = "(Atmospheric) density";
   pp[  28 ] = "d(p*)/dt .  p* = surface pressure";
   pp[  29 ] = "Cloud fraction below a level in feet";
   pp[  30 ] = "Total cloud       See note (a) in @FCODES";
   pp[  31 ] = "High cloud        See note (a) in @FCODES";
   pp[  32 ] = "Medium cloud      See note (a) in @FCODES";
   pp[  33 ] = "Low cloud         See note (a) in @FCODES";
   pp[  34 ] = "Convective cloud  See note (a) in @FCODES";
   pp[  35 ] = "Contrail";
   pp[  36 ] = "Fractional land amount";
   pp[  37 ] = "Fractional sea-ice cover";
   pp[  38 ] = "Atmospheric model land/sea mask   Land=1, Sea=0";
   pp[  39 ] = "Coriolis parameter";
   pp[  40 ] = "Omega  (= dp/dt)";
   pp[  41 ] = "Wet bulb temperature";
   pp[  42 ] = "Vertical velocity  (= dz/dt)";
   pp[  43 ] = "Eta dot";
   pp[  44 ] = "Time in seconds";
   pp[  45 ] = "d(sigma)/dt";
   pp[  46 ] = "u*q";
   pp[  47 ] = "v*q";
   pp[  48 ] = "x wind component (with respect to grid)";
   pp[  49 ] = "y wind component (with respect to grid)";
   pp[  50 ] = "Wind speed";
   pp[  51 ] = "Thermal wind speed";
   pp[  52 ] = "Vertical speed shear";
   pp[  53 ] = "u*omega";
   pp[  54 ] = "v*omega";
   pp[  55 ] = "Wind direction";
   pp[  56 ] = "Westerly component of wind  u";
   pp[  57 ] = "Southerly component of wind v";
   pp[  58 ] = "u**2";
   pp[  59 ] = "v**2";
   pp[  60 ] = "Product of wind components  u*v";
   pp[  61 ] = "x component of wind stress";
   pp[  62 ] = "y component of wind stress";
   pp[  63 ] = "Kinetic energy";
   pp[  64 ] = "Wind in DDDFFF format";
   pp[  65 ] = "Reserved for M.Mawson";
   pp[  66 ] = "Reserved for M.Mawson";
   pp[  67 ] = "Reserved for M.Mawson";
   pp[  68 ] = "u-acceleration from saturated stress";
   pp[  69 ] = "v-acceleration from saturated stress";
   pp[  70 ] = "u-acceleration from hydraulic jump";
   pp[  71 ] = "v-acceleration from hydraulic jump";
   pp[  72 ] = "Absolute vorticity";
   pp[  73 ] = "Relative vorticity";
   pp[  74 ] = "Divergence";
   pp[  75 ] = "Height of base of lowest cloud in feet";
   pp[  76 ] = "Height of top of lowest cloud in feet";
   pp[  77 ] = "Total precipitation accumulation";
   pp[  78 ] = "QCF - Frozen cloud water";
   pp[  79 ] = "QCL - Liquid cloud water";
   pp[  80 ] = "Stream function";
   pp[  81 ] = "Velocity potential";
   pp[  82 ] = "Ertel potential vorticity (Q)";
   pp[  83 ] = "Thermal vorticity";
   pp[  84 ] = "Quasi-geostrophic potential vorticity";
   pp[  85 ] = "Montgomery stream function";
   pp[  86 ] = "Geostrophic absolute vorticity";
   pp[  87 ] = "dq/dt";
   pp[  88 ] = "Relative humidity";
   pp[  89 ] = "Precipitable water";
   pp[  90 ] = "Total precipitation (= 94 + 102 + 103)";
   pp[  91 ] = "Equivalent ice depth";
   pp[  92 ] = "Actual ice depth";
   pp[  93 ] = "Snow depth (water equivalent)";
   pp[  94 ] = "Convective rain";
   pp[  95 ] = "Specific humidity q";
   pp[  96 ] = "Condensed water (per unit area)";
   pp[  97 ] = "Total rainfall rate";
   pp[  98 ] = "Convective rainfall rate";
   pp[  99 ] = "Dynamic rainfall rate";
   pp[ 100 ] = "Local convective rainfall";
   pp[ 101 ] = "Mixing ratio";
   pp[ 102 ] = "Large scale rain";
   pp[ 103 ] = "Snow";
   pp[ 104 ] = "Total rain  (= 94 + 102)";
   pp[ 105 ] = "Evaporation";
   pp[ 106 ] = "Total soil moisture content (levels 1-4)";
   pp[ 107 ] = "Sublimation";
   pp[ 108 ] = "Snowfall rate mm/s";
   pp[ 109 ] = "Total runoff";
   pp[ 110 ] = "Snowmelt";
   pp[ 111 ] = "Quick runoff";
   pp[ 112 ] = "Slow runoff";
   pp[ 113 ] = "(Precipitation minus evaporation) rate (= 90 - 105)";
   pp[ 114 ] = "Evaporation rate";
   pp[ 115 ] = "Evaporation from soil surface";
   pp[ 116 ] = "Large scale snowfall";
   pp[ 117 ] = "Convective snowfall";
   pp[ 118 ] = "Large scale snowfall rate mm/s";
   pp[ 119 ] = "Convective snowfall rate mm/s";
   pp[ 120 ] = "Total large-scale precipitation (102+116)";
   pp[ 121 ] = "Total convective precipitation (94+117)";
   pp[ 122 ] = "Soil moisture in each (of 4) levels";
   pp[ 123 ] = "u-acceleration from trapped lee waves";
   pp[ 124 ] = "v-acceleration from trapped lee waves";
   pp[ 125 ] = "Vertical transmission coefficient";
   pp[ 126 ] = "Max C.A.T. level";
   pp[ 127 ] = "Sea bed level";
   pp[ 128 ] = "Mean sea level";
   pp[ 129 ] = "Surface";
   pp[ 130 ] = "Tropopause level";
   pp[ 131 ] = "Maximum wind level";
   pp[ 132 ] = "Freezing level";
   pp[ 133 ] = "Top of atmosphere";
   pp[ 134 ] = "-20 deg.C level";
   pp[ 135 ] = "Upper level (height)";
   pp[ 136 ] = "Lower level (height)";
   pp[ 137 ] = "Upper level (pressure)";
   pp[ 138 ] = "Lower level (pressure)";
   pp[ 139 ] = "Wet bulb freezing level height (asl) M";
   pp[ 140 ] = "Salinity";
   pp[ 141 ] = "Snowmelt heat flux";
   pp[ 142 ] = "Upper level (hybrid)";
   pp[ 143 ] = "Lower level (hybrid)";
   pp[ 144 ] = "Unified model test diagnostic for output no. 1";
   pp[ 145 ] = "Unified model test diagnostic for output no. 2";
   pp[ 146 ] = "Unified model test diagnostic for output no. 3";
   pp[ 147 ] = "Unified model test diagnostic for output no. 4";
   pp[ 148 ] = "X component of geostrophic wind";
   pp[ 149 ] = "Y component of geostrophic wind";
   pp[ 150 ] = "Standard deviation of orography";
   pp[ 151 ] = "Distance to the centre of the earth";
   pp[ 152 ] = "Orography XX gradient component";
   pp[ 153 ] = "Orography XY gradient component";
   pp[ 154 ] = "Orography YY gradient component";
   pp[ 155 ] = "Orographic roughness";
   pp[ 156 ] = "Total ozone climatology";
   pp[ 157 ] = "Ultra violet index climatology";
   pp[ 158 ] = "Total ozone field, Dobson units";
   pp[ 159 ] = "UVB (Ultra violet index - dimensionless)";
   pp[ 160 ] = "Drag coefficient CD";
   pp[ 161 ] = "Theta_e";
   pp[ 162 ] = "Sunshine hours";
   pp[ 163 ] = "Convective cloud liquid re * convective cloud amount";
   pp[ 164 ] = "Layer cloud liquid re * layer cloud amount";
   pp[ 165 ] = "Convective cloud amount in SWRAD (microphysics)";
   pp[ 166 ] = "Layer cloud amount in SWRAD (microphysics)";
   pp[ 167 ] = "Layer cloud condensed water path * amount";
   pp[ 168 ] = "Cloud emissivity * cloud fraction";
   pp[ 169 ] = "Cloud albedo * cloud fraction";
   pp[ 170 ] = "Transmissivity";
   pp[ 171 ] = "RHOKH (RHO* * CH * SURF_LAYER_WIND_SHEAR)";
   pp[ 172 ] = "RHOKM (RHO* * CD * SURF_LAYER_WIND_SHEAR)";
   pp[ 173 ] = "Probability of visibility less than 5 km";
   pp[ 174 ] = "Silhouette area of unresolved orography per unit horizontal area";
   pp[ 175 ] = "Peak to trough height of unresolved orography divided by 2 (metres)";
   pp[ 176 ] = "Latitude  (north positive)";
   pp[ 177 ] = "Longitude  (east positive)";
   pp[ 178 ] = "Sensible heat flux";
   pp[ 179 ] = "Soil heat flux";
   pp[ 180 ] = "Latent heat flux";
   pp[ 181 ] = "Bulk Richardson number";
   pp[ 182 ] = "Wind mixing energy";
   pp[ 183 ] = "CH - bulk transfer coefficient of heat";
   pp[ 184 ] = "Moisture flux";
   pp[ 185 ] = "Mass flux";
   pp[ 186 ] = "Net short wave radiation flux";
   pp[ 187 ] = "Net long wave radiation flux";
   pp[ 188 ] = "Total surface heat flux (inc. sensible+latent)";
   pp[ 189 ] = "Thermal advection";
   pp[ 190 ] = "C.A.T. probability";
   pp[ 191 ] = "Snow probability";
   pp[ 192 ] = "Boundary mixing coeffs.";
   pp[ 193 ] = "Convective heating rate";
   pp[ 194 ] = "Convective moistening rate";
   pp[ 195 ] = "Vertical momentum flux - U";
   pp[ 196 ] = "Vertical momentum flux - V";
   pp[ 197 ] = "Snow melt heating flux";
   pp[ 198 ] = "Duct height";
   pp[ 199 ] = "Duct intensity";
   pp[ 200 ] = "Downward solar";
   pp[ 201 ] = "Upward solar";
   pp[ 202 ] = "Net surface radiation flux (No sensible or latent)";
   pp[ 203 ] = "Total downward surface solar flux over sea-ice.";
   pp[ 204 ] = "Reserved for M.Mawson";
   pp[ 205 ] = "IR down";
   pp[ 206 ] = "IR up";
   pp[ 207 ] = "Clear-sky flux (type II) solar up";
   pp[ 208 ] = "Clear-sky flux (type II) solar down";
   pp[ 209 ] = "Sea-ice temperature";
   pp[ 210 ] = "Clear-sky (type II) IR up";
   pp[ 211 ] = "Clear-sky (type II) IR down";
   pp[ 212 ] = "Convective cloud base times amount";
   pp[ 213 ] = "Dilute convectively available potential energy. J/kg (or equiv. m2/s2)";
   pp[ 214 ] = "Clear-sky (type II) net shortwave flux";
   pp[ 215 ] = "Clear-sky (type II) net longwave flux";
   pp[ 216 ] = "Cloud top height (asl)  kft";
   pp[ 217 ] = "Convective cloud top times amount";
   pp[ 218 ] = "Convective cloud water";
   pp[ 219 ] = "Convective cloud condensed water path kg/m**2";
   pp[ 220 ] = "Cloud amount in a layer / at a level  (reworded 4/3/93)";
   pp[ 221 ] = "Total water condensed by convection";
   pp[ 222 ] = "Convective cloud base level-number";
   pp[ 223 ] = "Convective cloud top level-number";
   pp[ 224 ] = "Advecting u * layer thickness (pascals) = zonal mass-flux";
   pp[ 225 ] = "Advecting v * layer thickness (pascals) = meridional mass-flux";
   pp[ 226 ] = "Blocking index (Tibaldi & Molteni definition)";
   pp[ 227 ] = "EMAX from convection scheme";
   pp[ 228 ] = "Total net radiative heating";
   pp[ 229 ] = "Zonal mass-flux * temperature";
   pp[ 230 ] = "Meridional mass-flux * temperature";
   pp[ 231 ] = "Zonal mass-flux * specific humidity q";
   pp[ 232 ] = "Meridional mass-flux * specific humidity q";
   pp[ 233 ] = "Zonal mass-flux * liquid water temperature";
   pp[ 234 ] = "Meridional mass-flux * liquid water temperature";
   pp[ 235 ] = "Zonal mass-flux * total water";
   pp[ 236 ] = "Meridional mass-flux * total water";
   pp[ 237 ] = "Clear-sky (type I) solar up";
   pp[ 238 ] = "Clear-sky (type I) solar down";
   pp[ 239 ] = "Vapour pressure";
   pp[ 240 ] = "Clear-sky (type I) IR up";
   pp[ 241 ] = "Clear-sky (type I) IR down";
   pp[ 242 ] = "Probability of precipitation";
   pp[ 243 ] = "Clear-sky (type I) net shortwave flux";
   pp[ 244 ] = "Clear-sky (type I) net longwave flux";
   pp[ 245 ] = "Clear-sky(type I) radiative heating";
   pp[ 246 ] = "Clear-sky(type I) short-wave radiative heating";
   pp[ 247 ] = "Clear-sky(type I) long wave radiative heating";
   pp[ 248 ] = "X component of ageostrophic wind";
   pp[ 249 ] = "Y component of ageostrophic wind";
   pp[ 250 ] = "Clear-sky(type II) radiative heating";
   pp[ 251 ] = "Short-wave radiative heating";
   pp[ 252 ] = "Clear-sky(type II) ditto";
   pp[ 253 ] = "Long-wave radiative heating";
   pp[ 254 ] = "Clear-sky(type II) ditto";
   pp[ 255 ] = "Convective cloud liquid re * convective cloud weighting (full levels)";
   pp[ 256 ] = "Convective cloud weighting for microphysics (full levels)";
   pp[ 257 ] = "RHO_CD_MODV1 = rhostar*cD*modv1";
   pp[ 258 ] = "RHO_KM = rho*Km (Km = turbulent mixing coefficient for momentum)";
   pp[ 259 ] = "Atmospheric energy correction    W/m**2  (from UM 3.3)";
   pp[ 260 ] = "Sea-ice topmelt w/m2";
   pp[ 261 ] = "Sea-ice botmelt w/m2";
   pp[ 262 ] = "Fractional time of change of ice cover.";
   pp[ 263 ] = "Zonal mass-flux * u";
   pp[ 264 ] = "Meridional mass-flux * u";
   pp[ 265 ] = "Zonal mass-flux * v";
   pp[ 266 ] = "Meridional mass-flux * v";
   pp[ 267 ] = "Zonal mass-flux * geopotential";
   pp[ 268 ] = "Meridional mass-flux * geopotential";
   pp[ 269 ] = "Zonal mass-flux * moist static energy";
   pp[ 270 ] = "Meridional mass-flux * moist static energy";
   pp[ 271 ] = "Canopy water content";
   pp[ 272 ] = "Canopy condensation";
   pp[ 273 ] = "Canopy evaporation";
   pp[ 274 ] = "Canopy water throughfall";
   pp[ 275 ] = "Canopy height";
   pp[ 276 ] = "Air concentration of radioactivity Becquerels(Bq) m**-3";
   pp[ 277 ] = "Dosage of radioactivity Bq.seconds m**-3";
   pp[ 278 ] = "Dry deposition of radioactivity Bq m**-2";
   pp[ 279 ] = "Wet deposition of radioactivity Bq m**-2";
   pp[ 280 ] = "Leads;net solar radiation wm-2";
   pp[ 281 ] = "Leads;net infra-red flux  wm-2";
   pp[ 282 ] = "Leads;sensible heat flux  wm-2";
   pp[ 283 ] = "Leads;latent heat flux    wm-2";
   pp[ 284 ] = "Total deposition of radioactivity Bq m**-2";
   pp[ 285 ] = "Evap from sea * leads fraction.";
   pp[ 286 ] = "Total aerosol (micro g/kg)";
   pp[ 287 ] = "Total aerosol emissions (micro g/sq m/s)";
   pp[ 288 ] = "Visibility assimilation weights";
   pp[ 289 ] = "Visibility assimilation increment";
   pp[ 290 ] = "P* (surface pressure) weights";
   pp[ 291 ] = "Theta weights";
   pp[ 292 ] = "Wind weights";
   pp[ 293 ] = "Surface wind weights.......";
   pp[ 294 ] = "RH weights";
   pp[ 295 ] = "Precipitation rate assimilation weights";
   pp[ 296 ] = "Spare for A/C";
   pp[ 297 ] = "Spare for A/C";
   pp[ 298 ] = "Spare for A/C";
   pp[ 299 ] = "Specific layer cloud water content";
   pp[ 300 ] = "Spare for A/C";
   pp[ 301 ] = "Spare for A/C";
   pp[ 302 ] = "Spare for A/C";
   pp[ 303 ] = "P* (surface pressure) assimilation increments";
   pp[ 304 ] = "Theta assimilation increments";
   pp[ 305 ] = "u assimilation increments";
   pp[ 306 ] = "v assimilation increments";
   pp[ 307 ] = "Hydrostatic increments";
   pp[ 308 ] = "Probability of ground frost";
   pp[ 309 ] = "RH assimilation increments";
   pp[ 310 ] = "Precipitation rate assimilation increments";
   pp[ 311 ] = "Reserved for M.Mawson";
   pp[ 312 ] = "Reserved for M.Mawson";
   pp[ 313 ] = "Reserved for M.Mawson";
   pp[ 314 ] = "Reserved for M.Mawson";
   pp[ 315 ] = "Increment in q from a routine";
   pp[ 316 ] = "Increment in T from a routine";
   pp[ 317 ] = "Increment in theta from a routine";
   pp[ 318 ] = "Increment in u from a routine";
   pp[ 319 ] = "Increment in v from a routine";
   pp[ 320 ] = "Surface roughness (heat)";
   pp[ 321 ] = "Root depth";
   pp[ 322 ] = "Snow free albedo";
   pp[ 323 ] = "Surface resistance to evaporation";
   pp[ 324 ] = "Surface roughness (momentum)";
   pp[ 325 ] = "Surface capacity";
   pp[ 326 ] = "Vegetation fraction";
   pp[ 327 ] = "Veg. infilt. enhancement factor";
   pp[ 328 ] = "Deep snow albedo";
   pp[ 329 ] = "Wilting point";
   pp[ 330 ] = "Critical point";
   pp[ 331 ] = "Field capacity";
   pp[ 332 ] = "Saturation";
   pp[ 333 ] = "Saturated conductivity";
   pp[ 334 ] = "Eagleson's exponent";
   pp[ 335 ] = "Heat capacity";
   pp[ 336 ] = "Heat conductivity";
   pp[ 337 ] = "SOILB (Soil hydrology parameter BS)";
   pp[ 338 ] = "Field capacity-root depth";
   pp[ 339 ] = "Surface infilt.-infilt. factor";
   pp[ 340 ] = "Thermal inertia-(lambda C ** 1/2)";
   pp[ 341 ] = "Veg. infilt. enhancement factor * Saturated conductivity (327*333)";
   pp[ 342 ] = "Saturated soil water suction (m)";
   pp[ 343 ] = "Lowest convective cloud amount";
   pp[ 344 ] = "Lowest convective cloud base (pa)";
   pp[ 345 ] = "Lowest convective cloud top (pa)";
   pp[ 346 ] = "Lowest convective cloud base (Kft)";
   pp[ 347 ] = "Lowest convective cloud top (Kft)";
   pp[ 348 ] = "X component of Q";
   pp[ 349 ] = "Y component of Q";
   pp[ 350 ] = "DIV(Q)";
 ---------------------------------------------------------------
   pp[ 351 ] = "Wave/ Spectral wave energy component";
   pp[ 352 ] = "Wave/";

   pp[ 366 ] = "Wave/ Induced stress";
   pp[ 367 ] = "Wave/ Dependent roughness length";
   pp[ 370 ] = "Wave/ Surge induced current speed";
   pp[ 371 ] = "Wave/ Surge induced current direction";
   pp[ 372 ] = "Wave/ Tide induced water level";
   pp[ 373 ] = "Wave/ Tide induced current speed";
   pp[ 374 ] = "Wave/ Tide induced current direction";
   pp[ 375 ] = "Wave/ Mean wave height error";
   pp[ 376 ] = "Wave/ Mean wave period error";
   pp[ 377 ] = "Wave/ Mean wave speed error";
   pp[ 378 ] = "Wave/ RMS wave height error";
   pp[ 379 ] = "Wave/ RMS wave period error";
   pp[ 380 ] = "Wave/ RMS wave speed error";
   pp[ 384 ] = "Wave/ Water temperature";
   pp[ 385 ] = "Wave/ Height of wind-driven waves";
   pp[ 386 ] = "Wave/ Height of sea swells";
   pp[ 387 ] = "Wave/ Combined wave and swell height";
   pp[ 388 ] = "Wave/ Period of wind-driven waves";
   pp[ 389 ] = "Wave/ Direction from which waves come";
   pp[ 390 ] = "Wave/ Period of sea swells";
   pp[ 391 ] = "Wave/ Direction from which swells come";
   pp[ 393 ] = "Wave/ Period of significant waves";
   pp[ 394 ] = "Wave/ Dirn. from which sig. waves come";
   pp[ 395 ] = "Wave/ Grid point type (sea/land/coast)";
   pp[ 396 ] = "Wave/ Surge induced water level";
   pp[ 397 ] = "Wave/ Wave model land/sea indicator";
 ---------------------------------------------------------------
   pp[ 401 ] = "  MA/ d(ln p)/dt";
   pp[ 402 ] = "  MA/ d(theta)/dp";
   pp[ 403 ] = "  MA/ Log(Absolute ertel pot. vorticity)";
   pp[ 404 ] = "  MA/ Sign of dq/dt";
   pp[ 405 ] = "  MA/ d(theta)/dt";
   pp[ 406 ] = "  MA/ Shortwave heating rates";
   pp[ 407 ] = "  MA/ Longwave cooling rates";
   pp[ 408 ] = "  MA/ Total radiative heating";
   pp[ 409 ] = "  MA/ Friction term in circulation budget";
   pp[ 410 ] = "  MA/ dp/d(theta)";
   pp[ 411 ] = "  MA/ Geostrophic Ertel potential vorticity";
   pp[ 412 ] = "  MA/ dq/dt advection term";
   pp[ 413 ] = "  MA/ dq/dt source term";
   pp[ 414 ] = "  MA/ Total dq/dt ie source + advection";
   pp[ 415 ] = "  MA/ d(theta)/dt";
   pp[ 416 ] = "  MA/ Absolute vorticity (interpolated)";
   pp[ 417 ] = "  MA/ Absolute vorticity*total dq/dt";
   pp[ 418 ] = "  MA/ dq/dt from Raleigh friction";

...............................................................
   pp[ 451 ] = "MAtr/ Passive tracer";
   pp[ 452 ] = "MAtr/ Nitrous oxide tracer";
   pp[ 453 ] = "MAtr/ Ozone tracer";
...............................................................
     Middle atmosphere - Chemical species for UARS (Volume mixing ratios)
   pp[ 501 ] = "MAUA/ Atmosphere tracer 1 (conventionally O3)";
   pp[ 502 ] = "MAUA/ Atmosphere tracer 2 (conventionally H2O)";
   pp[ 503 ] = "MAUA/ Atmosphere tracer 3 (conventionally CO)";
   pp[ 504 ] = "MAUA/ Atmosphere tracer 4 (conventionally CH4)";
   pp[ 505 ] = "MAUA/ Atmosphere tracer 5 (conventionally N2O)";
   pp[ 506 ] = "MAUA/ Atmosphere tracer 6 (conventionally NO)";
   pp[ 507 ] = "MAUA/ Atmosphere tracer 7 (conventionally NO2)";
   pp[ 508 ] = "MAUA/ Atmosphere tracer 8 (conventionally HNO3)";
   pp[ 509 ] = "MAUA/ Atmosphere tracer 9 (conventionally N2O5)";
   pp[ 510 ] = "MAUA/ Atmosphere tracer 10 (conventionally ClONO2)";
   pp[ 511 ] = "MAUA/ Atmosphere tracer 11 (conventionally ClO)";
   pp[ 512 ] = "MAUA/ Atmosphere tracer 12 (conventionally HCl)";
   pp[ 513 ] = "MAUA/ Atmosphere tracer 13 (conventionally CF2Cl2)";
   pp[ 514 ] = "MAUA/ Atmosphere tracer 14 (conventionally CFCl3)";
   pp[ 515 ] = "MAUA/ Atmosphere tracer 15 (conventionally HF)";
   pp[ 516 ] = "MAUA/ Atmosphere tracer 16";
   pp[ 517 ] = "MAUA/ Atmosphere tracer 17";
   pp[ 518 ] = "MAUA/ Atmosphere tracer 18";
   pp[ 519 ] = "MAUA/ Atmosphere tracer 19 (conventionally SO2)";
   pp[ 520 ] = "MAUA/ Atmosphere tracer 20 (conventionally DMS)";
   pp[ 521 ] = "MAUA/ Atmosphere tracer 21 (conventionally H2S)";
   pp[ 522 ] = "MAUA/ Atmosphere tracer 22 (conventionally WATER-SOLUBLE)";
   pp[ 523 ] = "MAUA/ Atmosphere tracer 23 (conventionally DUST-LIKE)";
   pp[ 524 ] = "MAUA/ Atmosphere tracer 24 (conventionally OCEANIC)";
   pp[ 525 ] = "MAUA/ Atmosphere tracer 25 (conventionally SOOT)";
   pp[ 526 ] = "MAUA/ Atmosphere tracer 26 (conventionally VOLCANIC ASH)";
   pp[ 527 ] = "MAUA/ Atmosphere tracer 27 (conventionally SULPHURIC ACID)";
   pp[ 528 ] = "MAUA/ Atmosphere tracer 28 (conventionally AMMONIUM SULPHATE)";
   pp[ 529 ] = "MAUA/ Atmosphere tracer 29 (conventionally MINERAL)";

   pp[ 568 ] = "MAUA/";
   pp[ 569 ] = "MAUA/ Sulphur Dioxide emissions.";
   pp[ 570 ] = "MAUA/ Dimethyl Sulphide emissions.";
   pp[ 571 ] = "MAUA/ Hydrogen Sulphide emissions.";

   pp[ 580 ] = "MAUA/ Hydroxyl radical concentration molecules cm**-3";
   pp[ 581 ] = "MAUA/ Hydrogen Peroxide concentration";

   pp[ 600 ] = "MAUA/ HO2 concentration";
 ---------------------------------------------------------------
   pp[ 601 ] = "OCtr/ Temperature.";
   pp[ 602 ] = "OCtr/ Salinity.";
   pp[ 603 ] = "OCtr/ T*";
   pp[ 604 ] = "OCtr/ Temperature at t-1.";
   pp[ 605 ] = "OCtr/ Salinity at t-1.";
   pp[ 606 ] = "OCtr/ No. deep convection points";
   pp[ 607 ] = "OCtr/ Fractional expansion of sea water (dimensionless)";
   pp[ 608 ] = "OCtr/ Sea surface elevation";
   pp[ 609 ] = "OCtr/ Density of sea water/kg m**-3";
   pp[ 610 ] = "OCtr/ Sea level rise/m";
   pp[ 611 ] = "OCtr/ Stream function.";
   pp[ 612 ] = "OCtr/ Stream function at t-1.";
   pp[ 613 ] = "OCtr/ Change of stream function across a time step.";
   pp[ 614 ] = "OCtr/ Change of stream function across previous timestep.";
   pp[ 615 ] = "OCtr/ (Formerly reciprocal of total depth at U/V points, use 715 1/1/92)";
   pp[ 616 ] = "OCtr/ Number of vertical levels of ocean at T points.";
   pp[ 617 ] = "Octr/ rigid-lid pressure/Pa";
   pp[ 618 ] = "OCtr/ Change of vorticity across one timestep. Units s*-2 from June 1996.";
   pp[ 619 ] = "OCtr/ Vertical expansion/m of sea water.";
   pp[ 620 ] = "OCtr/ Convergence heat WM-2";
   pp[ 621 ] = "OCtr/ Equivalent ice depth.";
   pp[ 622 ] = "OCtr/ Snow depth.";
   pp[ 623 ] = "OCtr/ Snowfall.";
   pp[ 624 ] = "OCtr/ Sublimation.";
   pp[ 625 ] = "OCtr/ Net solar heat flux.";
   pp[ 626 ] = "OCtr/ Net surface heat flux (HTN).";
   pp[ 627 ] = "OCtr/ Wind mixing energy.";
   pp[ 628 ] = "OCtr/ Diffusive heat flux.";
   pp[ 629 ] = "OCtr/ Precipitation minus evaporation (PLE)";
   pp[ 630 ] = "OCtr/ Sum of net solar and net surface heating.";
   pp[ 631 ] = "OCtr/ River outflow";
   pp[ 632 ] = "OCtr/ Surface water flux * salinity / density  m s**-1";
   pp[ 633 ] = "OCtr/ x component of sea-ice/ocean surface stress (ISX)";
   pp[ 634 ] = "OCtr/ y component of sea-ice/ocean surface stress (ISY)";
   pp[ 635 ] = "OCtr/ Buoyancy/kg m**-2 s**-2";
   pp[ 636 ] = "OCtr/ Buoyancy flux/kg m**-1 s**-3";

   pp[ 640 ] = "OCtr/ Zonal heat advection.";
   pp[ 641 ] = "OCtr/ Meridional heat advection.";
   pp[ 642 ] = "OCtr/ Heating rate due to advection  K s**-1";
   pp[ 643 ] = "OCtr/ Heating rate due to diffusion  K s**-1";
   pp[ 644 ] = "OCtr/ Heating rate due to surface fluxes  K s**-1";
   pp[ 645 ] = "OCtr/ Heating rate due to mixing  K s**-1";
   pp[ 646 ] = "OCtr/ Heating rate due to filtering  K s**-1";
   pp[     ] = "OCtr/";
   pp[ 647 ] = "OCtr/ Heating rate  K s**-1";
   pp[ 648 ] = "OCtr/ Rate of change of salinity/s**-1 (UM cant control LBPROC)";
   pp[ 649 ] = "OCtr/ Climatological reference surface salinity";
   pp[ 650 ] = "OCtr/ Climatological reference sea surface temperature.";
   pp[ 651 ] = "OCtr/ Anomalous heat flux from Haney term.";
   pp[ 653 ] = "OCtr/ Mixed layer depth,type 1.";
   pp[ 654 ] = "OCtr/ Mixed layer depth,type 2.";
   pp[ 655 ] = "OCtr/ Heat content /J";
   pp[ 656 ] = "OCtr/ Latent heat content /J";

   pp[ 660 ] = "OCtr/ vertical mean vorticity forcing: advection s*-2";
   pp[ 661 ] = "OCtr/ vertical mean vorticity forcing: hor diffn s*-2";
   pp[ 662 ] = "OCtr/ vertical mean vorticity forcing: vrt diffn s*-2";
   pp[ 663 ] = "OCtr/ vertical mean vorticity forcing: coriolis s*-2";
   pp[ 664 ] = "OCtr/ vertical mean vorticity forcing: pressure s*-2";
   pp[ 665 ] = "OCtr/ Vertical integral vorticity forcing: advection cm s*-2";
   pp[ 666 ] = "OCtr/ Vertical integral vorticity forcing: hor diffn cm s*-2";
   pp[ 667 ] = "OCtr/ Vertical integral vorticity forcing: vrt diffn cm s*-2";
   pp[ 668 ] = "OCtr/ Vertical integral vorticity forcing: coriolis cm s*-2";
   pp[ 669 ] = "OCtr/ Vertical integral vorticity forcing: bottom p cm s*-2";
   pp[ 670 ] = "OCtr/ boundary profiles.";
   pp[ 671 ] = "OCtr/ anomalous heat flux.";
   pp[ 672 ] = "OCtr/ anomalous salt flux.";
   pp[ 675 ] = "OCtr/ Climatological Ice depth";
   pp[ 678 ] = "OCtr/ Anomolous sea-ice heat flux W,M2";
   pp[ 679 ] = "OCtr/ Anomalous sea-ice P-E flux kg, M2, S";
   pp[ 680 ] = "OCtr/ W (vertical velocity).";
   pp[ 681 ] = "OCtr/ Topmelt.";
   pp[ 682 ] = "OCtr/ Botmelt.";
   pp[ 683 ] = "OCtr/ Fractional ice cover.";
   pp[ 684 ] = "OCtr/ Ocean-ice heat flux.";
   pp[ 685 ] = "OCtr/ Carry heat.";
   pp[ 686 ] = "OCtr/ Carry salt.";
   pp[ 687 ] = "OCtr/ Actual ice depth.";
   pp[ 688 ] = "OCtr/ Snow depth over ice (M).";
   pp[ 689 ] = "OCtr/ Sea-ice internal pressure (usually in N.m-2)";
   pp[ 690 ] = "OCtr/ Sea-ice strength     (usually in N.m-2)";
   pp[ 692 ] = "OCtr/ Average snow depth.";
   pp[ 693 ] = "OCtr/ Average ice cover.";
   pp[ 694 ] = "OCtr/ Average O/I heat flux.";
   pp[ 698 ] = "OCtr/ Downwards solar radiation over ice";
 .................................................................
   pp[ 700 ] = "OCuv/ River run-off ocean entry point co-ordinates.";
   pp[ 701 ] = "OCuv/ Baroclinic component of zonal velocity";
   pp[ 702 ] = "OCuv/ Baroclinic component of meridional velocity";
   pp[ 703 ] = "OCuv/ Zonal velocity (total)";
   pp[ 704 ] = "OCuv/ Meridional velocity (total)";
   pp[ 711 ] = "OCuv/ Barotropic component of zonal velocity";
   pp[ 712 ] = "OCuv/ Barotropic component of meridional velocity";
   pp[ 713 ] = "OCuv/ Baroclinic x-acceleration cm s**-2";
   pp[ 714 ] = "OCuv/ Baroclinic y-acceleration cm s**-2";
   pp[ 715 ] = "OCuv/ Reciprocal of total depth";
   pp[ 717 ] = "OCuv/ Number of vertical levels of ocean at U/V points.";
   pp[ 721 ] = "OCuv/ Zonal component of windstress (TAUX)";
   pp[ 722 ] = "OCuv/ Meridional component of windstress (TAUY)";
   pp[ 728 ] = "OCuv/ x component of sea-ice velocity";
   pp[ 729 ] = "OCuv/ y component of sea-ice velocity";
   pp[ 730 ] = "OCuv/ Magnitude of sea-ice velocity";
   pp[ 731 ] = "OCuv/ Zonal component of sea-ice velocity";
   pp[ 732 ] = "OCuv/ Meridional component of sea-ice velocity";

   pp[ 740 ] = "OCuv/ Zonal mean tracer transport diagnostics";

 ..............................................................
   pp[ 801 ] = " OCE/  ocean extra tracer 1 (conventionally TCO2 )";
   pp[ 802 ] = " OCE/  ocean extra tracer 2 (conventionally alkalinity)";
   pp[ 803 ] = " OCE/  ocean extra tracer 3 (conventionally nutrient)";
   pp[ 804 ] = " OCE/  ocean extra tracer 4 (conventionally phytoplankton conc.)";
   pp[ 805 ] = " OCE/  ocean extra tracer 5 (conventionally zooplankton)";
   pp[ 806 ] = " OCE/  ocean extra tracer 6 (conventionally detritus)";
   pp[ 807 ] = " OCE/  ocean extra tracer 7 (conventionally tritium)";
   pp[ 808 ] = " OCE/  ocean extra tracer 8 (conventionally 3H+3He total mass)";
   pp[ 809 ] = " OCE/  ocean extra tracer 9 (conventionally CFC11)";
   pp[ 810 ] = " OCE/  ocean extra tracer 10 (conventionally CFC12)";
   pp[ 811 ] = " OCE/  ocean extra tracer 11 (conventionally CFC13)";
   pp[ 812 ] = " OCE/  ocean extra tracer 12 (conventionally carbon 14)";
   pp[ 813 ] = " OCE/  ocean extra tracer 13";
   pp[ 814 ] = " OCE/  ocean extra tracer 14";
   pp[ 815 ] = " OCE/  ocean extra tracer 15";
   pp[ 816 ] = " OCE/  ocean extra tracer 16";
   pp[ 817 ] = " OCE/  ocean extra tracer 17";
   pp[ 818 ] = " OCE/  ocean extra tracer 18";

   pp[ 831 ] = " OCE/ Gent and McWilliams scheme eddy u velocity (ocean)";
   pp[ 832 ] = " OCE/ Gent and McWilliams scheme eddy v velocity (N face) (ocean)";
   pp[ 833 ] = " OCE/ Gent and McWilliams scheme eddy w velocity (top face) (ocean)";
   pp[ 834 ] = " OCE/ d theta/dt from Gent and McWilliams scheme K/S";

   pp[ 840 ] = " OCE/ Total temperature advection, zonal.";
   pp[ 841 ] = " OCE/ Total temperature diffusion, zonal.";
 ..............................................................
   pp[ 850 ] = "  OA/ Surface height analysis weights";
   pp[ 851 ] = "  OA/ Mixed layer depth analysis weights";
   pp[ 852 ] = "  OA/ Surface temperature analysis weights";
   pp[ 853 ] = "  OA/ Potential temperature analysis weights";
   pp[ 854 ] = "  OA/ Salinity analysis weights";
   pp[ 855 ] = "  OA/ Velocity components analysis weights";
   pp[ 860 ] = "  OA/ Surface height analysis increments";
   pp[ 861 ] = "  OA/ Mixed layer depth analysis increments";
   pp[ 862 ] = "  OA/ Surface temperature analysis increments";
   pp[ 863 ] = "  OA/ Potential temperature analysis increments";
   pp[ 864 ] = "  OA/ Salinity analysis increments";
   pp[ 865 ] = "  OA/ Zonal velocity analysis increments";
   pp[ 870 ] = "  OA/ Meridional velocity analysis increments";
   pp[ 871 ] = "  OA/ Meridional velocity increments after surface height analysis";
   pp[ 872 ] = "  OA/ Meridional velocity increments after thermal analysis";
   pp[ 873 ] = "  OA/ Meridional velocity increments after saline analysis";
   pp[ 876 ] = "  OA/ Zonal velocity increments after surface height analysis";
   pp[ 877 ] = "  OA/ Zonal velocity increments after thermal analysis";
   pp[ 878 ] = "  OA/ Zonal velocity increments after saline analysis";
   pp[ 880 ] = "  OA/ Pressure increments after surface height analysis";
   pp[ 881 ] = "  OA/ Pressure increments after thermal analysis";
   pp[ 882 ] = "  OA/ Pressure increments after saline analysis";
   pp[ 885 ] = "  OA/ Potential temperature increments after surface height analysis";
   pp[ 888 ] = "  OA/ Saline increments after surface height analysis";
 ..............................................................
   pp[ 891 ] = " OCE/ PRIMARY PRODUCTION (GC/M2/DAY)";
   pp[ 892 ] = " OCE/ ZOOPLTN PRODUCTION (GC/M2/DAY)";
   pp[ 893 ] = " OCE/ PHYTO SPECIFIC GROWTH RATE (1/DAY)";
   pp[ 894 ] = " OCE/ PHYTO SPECIFIC GRAZING RATE (1/DAY)";
   pp[ 895 ] = " OCE/ PHYTO SPECIFIC MORTALITY (1/DAY)";
   pp[ 896 ] = " OCE/ NITRATE GAIN-EXCRETION (MMOL-N/M2/D)";
   pp[ 897 ] = " OCE/ NITRATE LOSS - GROWTH (MMOL-N/M2/D)";
   pp[ 898 ] = " OCE/ NITRATE GAIN-PHY MORT (MMOL-N/M2/D)";
   pp[ 899 ] = " OCE/ NITRATE GAIN-ZOO MORT (MMOL-N/M2/D)";
   pp[ 900 ] = " OCE/ NITRATE GAIN-PHY RESP (MMOL-N/M2/D)";
   pp[ 901 ] = " OCE/ NITRATE GAIN-REMIN    (MMOL-N/M2/D)";
   pp[ 902 ] = " OCE/ NUTRIENT LIMITATION";
   pp[ 903 ] = " OCE/ LIGHT LIMITATION";
   pp[ 904 ] = " OCE/ TEMPERATURE LIMITATION";
   pp[ 905 ] = " OCE/ DETRITUS FLUX  (MMOL-N/M2/D)";
   pp[ 906 ] = " OCE/ VERTICAL NITRATE FLUX  (MMOL-N/M2/D)";
   pp[ 907 ] = " OCE/ HORIZ NITRATE ADVECT RATE(MMOL/M3/D)";
   pp[ 908 ] = " OCE/ VERT NITRATE ADVECTN RATE(MMOL/M3/D)";
   pp[ 909 ] = " OCE/ HORIZ NITRATE DIFFUSION  (MMOL/M3/D)";
   pp[ 910 ] = " OCE/ VERT NITRATE DIFFUSION   (MMOL/M3/D)";
   pp[ 911 ] = " OCE/ NITRATE MIXING DUE TO MLM(MMOL/M3/D)";
   pp[ 912 ] = " OCE/ NITRATE CONVECTION       (MMOL/M3/D)";
   pp[ 913 ] = " OCE/ NITRATE CHANGE - BIOLOGY (MMOL/M3/D)";
   pp[ 914 ] = " OCE/ NITRATE CHANGE-RESETTING (MMOL/M3/D)";
   pp[ 915 ] = " OCE/ HORIZ PHYTO ADVECT RATE(MMOL-N/M3/D)";
   pp[ 916 ] = " OCE/ HORIZ ZOO   ADVECT RATE(MMOL-N/M3/D)";
   pp[ 917 ] = " OCE/ HORIZ DETRI ADVECT RATE(MMOL-N/M3/D)";

   pp[ 940 ] = " OCE/ Total temperature advection, meridional.";
   pp[ 941 ] = " OCE/ Total temperature diffusion, meridional.";
   pp[ 942 ] = " OCE/ Mmeridional overturning streamfunction/Sv";
 ..............................................................
 1000}
 to  } Reserved for M.Mawson
 1300}
 ..............................................................
   pp[ 1301] = " BL flux of atmospheric tracer  1 (conventionally O3)";
   pp[ 1302] = " BL flux of atmospheric tracer  2 (conventionally H2O)";
   pp[ 1303] = " BL flux of atmospheric tracer  3 (conventionally CO)";
   pp[ 1304] = " BL flux of atmospheric tracer  4 (conventionally CH4)";
   pp[ 1305] = " BL flux of atmospheric tracer  5 (conventionally N2O)";
   pp[ 1306] = " BL flux of atmospheric tracer  6 (conventionally NO)";
   pp[ 1307] = " BL flux of atmospheric tracer  7 (conventionally NO2)";
   pp[ 1308] = " BL flux of atmospheric tracer  8 (conventionally HNO3)";
   pp[ 1309] = " BL flux of atmospheric tracer  9 (conventionally N2O5)";
   pp[ 1310] = " BL flux of atmospheric tracer 10 (conventionally ClONO2)";
   pp[ 1311] = " BL flux of atmospheric tracer 11 (conventionally ClO)";
   pp[ 1312] = " BL flux of atmospheric tracer 12 (conventionally HCl)";
   pp[ 1313] = " BL flux of atmospheric tracer 13 (conventionally CF2Cl2)";
   pp[ 1314] = " BL flux of atmospheric tracer 14 (conventionally CFCl3)";
   pp[ 1315] = " BL flux of atmospheric tracer 15 (conventionally HF)";
   pp[ 1316] = " BL flux of atmospheric tracer 16";
   pp[ 1317] = " BL flux of atmospheric tracer 17";
   pp[ 1318] = " BL flux of atmospheric tracer 18";
   pp[ 1319] = " BL flux of atmospheric tracer 19 (conventionally SO2)";
   pp[ 1320] = " BL flux of atmospheric tracer 20 (conventionally DMS)";
   pp[ 1321] = " BL flux of atmospheric tracer 20 (conventionally DMS)";
   pp[ 1322] = " BL flux of atmospheric tracer 21 (conventionally H2S)";
   pp[ 1323] = " BL flux of atmospheric tracer 22 (conventionally WATER-SOLUBLE)";
   pp[ 1324] = " BL flux of atmospheric tracer 23 (conventionally DUST-LIKE)";
   pp[ 1325] = " BL flux of atmospheric tracer 24 (conventionally OCEANIC)";
   pp[ 1326] = " BL flux of atmospheric tracer 25 (conventionally SOOT)";
   pp[ 1327] = " BL flux of atmospheric tracer 26 (conventionally VOLCANIC ASH)";
   pp[ 1328] = " BL flux of atmospheric tracer 27 (conventionally SULPHURIC ACID)";
   pp[ 1329] = " BL flux of atmospheric tracer 28 (conventionally AMMONIUM SULPHATE)";
   pp[ 1330] = " BL flux of atmospheric tracer 29 (conventionally MINERAL)";
   pp[ 1331] = " BL flux of atmospheric total aerosol";
   pp[ 1332] = " Ice Possible (0- -20 Celcius, RH =>70%) 1.0=possible;0.0 not";

 .............................................................
   pp[ 1340] = "  Reserved for VAR project : B.Ingleby.";
 .
   pp[ 1369] = "  Reserved for VAR project : B.Ingleby.";
 .............................................................
   pp[ 1370] = " SO4 aerosol: Aitken mode. Units: mass mixing ratio (kg/kg)";
   pp[ 1371] = " SO4 aerosol: accumulation mode. Units: mass mixing ratio (kg/kg)";
   pp[ 1372] = " SO4 aerosol: dissolved mode. Units: mass mixing ratio (kg/kg)";
   pp[ 1373] = " SO4 aerosol: DMS mass mixing ratio";
   pp[ 1374] = " SO4 aerosol: SO2 mass mixing ratio";
   pp[ 1375] = " Methyl Sulphonic Acid mass mixing ratio kg/kg";
 1379
 .............................................................
   pp[ 1380] = " Van-Genuchten B parameter";
   pp[ 1381] = " Clapp-Hornberger B exponent";
   pp[ 1382] = " Leaf area index of vegetated fraction";
   pp[ 1383] = " Canopy height of vegetated fraction";
   pp[ 1384] = " Canopy conductance";
   pp[ 1385] = " Unfrozen soil moisture fraction";
   pp[ 1386] = " Frozen soil moisture fraction";
   pp[ 1387] = " Transpiration";
   pp[ 1388] = " Gross Primary Productivity";
   pp[ 1389] = " Net Primary Productivity";
   pp[ 1390] = " Plant Respiration";
 1391
 1392
 1393
 1394
 1395
 1396
 1397
 1398
 1399

   pp[ 1400] = "Surface dry deposition flux of SO2 kg/m2/s";
   pp[ 1401] = "Surface dry deposition flux of SO4 AITKEN mode kg/m2/s";
   pp[ 1402] = "Surface dry deposition flux of SO4 ACCUMULATION mode kg/m2/s";
   pp[ 1403] = "Surface dry deposition flux of SO4 DISSOLVED mode kg/m2/s";
   pp[ 1404] = "RESIST_B for SO2 (Note: 1400-1416 are Sulphur Cycle BL diagnostics.)";
   pp[ 1405] = "RESIST_B for SO2 AITKEN mode";
   pp[ 1406] = "RESIST_B for SO2 ACCUMULATION  mode";
   pp[ 1407] = "RESIST_B for SO2 DISSOLVED mode kg/m2/s";
   pp[ 1408] = "RESIST_S for SO2";
   pp[ 1409] = "RESIST_S for SO2 AITKEN mode";
   pp[ 1410] = "RESIST_S for SO2 ACCUMULATION mode";
   pp[ 1411] = "RESIST_S for SO2 DISSOLVED  mode";
   pp[ 1412] = "Dry deposition velocity for SO2";
   pp[ 1413] = "Dry deposition velocity for SO4 AITKEN mode";
   pp[ 1414] = "Dry deposition velocity for SO4 ACCUMULATION mode";
   pp[ 1415] = "Dry deposition velocity for SO4 DISSOLVED mode";
   pp[ 1416] = "Aerodynamic resistance 1/CDSTD after TSTEP";
   pp[ 1417] = "SO2 scavenged by convective ppn kg(S)/m2/tstep";
   pp[ 1418] = "SO4 AITKEN scavenged by convective ppn kg(S)/m2/tstep";
   pp[ 1419] = "SO4 ACCU scavenged by convective ppn kg(S)/m2/tstep";
   pp[ 1420] = "SO4 DISS scavenged by convective ppn kg(S)/m2/tstep";
   pp[ 1421] = "SO2 scavenged by large scale ppn kg(S)/m2/tstep";
   pp[ 1422] = "SO4 AITKEN scavenged by large scale ppn kg(S)/m2/tstep";
   pp[ 1423] = "SO4 ACCU scavenged by large scale ppn kg(S)/m2/tstep";
   pp[ 1424] = "SO4 DISS scavenged by large scale ppn kg(S)/m2/tstep";
 1425

 ..............................................................
   pp[ 1600] = "net surface water flux/kg m**-2 s**-1";
 ..............................................................
  Glossary:-
  Glossary: RHOSTAR  surface density of air
  Glossary: CD = transfer coefficient for 172
...............................................................
