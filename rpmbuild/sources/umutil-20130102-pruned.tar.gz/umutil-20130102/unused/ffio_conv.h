#if !defined(FFIO_CONV_HDR)
#define FFIO_CONV_HDR

#include "util.h"

#ifdef _CRAY
#include <fortran.h>
typedef _fcd fpchar;
#else
typedef char *fpchar;
#endif

#ifndef TRUE
#define TRUE 1
#endif
#ifndef FALSE
#define FALSE 0
#endif

#ifdef LONG64
#define ZERO64 0l
#else
#define ZERO64 0ll
#endif 

#if _FILE_OFFSET_BITS == 64 || defined _LARGE_FILES
#define ftell ftello
#define fseek fseeko
#endif

#if __FORT_SYMBOL == _FS_UC
#define openff  OPENFF
#define closeff CLOSEFF
#define abortff ABORTFF
#define rdblki  RDBLKI
#define rdblkp  RDBLKP
#define rdblkr  RDBLKR
#define wrtblki WRTBLKI
#define wrtblkp WRTBLKP
#define wrtblkr WRTBLKR
#define skip    SKIP
#define fcopy   FCOPY
#elif __FORT_SYMBOL == _FS_LC_
#define openff  openff_
#define closeff closeff_
#define abortff abortff_
#define rdblki  rdblki_
#define rdblkp  rdblkp_
#define rdblkr  rdblkr_
#define wrtblki wrtblki_
#define wrtblkp wrtblkp_
#define wrtblkr wrtblkr_
#define skip    skip_
#define fcopy   fcopy_
#endif

#define BUFSIZE 4096
#define MAXFILESIZE 257

/* definition of file information structure */

typedef struct finfo_st {
	char     fname[MAXFILESIZE];   /* file name */
        char     ftype[4];             /* file type */
        FILE     *fp;                  /* file identifier */
} FILEINFO;

void openff(FILEINFO **, fpchar, fpchar, fpchar, int, int, int);
void closeff(FILEINFO **);
void abortff(FILEINFO **);
void rdblki(INTEGER *, INTEGER *, INTEGER *, FILEINFO **, OFFSET * , INTEGER *);
void rdblkp(INTEGER *, INTEGER *, INTEGER *, FILEINFO **, OFFSET * , INTEGER *);
void rdblkr(REAL *, INTEGER *, INTEGER *, FILEINFO **, OFFSET *, INTEGER *);
void wrtblki(INTEGER *, INTEGER *, INTEGER *, FILEINFO **, OFFSET *);
void wrtblkp(INTEGER *, INTEGER *, INTEGER *, FILEINFO **, OFFSET *);
void wrtblkr(REAL *, INTEGER *, INTEGER *, FILEINFO **, OFFSET *);
void skip(FILEINFO **, OFFSET *, OFFSET *);
void fcopy(FILE ** , FILE **);

#endif
