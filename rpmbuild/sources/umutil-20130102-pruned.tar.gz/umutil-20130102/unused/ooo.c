#include <stdio.h>
#include "util.h"

typedef unsigned int uint32;
typedef double float64;

#define CSIGNMASK1 0x80000000  /* Mask to get 1st of 32 bits */
#define CBIAS      040000      /* Cray f.p. exponent bias */

void expand21_r81(long *n, void *in, void *out, long *nexp);

int main ()
{
  int ii;
  long n=1, nexp=6;
  float64 xx;

  ii = 0xDE728853;

  expand21_r81(&n,&ii,&xx,&nexp);

  printf("xx = %f \n",xx);

  ii = 0;

  expand21_r81(&n,&ii,&xx,&nexp);

  printf("xx = %f \n",xx);

  return 0;
}

void expand21_r81(long *n, void *in, void *out, long *nexp)
{
  int i, bias;
  uint32 *lin, crayword[2];
  uint32 cexp, pexp, sign, pfrac;
  uint32 mask1, mask2, mask3, mask4;
  float64 *lout;

  swap_bytes(in, 4, *n);

  lin = (uint32 *) in;
  lout = (float64 *) out;
  bias = pow(2.0,(double) *nexp-1);
  mask1 = ~(~0 << *nexp);
  mask2 = ~(~0 << (31-*nexp));
  mask3 = ~(~0 << 16);
  mask4 = ~(~0 << (15-*nexp));

  for (i = 0; i < *n; i++, lin++, lout++)
  {
     sign = *lin & CSIGNMASK1;    /* sign bit */

     /* Calculate packed unbiased exponent and Cray unbiased exponent */

     pexp = (*lin >> (31-*nexp)) & mask1;
     cexp = pexp - bias + CBIAS;

     /* Calculate packed fraction */

     pfrac = *lin & mask2;

     /* Calculate 64 bit cray word stored as 2 32 bit integers */

     crayword[0] = sign | (cexp << 16) | ((pfrac >> (15-*nexp)) & mask3);
     crayword[1] = (pfrac & mask4) << (17+*nexp);

     /* Calculate 64 bit IEEE word */

     swap_bytes(crayword, 4, 2);
     c8_to_r8(crayword, lout, 1);
  }

  swap_bytes(in, 4, *n);
}
