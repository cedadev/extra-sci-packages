#include <stdio.h>

int main ()
{
  int i;
  short ii;
  double y;

  y = -999.999;
  i = 0xbf82000000000000;
  ibmr4_to_r8(&i,&y,1,0);
  printf("i = %llx %lld y = %16.12f\n",i,i,y);

  i = 0xb82200000001b410;
  ibmr4_to_r8(&i,&y,1,0);
  printf("i = %llx %lld y = %16.12f\n",i,i,y);

  i = 0xC018200000000000;
  ibmr4_to_r8(&i,&y,1,0);
  printf("i = %llx %lld y = %16.12f\n",i,i,y);

  ii = 0xC0182000;
  ibmr4_to_r8(&ii,&y,1,0);
  printf("i = %x %d y = %16.12f\n",ii,ii,y);

  ii = 0xb8220000;
  ibmr4_to_r8(&ii,&y,1,0);
  printf("i = %x %d y = %16.12f\n",ii,ii,y);

  return 0;
}
