#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "util.h"

#ifdef _CRAY
#include <fortran.h>
typedef _fcd fpchar;
#else
typedef char *fpchar;
#endif

#define TRUE 1
#define FALSE 0

#ifdef LONG64
#define ZERO64 0l
#else
#define ZERO64 0ll
#endif 

#define UMFILE 1
#define PPFILE 2
#define UMFILEBS 201
#define UMFILE64 65
#define PPFILE64 66
#define UMFILE64BS 265
#define UMFILECRAY 165
#define PPFILECRAY 166
#define PPFILECRAYIEEE 167

#if defined _CRAY || defined VAX || defined IBM
#define openff  OPENFF
#define closeff CLOSEFF
#define abortff ABORTFF
#define rdblki  RDBLKI
#define rdblkp  RDBLKP
#define rdblkr  RDBLKR
#define wrtblki WRTBLKI
#define wrtblkp WRTBLKP
#define wrtblkr WRTBLKR
#define skip    SKIP
#define fcopy   FCOPY
#elif defined __sun || defined __sgi || defined __osf__ || defined __uxpv__ || defined __linux || defined _SX
#define openff  openff_
#define closeff closeff_
#define abortff abortff_
#define rdblki  rdblki_
#define rdblkp  rdblkp_
#define rdblkr  rdblkr_
#define wrtblki wrtblki_
#define wrtblkp wrtblkp_
#define wrtblkr wrtblkr_
#define skip    skip_
#define fcopy   fcopy_
#endif

#define BUFSIZE 4096

void openff( FILE **, fpchar, fpchar, fpchar, int, int, int);
void closeff( FILE ** );
void abortff( FILE ** );
void rdblki( INTEGER *, INTEGER *, INTEGER *, FILE **, INTEGER *, INTEGER *);
void rdblkp( INTEGER *, INTEGER *, INTEGER *, FILE **, INTEGER *, INTEGER *);
void rdblkr( REAL *, INTEGER *, INTEGER *, FILE **, INTEGER *, INTEGER *);
void wrtblki( INTEGER *, INTEGER *, INTEGER *, FILE **, INTEGER *);
void wrtblkp( INTEGER *, INTEGER *, INTEGER *, FILE **, INTEGER *);
void wrtblkr( REAL *, INTEGER *, INTEGER *, FILE **, INTEGER *);
void skip( FILE **, INTEGER *, INTEGER *);
void fcopy( FILE ** , FILE **);

/*
  ------------------------------------------------------------------------------
*/

void openff( FILE ** unit, fpchar file, fpchar mode, fpchar type, 
             int flen, int mlen, int tlen )
{
    char *p, *cfile, *cmode, *ctype;

    /* convert fortran CHARACTERs to c chars */

#ifdef _CRAY
    flen = _fcdlen(file);
    cfile = ( char *) malloc(flen+1);
    strncpy(cfile, _fcdtocp(file), flen);
    cfile[flen] = '\0';
    mlen = _fcdlen(mode);
    cmode = ( char *) malloc(mlen+1);
    strncpy(cmode,  _fcdtocp(mode), mlen);
    cmode[mlen] = '\0';
    tlen = _fcdlen(type);
    ctype = ( char *) malloc(tlen+1);
    strncpy(ctype,  _fcdtocp(type), tlen);
    ctype[tlen] = '\0';
#else
    cfile = ( char *) malloc(flen+1);
    strncpy(cfile, file, flen);
    cfile[flen] = '\0';
    cmode = ( char *) malloc(mlen+1);
    strncpy(cmode, mode, mlen);
    cmode[mlen] = '\0';
    ctype = ( char *) malloc(tlen+1);
    strncpy(ctype, type, tlen);
    ctype[tlen] = '\0';
#endif

    /* strip trailing blanks */

    p = cfile+flen-1;
    while(*p == ' ')
    {
       *p = '\0';
       p--;
    }
    p = cmode+mlen-1;
    while(*p == ' ')
    {
       *p = '\0';
       p--;
    }
    p = ctype+tlen-1;
    while(*p == ' ')
    {
       *p = '\0';
       p--;
    }

    /* open file */

    if ((*unit = fopen(cfile, cmode)) == NULL)
    {
       printf("Error opening file %s \n",cfile);
       abort();
    }

    free (cfile);
    free (cmode);
    free (ctype);

    return;
}
/*
  ------------------------------------------------------------------------------
*/
void closeff( FILE ** unit )
{
    int istat;

    istat = fclose(*unit);
    if (istat != 0)
    {
       printf("Error closing file \n");
       abort();
    }
    return;
}
/*
  ------------------------------------------------------------------------------
*/
void abortff( FILE ** unit )
{
    int istat;

    istat = fclose(*unit);
    if (istat != 0)
       printf("Error closing file \n");
    abort();
    return;
}
/*
  ------------------------------------------------------------------------------
*/
void rdblki( INTEGER * a, INTEGER * n1, INTEGER * n2, FILE ** unit, INTEGER * pos, INTEGER * ieof )
{
    int ierr=0;
    *ieof=0;

    if ((int) *n2 == 0) return;
    if (*n2 > *n1)
    {
       printf("*** ERROR Array size = %d size of data to be read = %d \n",
              (int) *n1,(int) *n2);
       ierr=1;
    }
    if ((int) *n2 < 0)
    {
       printf("*** ERROR Negative length read requested \n");
       ierr=1;
    }
    if (ierr != 0) abortff(unit);

    *pos = *pos + *n2;
    ierr = fread(a, sizeof(INTEGER), (size_t) *n2, *unit);
    if (ierr != (int) *n2)
    {
       if ( ! feof(*unit) )
       {
          printf("Error reading file \n");
          abortff(unit);
       }
       else
          *ieof=-1;
    }
    return;
}
/*
  ------------------------------------------------------------------------------
*/
void rdblkp( INTEGER * a, INTEGER * n1, INTEGER * n2, FILE ** unit, INTEGER * pos, INTEGER * ieof )
{
    rdblki(a, n1, n2, unit, pos, ieof);
    return;
}
/*
  ------------------------------------------------------------------------------
*/
void rdblkr( REAL * a, INTEGER * n1, INTEGER * n2, FILE ** unit, INTEGER * pos, INTEGER * ieof )
{
    int ierr=0;
    *ieof=0;

    if ((int) *n2 == 0) return;
    if (*n2 > *n1)
    {
       printf("*** ERROR Array size = %d size of data to be read = %d \n",
              (int) *n1,(int) *n2);
       ierr=1;
    }
    if ((int) *n2 < 0)
    {
       printf("*** ERROR Negative length read requested \n");
       ierr=1;
    }
    if (ierr != 0) abortff(unit);

    *pos = *pos + *n2;
    ierr = fread(a, sizeof(REAL), (size_t) *n2, *unit);
    if (ierr != (int) *n2)
    {
       if ( ! feof(*unit) )
       {
          printf("Error reading file \n");
          abortff(unit);
       }
       else
          *ieof=-1;
    }
    return;
}
/*
  ------------------------------------------------------------------------------
*/
void wrtblki( INTEGER * a, INTEGER * n1, INTEGER * n2, FILE ** unit, INTEGER * pos )
{
    int ierr=0;

    if ((int) *n2 == 0) return;
    if (*n2 > *n1)
    {
       printf("*** ERROR Array size = %d size of data to be written = %d \n",
              (int) *n1,(int) *n2);
       ierr=1;
    }
    if ((int) *n2 < 0)
    {
       printf("*** ERROR Negative length write requested \n");
       ierr=1;
    }
    if (ierr != 0) abortff(unit);

    *pos = *pos + *n2;
    ierr = fwrite(a, sizeof(INTEGER), (size_t) *n2, *unit);
    if (ierr != (int) *n2)
    {
       printf("Error writing file \n");
       abortff(unit);
    }
    return;
}
/*
  ------------------------------------------------------------------------------
*/
void wrtblkp( INTEGER * a, INTEGER * n1, INTEGER * n2, FILE ** unit, INTEGER * pos )
{
    wrtblki(a, n1, n2, unit, pos);
    return;
}
/*
  ------------------------------------------------------------------------------
*/
void wrtblkr( REAL * a, INTEGER * n1, INTEGER * n2, FILE ** unit, INTEGER * pos )
{
    int ierr=0;

    if ((int) *n2 == 0) return;
    if (*n2 > *n1)
    {
       printf("*** ERROR Array size = %d size of data to be written = %d \n",
              (int) *n1,(int) *n2);
       ierr=1;
    }
    if ((int) *n2 < 0)
    {
       printf("*** ERROR Negative length write requested \n");
       ierr=1;
    }
    if (ierr != 0) abortff(unit);

    *pos = *pos + *n2;
    ierr = fwrite(a, sizeof(REAL), (size_t) *n2, *unit);
    if (ierr != (int) *n2)
    {
       printf("Error writing file \n");
       abortff(unit);
    }
    return;
}
/*
  ------------------------------------------------------------------------------
*/
void skip( FILE ** unit, INTEGER * curpos, INTEGER * newpos )
{
    int istat;

/*    istat = fseek(*unit, sizeof(INTEGER) * ((long) *newpos - (long) *curpos), 
                    SEEK_CUR); */
    istat = fseek(*unit, sizeof(INTEGER) * ((long) *newpos - 1), SEEK_SET);

    if (istat != 0)
    {
       printf("Error in skip \n");
       abortff(unit);
    }
    *curpos = *newpos;
    return;
}
/*
  ------------------------------------------------------------------------------
*/
void fcopy( FILE ** inunit, FILE ** outunit)
{
/* make a copy of input file */

    char c[BUFSIZE];
    int numr, numw, istat;
    long pos;

    pos = ftell(*inunit);
    rewind(*inunit);

    while ((numr = fread(c, 1, BUFSIZE, *inunit)) == BUFSIZE)
       numw = fwrite(c, 1, BUFSIZE, *outunit);
    numw = fwrite(c, 1, numr, *outunit);

    istat = fseek(*inunit, pos, SEEK_SET);
    rewind(*outunit);

    return;
}

