#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <float.h>
#include <errno.h>
#include "/home/jeff/software/util/crayio.h"

#ifdef CRAY
typedef double real;
typedef long long integer;
#else
typedef double real;
typedef long long integer;
#endif

int ibmr4_to_r8(void *, void *, int, int);
void ieee2ibm_ (integer *, integer *, integer *, integer *, integer *,
                integer *, integer *, integer *);
void ibm2ieee_ (integer *, integer *, integer *, integer *, integer *,
                integer *, integer *, integer *);

/*

On a t3e I get this output

 -0.094238281250 C0182000  -0.094238281250

But on an sgi I get

 -0.094238281250 BF820000  -0.031738281250

*/

int main ()
{
  real x, y;
  integer *ix, *iy;
  integer type,num,i,offset_out,stride,size_num_in,size_num_out;
#ifdef CRAY
  short ii;
#else
  int ii;
#endif

  type = 3;
  num = 1;
  offset_out = 0;
  stride = 1;
  size_num_in = 64;
  size_num_out = 32;

  x = -0.094238281250;
  ix = (integer *) &x;
  iy = (integer *) &y;
  /**ix = 0x3fb738909bf22221;*/

  printf("ix = 0x%llx x = %16.12f\n",*ix,x);

  ieee2ibm_(&type,&num,&i,&offset_out,ix,&stride,&size_num_in,&size_num_out);
  ibm2ieee_(&type,&num,&i,&offset_out,iy,&stride,&size_num_in,&size_num_out);

#ifdef CRAY
  printf("%16.12f %16.16llx %lld %16.12f\n",x,i,i,y);

  CRI2IBM(&type,&num,&i,&offset_out,ix,&stride,&size_num_in,&size_num_out);
  IBM2CRI(&type,&num,&i,&offset_out,iy,&stride,&size_num_in,&size_num_out);

  printf("%16.12f %16.16lx %ld %16.12f\n",x,i,i,y);

#else
  printf("%16.12f %16.16llx %lld %16.12f\n",x,i,i,y);
#endif

  return 0;

  y = -999.999;
  i = 0xC018200000000000;
  ibmr4_to_r8(&i,&y,1,0);
  printf("i = %llx %lld y = %16.12f\n",i,i,y);

  ii = 0xC0182000;
  ibmr4_to_r8(&ii,&y,1,0);
  printf("i = %8.8x %d y = %16.12f\n",ii,ii,y);

  i = 0xbf82000000000000;
  ibmr4_to_r8(&i,&y,1,0);
  printf("i = %llx %lld y = %16.12f\n",i,i,y);

  ii = 0xbf820000;
  ibmr4_to_r8(&ii,&y,1,0);
  printf("i = %8.8x %d y = %16.12f\n",ii,ii,y);

  return 0;
}
int ibmr4_to_r8(void *in, void *out, int n, int offset)
{
#ifndef _CRAY
  unsigned char *pin;
  double *pout;
  unsigned long man;
  int err, i, exp, sign;
  double d;
  unsigned long long i64;

  pin = (unsigned char *) in;
  pout = (double *) out;

  for (i=0; i<4*offset; i++) pin++;

  err=0;

  for (i=0; i<n; i++)
  {
     sign = pin[0] & 0x80;
     exp = pin[0] & 0x7f;
     man = ((unsigned long) pin[1] << 16) | 
           ((unsigned long) pin[2] << 8) | (unsigned long) pin[3];

     d = ldexp((double) man ,4*(exp-64-6));

     printf("sign = %d exp = %d man = %lu d = %16.12f\n",sign,exp,man,d);

     if (d > (double) DBL_MAX || errno == ERANGE)
     {
        i64 = (sign ? (long long) I64_INFN : (long long) I64_INFP);
        *pout = *(double *) &i64;
        err=1;
     }
     else
        *pout = (sign ? -d : d);

     pout++;
     pin += 4;     
  }

  return err;
#else
  int err, type, bitoff, stride, intlen, extlen;

  type = 3;
  bitoff = offset*32;
  stride = 1;
  intlen = 64;
  extlen = 32;

  err = IBM2CRI(&type, &n, in, &bitoff, out, &stride, &intlen, &extlen);

  return err;
#endif
}

/****************************************************************/
/* The following global constants are required by the portable  */
/* data conversion routines.  These constants provide masks for */
/* for selectively extracting the sign, exponent and mantissa   */
/* parts from IEEE and IBM 32 and 64 bit reals and integers.    */
/* The constants are expressed here in hex format.  The         */
/* corresponding binary representations are given by the usual  */
/* relationships:                                               */
/*    0=0000, 1=0001, 2=0010,....., 9=1001, A=1010,....F=1111   */
/****************************************************************/

/* Format 1: IBM 32 bit floating point numbers                  */
#define ibm_sign_32   0x80000000
#define ibm_expo_32   0x7F000000
#define ibm_mant_32   0x00FFFFFF
#define ibm_mant_bits_32 24
#define ibm_expo_bits_32 7
#define ibm_expo_bias_32 64

/* Format 2: IBM 64 bit floating point numbers                  */
#define ibm_sign_64   0x8000000000000000LL
#define ibm_expo_64   0x7F00000000000000LL
#define ibm_mant_64   0x00FFFFFFFFFFFFFFLL
#define ibm_mant_bits_64 56
#define ibm_expo_bits_64 7
#define ibm_expo_bias_64 64

/* Format 3: IEEE 32 bit floating point numbers                 */
#define ieee_sign_32  0x80000000
#define ieee_expo_32  0x7F800000
#define ieee_mant_32  0x007FFFFF
#define ieee_mant_bits_32 23
#define ieee_expo_bits_32 8
#define ieee_expo_bias_32 127

/* Format 4: IEEE 64 bit floating point numbers                 */
#define ieee_sign_64  0x8000000000000000LL
#define ieee_expo_64  0x7FF0000000000000LL
#define ieee_mant_64  0x000FFFFFFFFFFFFFLL
#define ieee_mant_bits_64 52
#define ieee_expo_bits_64 11
#define ieee_expo_bias_64 1023

/* Format 6: IEEE 16 bit integers (two's complement)            */
#define ieee_int_sign_16  0x8000
#define ieee_int_mant_16  0x7FFF
#define ieee_int_mant_bits_16 15

/* Format 7: IEEE 32 bit integers (two's complement)            */
#define ieee_int_sign_32  0x80000000
#define ieee_int_mant_32  0x7FFFFFFF
#define ieee_int_mant_bits_32 31

/* Format 8: IEEE 64 bit integers (two's complement)            */
#define ieee_int_sign_64  0x8000000000000000LL
#define ieee_int_mant_64  0x7FFFFFFFFFFFFFFFLL
#define ieee_int_mant_bits_64 63

void
ieee2ibm_
(type, num, ibm_num_out, offset_out, cri_num_in, stride,
    size_num_in, size_num_out)
integer *type, *num, *offset_out, *stride, *size_num_in, *size_num_out;
integer ibm_num_out[], cri_num_in[];
{
/* Prototype functions */
void read_number();
void write_number();
/* local variables */
int i;
int type_num_in, type_num_out, offset;
/* Variables in calls to read/write_number */
integer sign, expo, mant, mant_bits_read;

/* Convert Cray offset to my offset */
 offset = 64 - (int) *offset_out - (int) *size_num_out;

/* Cray fortran uses IEEE data types */
/* decide which data types are used */
if ((int) *type == 2){
  switch ((int) *size_num_in){               /* IEEE integer in */
    case 16:  type_num_in = 6;  break;
    case 32:  type_num_in = 7;  break;
    case 64:  type_num_in = 8;  break;
  }
  switch ((int) *size_num_out){              /* IEEE integer out */
    case 16:  type_num_out = 6;  break;
    case 32:  type_num_out = 7;  break;
    case 64:  type_num_out = 8;  break;
  }
}
else if ((int) *type == 3){
  switch ((int) *size_num_in){               /* real IEEE in */
    case 32:  type_num_in = 3;  break;
    case 64:  type_num_in = 4;  break;
  }
  switch ((int) *size_num_out){              /* real IBM out */
    case 32:  type_num_out = 1;  break;
    case 64:  type_num_out = 2;  break;
  }
}

printf("type_num_in = %d type_num_out = %d\n",type_num_in,type_num_out);

/*else*/ /* ERROR - unsupported type */

/* Loop over all values converting them as we go along */
for (i=0; i < *num; i++){
  read_number(type_num_in, (int) *size_num_in, 0, cri_num_in[i],
            &sign, &expo, &mant, &mant_bits_read);
  printf("sign = %lld expo = %lld mant = 0x%llx mant_bits_read = %lld \n",
          sign, expo, mant, mant_bits_read);
  write_number(type_num_out, (int) *size_num_out, offset,
            &ibm_num_out[i], sign, expo, mant, mant_bits_read);
}
}

/****************************************************************/
/* The following function is to be called from Fortan.  It      */
/* provides a portable version of Cray routine IBM2CRI -        */
/* interface to read_number/write_number                        */
/****************************************************************/
void
ibm2ieee_
(type, num, ibm_num_in, offset_in, cri_num_out, stride,
size_num_out, size_num_in)
integer *type, *num, *offset_in, *stride, *size_num_in, *size_num_out;
integer ibm_num_in[], cri_num_out[];
{
/* Prototype functions */
void read_number();
void write_number();
/* Local variables */
int i;
int type_num_in, type_num_out, offset;
/* Variables in calls to read/write_number */
integer sign, expo, mant, mant_bits_read;

/* Convert Cray offset to my offset */
 offset = 64 - (int) *offset_in - (int) *size_num_in;

/* Cray fortran uses IEEE data types */
/* Decide which data types are used */
if ((int) *type == 2){
  switch ((int) *size_num_in){                  /* IEEE integer in */
    case 16:  type_num_in = 6;  break;
    case 32:  type_num_in = 7;  break;
    case 64:  type_num_in = 8;  break;
  }
  switch ((int) *size_num_out){                 /* IEEE integer out */
    case 16:  type_num_out = 6;  break;
    case 32:  type_num_out = 7;  break;
    case 64:  type_num_out = 8;  break;
  }
}
else if ((int) *type == 3){
  switch ((int) *size_num_in){                  /* real IBM in */
    case 32:  type_num_in = 1;  break;
    case 64:  type_num_in = 2;  break;
  }
  switch ((int) *size_num_out){                 /* real IEEE out */
    case 32:  type_num_out = 3;  break;
    case 64:  type_num_out = 4;  break;
  }
}
/*else*/ /* ERROR - unsupported type */

/* Loop over all values converting them as we go along */
for (i=0; i<*num; i++){
  read_number(type_num_in, (int) *size_num_in, offset, ibm_num_in[i],
                     &sign, &expo, &mant, &mant_bits_read);
  write_number(type_num_out, (int) *size_num_out, 0, &cri_num_out[i],
                      sign,  expo,  mant,  mant_bits_read);
}
}

/****************************************************************/
/* The following function is to be called from C.  It           */
/* reads in numbers of different types:                         */
/* real/integer, IBM or IEEE  with offsets/packed etc           */
/* Called from the portable data conversion routines            */
/****************************************************************/
void read_number
(format,size,offset,in_number,out_sign,out_expo,out_mant,mant_bits_read)
int format, size, offset;
integer in_number;
integer *out_sign, *out_expo, *out_mant, *mant_bits_read;
{

integer expo_bits, expo_bias;
integer sign_mask, expo_mask, mant_mask, in_number_mask;
integer one ;
int i, first_bit;

printf("read_number format = %d \n",format);

switch (format){
  case 1:
    /* format 1 IBM 32 bits */
    sign_mask =      ibm_sign_32;
    expo_mask =      ibm_expo_32;
    expo_bits =      ibm_expo_bits_32;
    expo_bias =      ibm_expo_bias_32;
    mant_mask =      ibm_mant_32;
    *mant_bits_read = ibm_mant_bits_32;
  break;

  case 2:
    /* format 2 IBM 64 bits */
    sign_mask =      ibm_sign_64;
    expo_mask =      ibm_expo_64;
    expo_bits =      ibm_expo_bits_64;
    expo_bias =      ibm_expo_bias_64;
    mant_mask =      ibm_mant_64;
    *mant_bits_read = ibm_mant_bits_64;
  break;

  case 3:
    /* format 3  IEEE 32 bits */
    sign_mask =      ieee_sign_32;
    expo_mask =      ieee_expo_32;
    expo_bits =      ieee_expo_bits_32;
    expo_bias =      ieee_expo_bias_32;
    mant_mask =      ieee_mant_32;
    *mant_bits_read = ieee_mant_bits_32;
  break;

  case 4:
    /* format 4  IEEE 64 bits */
    sign_mask =      ieee_sign_64;
    expo_mask =      ieee_expo_64;
    expo_bits =      ieee_expo_bits_64;
    expo_bias =      ieee_expo_bias_64;
    mant_mask =      ieee_mant_64;
    *mant_bits_read = ieee_mant_bits_64;
  break;

  case 6:
    /* format 6 IEEE 16 bit integers */
    sign_mask =      ieee_int_sign_16;
    mant_mask =      ieee_int_mant_16;
    *mant_bits_read = ieee_int_mant_bits_16;
    expo_bits = 0;
    expo_bias = 0;
  break;

  case 7:
    /* format 7 IEEE 32 bit integers */
    sign_mask =      ieee_int_sign_32;
    mant_mask =      ieee_int_mant_32;
    *mant_bits_read = ieee_int_mant_bits_32;
    expo_bits = 0;
    expo_bias = 0;
  break;

  case 8:
    /* format 8 IEEE 64 bit integers */
    sign_mask =      ieee_int_sign_64;
    mant_mask =      ieee_int_mant_64;
    *mant_bits_read = ieee_int_mant_bits_64;
    expo_bits = 0;
    expo_bias = 0;
  break;
}

if ( offset != 0 || size != (*mant_bits_read + expo_bits + 1)
     || (64 - offset -size != 0) ){
  /* For offsets and size differences */

  /* shift number to right and clear off any other data in string */
  in_number = in_number >> offset;
  one = 1 ;
  in_number_mask = ( (one << size) - 1 );
  in_number = in_number & in_number_mask;

  /* sign_mask */
  one = 1 ;
  sign_mask = one << (size - 1);
}


/* For all types of nos */

/* Extract 1 bit sign and remove trailing 0s*/
  *out_sign= (in_number & sign_mask) >> (*mant_bits_read + expo_bits);

/* mantissa and expo */

if ((in_number & mant_mask) == 0 && (in_number & expo_mask) == 0) {
  *out_mant = 0 ;
  *out_expo = 0 ;
}
else{
if( format == 1 || format ==2 ){

  /* IBM type numbers */

  /*  find first non-zero bit
  (up to first three leading bits could be 0 from IBM)*/
  first_bit = 0;
  for (i = 1; first_bit == 0; i++){
    if(((in_number & mant_mask) >> (*mant_bits_read - i)) & 1  == 1){
      first_bit = i;
    }
    if(i == *mant_bits_read) first_bit = *mant_bits_read;
  }

  /* shift mantissa to be of the form 1.fraction
     and scale expo appropriately */
  *out_mant = (in_number & mant_mask) << first_bit;

  /*  IBM type - scale base 16 exponent to decimal and then correct
  for normalised mantissa */

  *out_expo =((((in_number & expo_mask) >> *mant_bits_read)
                - expo_bias) * 4) - first_bit;

  /* added extra bit to mantissa forming 1.frac */
  *mant_bits_read = *mant_bits_read + 1;

}
else if(format == 3 || format == 4){

  /* IEEE floating point number */

  /* For IEEE number, add in 1 above fractional mantissa */
  one = 1 ;
  one = one << *mant_bits_read ;

  *out_mant= (in_number & mant_mask) | one ;

  /* just expo, removes trailing 0s, removes offset*/
  *out_expo= ((in_number & expo_mask) >> *mant_bits_read ) - expo_bias;

  /* mant has grown by one bit */
  *mant_bits_read = *mant_bits_read + 1;
}
else {
/* For integers */
  *out_mant = mant_mask & in_number;
  *out_expo = 0;
}
}
/* NB - DATA FROM READ TO WRITE
sign:  1 bit representing sign of mantissa 0=+, 1=-
expo:  without any offset
mantissa: explicit 1 before fraction, normalised
mant_bits_read:  no. of bits in mantissa
offset:POSITIVE, no. of bits to left integer number is offset in string
size:  bit size of number read / wrote */

}

/****************************************************************/
/* The following function is to be called from C.  It           */
/* write out numbers of different types:                        */
/* real/integer, IBM or IEEE with offsets/packed etc            */
/* Called from the portable data conversion routines            */
/****************************************************************/
void write_number
(format,size,offset,out_number,in_sign,in_expo,in_mant,mant_bits_read)
int format, size, offset;
integer *out_number;
integer in_sign, in_expo, in_mant, mant_bits_read;
{
integer mant_bits_write, expo_bits_write;
integer sign_mask, expo_mask, mant_mask;
integer sign, mant, expo, conv_number, conv_number_mask;
integer first_bit, temp;
integer one, add_one ;
integer mant_bits_diff, expo_bias;
int i, expo_diff;

printf("write_number format = %d \n",format);

switch(format){
  case 1:
    /* format 1 IBM 32 bit */
    sign= in_sign << 31;
    mant_bits_write= ibm_mant_bits_32;
    expo_bits_write= ibm_expo_bits_32;
    sign_mask= ibm_sign_32;
    expo_mask= ibm_expo_32;
    mant_mask= ibm_mant_32;
    expo_bias= ibm_expo_bias_32;
  break;

  case 2:
    /* format 2 IBM 64 bit */
    sign= in_sign << 63;
    mant_bits_write= ibm_mant_bits_64;
    expo_bits_write= ibm_expo_bits_64;
    sign_mask= ibm_sign_64;
    expo_mask= ibm_expo_64;
    mant_mask= ibm_mant_64;
    expo_bias= ibm_expo_bias_64;
  break;

  case 3:
    /* format 3 IEEE 32 bit */
    sign= in_sign << 31;
    mant_bits_write= ieee_mant_bits_32;
    expo_bits_write= ieee_expo_bits_32;
    sign_mask= ieee_sign_32;
    expo_mask= ieee_expo_32;
    mant_mask= ieee_mant_32;
    expo_bias= ieee_expo_bias_32;
  break;

  case 4:
    /* format 4 IEEE 64 bit */
    sign= in_sign << 63;
    mant_bits_write= ieee_mant_bits_64;
    expo_bits_write= ieee_expo_bits_64;
    sign_mask= ieee_sign_64;
    expo_mask= ieee_expo_64;
    mant_mask= ieee_mant_64;
    expo_bias= ieee_expo_bias_64;
  break;

  case 6:
    /* format 6 IEEE 16 bit integers */
    sign= in_sign << ieee_int_mant_bits_16;
    mant_bits_write= ieee_int_mant_bits_16;
    expo_bits_write= 0;
    expo_mask= 0;
    expo_bias= 0;
    sign_mask= ieee_int_sign_16;
    mant_mask= ieee_int_mant_16;
  break;

  case 7:
    /* format 7 IEEE 32 bit integers */
    sign= in_sign << ieee_int_mant_bits_32;
    mant_bits_write= ieee_int_mant_bits_32;
    expo_bits_write= 0;
    expo_mask= 0;
    expo_bias= 0;
    sign_mask= ieee_int_sign_32;
    mant_mask= ieee_int_mant_32;
  break;

  case 8:
    /* format 8 IEEE 64 bit integers */
    sign= in_sign << ieee_int_mant_bits_64;
    mant_bits_write= ieee_int_mant_bits_64;
    expo_bits_write= 0;
    expo_mask= 0;
    expo_bias= 0;
    sign_mask= ieee_int_sign_64;
    mant_mask= ieee_int_mant_64;
  break;

}

if ( in_mant == 0 && in_expo == 0 ) {
  mant = 0 ;
  expo = 0 ;
}
else {
/* write for real types - formats 1-4 inclusive */

if(format == 1 || format == 2){
  /* IBM numbers - reposition mantissa and re-scale expo to base 16 */

  /*  Find base 16 expo closest to but just larger than in_expo */

  if ( in_expo > -4 ) { 
    expo = in_expo/4 + 1 ;

    if (in_expo < 0) {
      /* Correct exponent for negative powers of 2 */
      expo-- ;
    }

    expo_diff = in_expo - 4*expo ;
  }
  else {
    expo = in_expo/4 ;
    expo_diff = in_expo - 4*expo ;
    if (expo_diff == 0){
      expo++ ;
      expo_diff = in_expo - 4*expo ;
    }
  }
  mant = in_mant >> ( 0 - expo_diff ) ;
  printf("in_expo = %lld expo = %lld expo_diff = %d mant = 0x%llx \n",
          in_expo,expo,expo_diff,mant);

  /* mant has shrunk back again, lose extra bit */

  mant_bits_read--;
  expo = expo + expo_bias;
  printf("expo = %lld \n",expo);

  /* Truncate/grow mantissa as appropriate to write_number format */
  mant_bits_diff = mant_bits_write - mant_bits_read;
  printf("mant_bits_diff = %lld \n",mant_bits_diff);

  /* check for rounding */
  add_one = 0 ;
  if (mant_bits_diff < 0) {
    mant = (mant >> (0 - mant_bits_diff - 1) ) ;
    if (  mant & 1  == 1 ) {
      add_one = 1 ;
    }
    mant = (mant >> 1) + add_one ;
  }
  else if(mant_bits_diff > 0) mant = ( mant << mant_bits_diff );
  else                        mant = mant;

  printf("mant = 0x%llx \n",mant);

}
else if (format == 3 || format == 4 ){

  /* For IEEE numbers knock off the 1 before the decimal -
  mantissa is only the fraction and take one from mant_bits_read, as
  it effectively shrinks one bit */

  one = 1 ;
  mant = in_mant ^ (one << (mant_bits_read - 1) );
  mant_bits_read--;

  expo = in_expo + expo_bias;

  /* truncate/grow mantissa as appropriate to write_number format */
  mant_bits_diff = mant_bits_write - mant_bits_read;

  /* check for rounding */
  add_one = 0 ;
  if (mant_bits_diff < 0) {
    mant = (mant >> (0 - mant_bits_diff - 1) ) ;
    if (  mant & 1  == 1 ) {
      add_one = 1 ;
    }
    mant = (mant >> 1) + add_one ;
  }
  else if(mant_bits_diff > 0) mant = (mant << mant_bits_diff );
  else                        mant = mant;

}

else if(format>5){

  /* Write for integer types - formats 6-8 inclusive */
  /* NB integers are written in two's complement form.
     The Most Sig Bit contains sign info (0=+).
     Neg numbers are converse of their pos opposite + 1  */

  /* Positive integers */
  first_bit=0;
  if (in_sign == 0){
    /* Find first data bit */
    for (i=1;first_bit==0;i++){
      if (( in_mant >> (mant_bits_read - i) ) & 1  == 1) first_bit = i;
      if (i == mant_bits_read) first_bit = mant_bits_read;
    }
  }

  /* Negetive integers */
  else{
    /* Find first data bit */
    temp = 0;
    for (i=1;first_bit==0;i++){
      if ( (in_mant >> (mant_bits_read - i)) < ( (temp<<1) + 1) )
          first_bit = i;
      temp = in_mant >> (mant_bits_read - i);
      if (i == mant_bits_read) first_bit = mant_bits_read;
    }
  }

  /* Shrink/truncate as appropriate */
  mant = in_mant & mant_mask;

  /* If no is negative add ones above Most Sigit Bit to fill out two's
    complement form*/
  /* Only need to fill out bits before bit 0 and bit mant_bits_read */

  if(in_sign != 0  &&  mant_bits_write > mant_bits_read){
    one = 1 ;
    mant = mant | ( ( (one << (mant_bits_write - mant_bits_read)) - 1 )
                                << mant_bits_read ) ;
    /* replace sign bit on mant */
    /* mant = mant | ( one << (mant_bits_read - 1) ); */
  }

  /* Warn if siginificant bits are lost
  mant_bits_diff = mant_bits_write - mant_bits_read;
  if ( (mant_bits_diff + first_bit) > 1) WARN
  */

  /* Null unused expo for build up number */
  expo = 0;
}
}

/* Build up converted number */
sign= sign_mask & sign;
mant= mant_mask & mant;
expo= expo_mask & (expo << (mant_bits_write) );
conv_number= sign | expo | mant;

printf("sign = 0x%llx mant = 0x%llx expo = 0x%llx conv_number  = 0x%llx\n",
        sign,mant,expo,conv_number);

/* Dealing with different sizes and offsets within the longer
   data type */
/* i.e.,  format = 32 bit int, but size = 8, offset = 8 */
/*  ----------------11111111--------  */
/*  32 bit data     8b size  8b offest
    ^ this kind of packing is used in the UM */

  if (offset != 0 || size != (mant_bits_write + expo_bits_write + 1)
      || (64 - offset - size) != 0) {
  /* create mask for converted number */
    one = 1;
    conv_number_mask = (one << size) - 1;
  }
  else {
    conv_number_mask = -1 ;
  }
  printf("conv_number_mask = 0x%llx \n",conv_number_mask);

  /* apply offset to mask and number */
  conv_number_mask = conv_number_mask << offset;
  conv_number = conv_number << offset;

  /* write in the correct place within the original string */
  *out_number = conv_number | ( *out_number & (~conv_number_mask) );

  printf("conv_number_mask = 0x%llx conv_number = 0x%llx *out_number = 0x%llx \n",
          conv_number_mask,conv_number,*out_number);

}
