#if !defined(PPIO_CONV_HDR)
#define PPIO_CONV_HDR

#include "util.h"
#include "ffio_conv.h"

#define NBYTES_PER_MARKER 4
#define marker_t int32

#if __FORT_SYMBOL == _FS_UC
#define openpp        OPENPP
#define closepp       CLOSEPP
#define abortpp       ABORTPP
#define rdreci        RDRECI
#define rdrecp        RDRECP
#define rdrecr        RDRECR
#define wrtreci       WRTRECI
#define wrtrecp       WRTRECP
#define wrtrecr       WRTRECR
#define skippp        SKIPPP
#define skiptostartpp SKIPTOSTARTPP
#define skiptoendpp   SKIPTOENDPP
#elif __FORT_SYMBOL == _FS_LC_
#define openpp        openpp_
#define closepp       closepp_
#define abortpp       abortpp_
#define rdreci        rdreci_
#define rdrecp        rdrecp_
#define rdrecr        rdrecr_
#define wrtreci       wrtreci_
#define wrtrecp       wrtrecp_
#define wrtrecr       wrtrecr_
#define skippp        skippp_
#define skiptostartpp skiptostartpp_
#define skiptoendpp   skiptoendpp_
#endif

/* definition of pp file information structure */

typedef struct ppfinfo_st {
        FILEINFO *finfo;     /* file information structure */
        OFFSET  startpos;   /* byte location of start of current record */
        OFFSET  filepos;    /* byte location of position in file */
        marker_t markerval;  /* current value of record marker */
        int      writeeor;   /* boolean value, does eor need to be written? */
} PPFILEINFO;

void openpp(PPFILEINFO **, fpchar, fpchar, fpchar, int, int, int);
void closepp(PPFILEINFO **);
void abortpp(PPFILEINFO **);
void rdreci(INTEGER *, INTEGER *, INTEGER *, 
            PPFILEINFO **, INTEGER *, INTEGER *);
void rdrecp(INTEGER *, INTEGER *, INTEGER *, 
            PPFILEINFO **, INTEGER *, INTEGER *);
void rdrecr(REAL *, INTEGER *, INTEGER *, 
            PPFILEINFO **, INTEGER *, INTEGER *);
void wrtreci(INTEGER *, INTEGER *, INTEGER *, PPFILEINFO **, INTEGER *);
void wrtrecp(INTEGER *, INTEGER *, INTEGER *, PPFILEINFO **, INTEGER *);
void wrtrecr(REAL *, INTEGER *, INTEGER *, PPFILEINFO **, INTEGER *);
void skippp(PPFILEINFO **, INTEGER *, INTEGER *);
void skiptostartpp(PPFILEINFO **);
void skiptoendpp(PPFILEINFO **);

void rdrec(void *, INTEGER *, INTEGER *, PPFILEINFO **, INTEGER *, int, int);
void write_sor_marker(PPFILEINFO *, OFFSET);
void write_eor_marker(PPFILEINFO *, OFFSET);
int getwordlen(FILEINFO *);

#endif
