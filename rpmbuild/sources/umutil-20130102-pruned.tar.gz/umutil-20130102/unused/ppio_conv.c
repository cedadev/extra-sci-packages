#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ppio_conv.h"

/*
  ------------------------------------------------------------------------------
*/

void openpp(PPFILEINFO **unit, fpchar file, fpchar mode, fpchar type, 
            int flen, int mlen, int tlen)
{
    FILEINFO *funit;

    /* Allocate memory for PPFILEINFO structure */

    if (((*unit) = (PPFILEINFO *) malloc(sizeof(PPFILEINFO))) == NULL)
    {
       printf("Error unable to allocate memory in openpp \n");
       abort();
    }

    openff(&funit, file, mode, type, flen, mlen, tlen);

    (*unit)->finfo = funit;
    (*unit)->startpos = -1;
    (*unit)->filepos = 0;
    (*unit)->markerval = -1;
    (*unit)->writeeor = FALSE;

    return;
}

/*
  ------------------------------------------------------------------------------
*/

void closepp(PPFILEINFO **unit)
{
    int ierr;
    FILEINFO *funit;
    OFFSET markerval;

    funit = (*unit)->finfo;

    if ((*unit)->writeeor)
    {
       markerval = (*unit)->filepos - (*unit)->startpos - NBYTES_PER_MARKER;
       write_eor_marker(*unit, markerval);
    }

    closeff(&funit);

    /* Free memory for PPFILEINFO structure */

    free(*unit);

    return;
}

/*
  ------------------------------------------------------------------------------
*/

void abortpp(PPFILEINFO **unit)
{
    FILEINFO *funit;

    funit = (*unit)->finfo;

    printf("Closing file %s due to program abort\n",funit->fname);

    closepp(unit);

    abort();
}

/*
  ------------------------------------------------------------------------------
*/

void rdrec(void *a, INTEGER *n1, INTEGER *n2, 
           PPFILEINFO **unit, INTEGER *ieof, int end, int type)
{
    FILEINFO *funit;
    char *ftype;
    OFFSET nbytes, pos;
    marker_t newval;
    int wordlen, ierr;
    INTEGER n22;

    funit = (*unit)->finfo;
    ftype = funit->ftype;

    if (type == 2)
       wordlen = sizeof(INTEGER);
    else
       wordlen = getwordlen(funit);
    nbytes = *n2*wordlen;
    pos = 0;
    n22 = *n2;

    if ((*unit)->filepos == 0 || 
        (*unit)->filepos == (*unit)->startpos+(*unit)->markerval+2*NBYTES_PER_MARKER)
    {
       /* Read start of record marker */

       ierr = fread(&newval, NBYTES_PER_MARKER, 1, funit->fp);
       if (ierr != 1)
       {
          if (feof(funit->fp))
          {
             *ieof = -1;
             return;
          }
          else
          {
             printf("Error reading start of record marker \n");
             perror("fread error");
             abortpp(unit);
          }
       }
       if (ftype[1] == 'S') swap_bytes(&newval, NBYTES_PER_MARKER, 1);

       (*unit)->startpos = (*unit)->filepos;
       (*unit)->filepos += NBYTES_PER_MARKER;
       (*unit)->markerval = newval;
    }

    if ((*unit)->filepos+nbytes == 
        (*unit)->startpos+(*unit)->markerval+NBYTES_PER_MARKER)
    {
       /* Reading exactly to end of record so end has to be true */

       end = TRUE;
    }
    else if ((*unit)->filepos+nbytes > 
            (*unit)->startpos+(*unit)->markerval+NBYTES_PER_MARKER)
    {
       /* Number of bytes to be read is greater than bytes remaining in
         current record, do a partial read */

       nbytes = (*unit)->startpos+(*unit)->markerval+NBYTES_PER_MARKER-
                (*unit)->filepos;
       n22 = nbytes/wordlen;
       end = TRUE;
    }

    /* Read data */

    if (type == 1)
       rdblki((INTEGER *) a, n1, &n22, &funit, &pos, ieof);
    else if (type == 2)
       rdblkp((INTEGER *) a, n1, &n22, &funit, &pos, ieof);
    else if (type == 3)
       rdblkr((REAL *) a, n1, &n22, &funit, &pos, ieof);

    if (end)
    {
       /* Position file after end of record marker */

       pos = (*unit)->startpos+(*unit)->markerval+2*NBYTES_PER_MARKER;
       ierr = fseek(funit->fp, pos, SEEK_SET);
       if (ierr != 0)
       {
          printf("Error seeking to end of current record \n");
          perror("fseek error");
          abortpp(unit);
       }
       (*unit)->filepos = pos;
    }
    else
    {
       (*unit)->filepos += nbytes;
    }
    
    return;
}

/*
  ------------------------------------------------------------------------------
*/

void rdreci(INTEGER *a, INTEGER *n1, INTEGER *n2, 
            PPFILEINFO **unit, INTEGER *ieof, INTEGER *end)
{
    int type = 1;
    int end1 = *end ? TRUE : FALSE;

    rdrec(a, n1, n2, unit, ieof, end1, type);

    return;
}

/*
  ------------------------------------------------------------------------------
*/

void rdrecp(INTEGER *a, INTEGER *n1, INTEGER *n2, 
            PPFILEINFO **unit, INTEGER *ieof, INTEGER *end)
{
    int type = 2;
    int end1 = *end ? TRUE : FALSE;

    rdrec(a, n1, n2, unit, ieof, end1, type);

    return;
}

/*
  ------------------------------------------------------------------------------
*/

void rdrecr(REAL *a, INTEGER *n1, INTEGER *n2, 
            PPFILEINFO **unit, INTEGER *ieof, INTEGER *end)
{
    int type = 3;
    int end1 = *end ? TRUE : FALSE;

    rdrec(a, n1, n2, unit, ieof, end1, type);

    return;
}

/*
  ------------------------------------------------------------------------------
*/

void wrtreci(INTEGER *a, INTEGER *n1, INTEGER *n2, 
             PPFILEINFO **unit, INTEGER *recsize)
{
    int ierr, wordlen;
    FILEINFO *funit;
    OFFSET recbytes, nbytes, pos;

    funit = (*unit)->finfo;
    nbytes = *n2*getwordlen(funit);
    pos = 0;

    if (*recsize != 0)
    {
       if (*recsize < 0)
          recbytes = nbytes;
       else
          recbytes = *recsize*getwordlen(funit);

       write_sor_marker(*unit, recbytes);
    }

    wrtblki(a, n1, n2, &funit, &pos);

    (*unit)->filepos += nbytes;
    
    return;
}

/*
  ------------------------------------------------------------------------------
*/

void wrtrecp(INTEGER *a, INTEGER *n1, INTEGER *n2, 
             PPFILEINFO **unit, INTEGER *recsize)
{
    int ierr, wordlen;
    FILEINFO *funit;
    OFFSET recbytes, nbytes, pos;

    funit = (*unit)->finfo;
    nbytes = *n2*sizeof(INTEGER);
    pos = 0;

    if (*recsize != 0)
    {
       if (*recsize < 0)
          recbytes = nbytes;
       else
          recbytes = *recsize*sizeof(INTEGER);

       write_sor_marker(*unit, recbytes);
    }

    wrtblkp(a, n1, n2, &funit, &pos);

    (*unit)->filepos += nbytes;
    
    return;
}

/*
  ------------------------------------------------------------------------------
*/

void wrtrecr(REAL *a, INTEGER *n1, INTEGER *n2, 
             PPFILEINFO **unit, INTEGER *recsize)
{
    int ierr, wordlen;
    FILEINFO *funit;
    OFFSET recbytes, nbytes, pos;

    funit = (*unit)->finfo;
    nbytes = *n2*getwordlen(funit);
    pos = 0;

    if (*recsize != 0)
    {
       if (*recsize < 0)
          recbytes = nbytes;
       else
          recbytes = *recsize*getwordlen(funit);

       write_sor_marker(*unit, recbytes);
    }

    wrtblkr(a, n1, n2, &funit, &pos);

    (*unit)->filepos += nbytes;
    
    return;
}

/*
  ------------------------------------------------------------------------------
*/

void skippp(PPFILEINFO **unit, INTEGER *nrec, INTEGER *ieof)
{
    OFFSET markerval, filepos, startpos, newpos;
    marker_t newval;
    int irec, ierr;
    FILE *fp;
    char *ftype;

    *ieof = 0;

    fp = (*unit)->finfo->fp;
    ftype = (*unit)->finfo->ftype;

    if ((*unit)->writeeor)
    {
       /* If writing to unit then write end of record marker */

       markerval = (*unit)->filepos - (*unit)->startpos - NBYTES_PER_MARKER;
       write_eor_marker(*unit, markerval);
 
       /* At end of file can't skip forward */

       if (*nrec > 0)
       {
          *ieof = -1;
          return;
       }
    }
    else if ((*unit)->startpos != -1)
    {
       /* If reading from unit skip to end of current record */

       if ((*unit)->filepos != 
           (*unit)->startpos+(*unit)->markerval+2*NBYTES_PER_MARKER)
       {
          ierr = fseek(fp, 
                       (*unit)->startpos+(*unit)->markerval+2*NBYTES_PER_MARKER,
                       SEEK_SET);
          if (ierr != 0)
          {
             printf("Error seeking to end of current record \n");
             perror("fseek error");
             abortpp(unit);
          }

          (*unit)->filepos = 
             (*unit)->startpos+(*unit)->markerval+2*NBYTES_PER_MARKER;
       }
    }

    if (*nrec == 0) return;

    startpos = (*unit)->startpos;
    filepos = (*unit)->filepos;
    markerval = (*unit)->markerval;

    if (*nrec > 0) /* skip forward nrec records */
    {
       for (irec=0; irec<*nrec; irec++)
       {
          /* Read next start of record marker */

          ierr = fread(&newval, NBYTES_PER_MARKER, 1, fp);
          if (ierr != 1)
          {
             if (feof(fp))
             {
                *ieof = -1;
                break;
             }
             else
             {
                printf("Error reading start of record marker \n");
                perror("fread error");
                abortpp(unit);
             }
          }
          if (ftype[1] == 'S') swap_bytes(&newval, NBYTES_PER_MARKER, 1);

          /* Skip to start of next record */

          ierr = fseek(fp, newval+NBYTES_PER_MARKER, SEEK_CUR);
          if (ierr != 0)
          {
             if (feof(fp))
             {
                *ieof = -1;
                break;
             }
             else
             {
                printf("Error seeking to start of next record \n");
                perror("fseek error");
                abortpp(unit);
             }
          }

          startpos = filepos;
          filepos += newval+2*NBYTES_PER_MARKER;
          markerval = newval;
       }
    }
    else if (*nrec < 0) /* skip back nrec records */
    {
       for (irec=0; irec<-*nrec; irec++)
       {
          /* Skip to end of record marker of previous record */

          newpos = filepos-markerval-3*NBYTES_PER_MARKER;

          if (newpos <= 0)
          {
             /* trying to skip beyond start of file */

             ierr = fseek(fp, (OFFSET) 0, SEEK_SET);
             if (ierr != 0)
             {
                printf("Error seeking to start of file \n");
                perror("fseek error");
                abortpp(unit);
             }

             startpos = -1;
             filepos = 0;
             markerval = -1;
             *ieof = -2;
             break;
          }

          ierr = fseek(fp, newpos, SEEK_SET);
          if (ierr != 0)
          {
             printf("Error seeking to start of previous record \n");
             perror("fseek error");
             abortpp(unit);
          }

          /* Read end of record marker for previous record */

          ierr = fread(&newval, NBYTES_PER_MARKER, 1, fp);
          if (ierr != 1)
          {
             printf("Error reading end of record marker \n");
             perror("fread error");
             abortpp(unit);
          }
          if (ftype[1] == 'S') swap_bytes(&newval, NBYTES_PER_MARKER, 1);

          filepos = newpos+NBYTES_PER_MARKER;
          markerval = newval;
          startpos = filepos-markerval-2*NBYTES_PER_MARKER;
       }
    }

    (*unit)->startpos = startpos;
    (*unit)->filepos = filepos;
    (*unit)->markerval = markerval;

    return;
}

/*
  ------------------------------------------------------------------------------
*/

void skiptostartpp(PPFILEINFO **unit)
{
    INTEGER nchunk=-1000;
    INTEGER ieof;
    int i;

    while(TRUE)
    {
       skippp(unit, &nchunk, &ieof);
       if (ieof < 0) break;
    }

    return;
}

/*
  ------------------------------------------------------------------------------
*/

void skiptoendpp(PPFILEINFO **unit)
{
    INTEGER nchunk=1000;
    INTEGER ieof;
    int i;

    while(TRUE)
    {
       skippp(unit, &nchunk, &ieof);
       if (ieof < 0) break;
    }

    return;
}

/*
  ------------------------------------------------------------------------------
*/

void write_sor_marker(PPFILEINFO *unit, OFFSET nbytes)
{
    int ierr;
    marker_t sorval;
    char *ftype;
    OFFSET markerval;

    ftype = unit->finfo->ftype;

    /* If necessary write previous end of record marker first */

    if (unit->writeeor) 
    {
       markerval = unit->filepos - unit->startpos - NBYTES_PER_MARKER;
       write_eor_marker(unit, markerval);
    }

    /* Write start of record marker */

    sorval = nbytes;
    if (ftype[1] == 'S') swap_bytes(&sorval, NBYTES_PER_MARKER, 1);

    ierr = fwrite(&sorval, NBYTES_PER_MARKER, 1, unit->finfo->fp);
    if (ierr != 1)
    {
       printf("Error writing start of record marker \n");
       perror("fwrite error");
       abortpp(&unit);
    }

    unit->startpos = unit->filepos;
    unit->filepos += NBYTES_PER_MARKER;
    unit->markerval = nbytes;
    unit->writeeor = TRUE;
}

/*
  ------------------------------------------------------------------------------
*/

void write_eor_marker(PPFILEINFO *unit, OFFSET nbytes)
{
    int ierr;
    marker_t eorval;
    char *ftype;
    FILE *fp;

    ftype = unit->finfo->ftype;
    fp = unit->finfo->fp;

    /* Write end of record marker */

    eorval = nbytes;
    if (ftype[1] == 'S') swap_bytes(&eorval, NBYTES_PER_MARKER, 1);

    ierr = fwrite(&eorval, NBYTES_PER_MARKER, 1, fp);
    if (ierr != 1)
    {
       printf("Error writing end of record marker \n");
       perror("fwrite error");
       abortpp(&unit);
    }
    unit->filepos += NBYTES_PER_MARKER;
    unit->writeeor = FALSE;

    /* If start of record marker is not equal to end of record marker 
       rewrite start of record marker */

    if (unit->markerval != nbytes)
    {
       /* Skip back to start of record marker */

       ierr = fseek(fp, unit->startpos, SEEK_SET);
       if (ierr != 0)
       {
          printf("Error seeking to start of record \n");
          perror("fseek error");
          abortpp(&unit);
       }

       /* Rewrite start of record marker */

       ierr = fwrite(&eorval, NBYTES_PER_MARKER, 1, fp);
       if (ierr != 1)
       {
          printf("Error writing start of record marker \n");
          perror("fwrite error");
          abortpp(&unit);
       }

       /* Return to current file position */

       ierr = fseek(fp, unit->filepos, SEEK_SET);
       if (ierr != 0)
       {
          printf("Error seeking to end of record \n");
          perror("fseek error");
          abortpp(&unit);
       }

       unit->markerval = nbytes;
    }
}

/*
  ------------------------------------------------------------------------------
*/

int getwordlen(FILEINFO *unit)
{
    int wordlen;

    if (unit->ftype[2] == '4')
       wordlen = 4;
    else if (unit->ftype[2] == '8')
       wordlen = 8;
    else
    {
       printf("Error unable to get wordlen, file type is %s\n",unit->ftype);
       abortff(&unit);       
    }

    return wordlen;
}
