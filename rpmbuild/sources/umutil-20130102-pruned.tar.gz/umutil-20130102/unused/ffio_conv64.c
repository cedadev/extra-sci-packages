#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "util.h"

#ifdef _CRAY
#include <fortran.h>
typedef _fcd fpchar;
#else
typedef char *fpchar;
#endif

#define TRUE 1
#define FALSE 0

#ifdef LONG64
#define ZERO64 0l
#else
#define ZERO64 0ll
#endif 

#define UMFILE 1
#define PPFILE 2
#define UMFILEBS 201
#define UMFILE64 65
#define PPFILE64 66
#define UMFILE64BS 265
#define UMFILECRAY 165
#define PPFILECRAY 166
#define PPFILECRAYIEEE 167

#if defined _CRAY || defined VAX || defined IBM
#define openff  OPENFF
#define closeff CLOSEFF
#define abortff ABORTFF
#define rdblki  RDBLKI
#define rdblkp  RDBLKP
#define rdblkr  RDBLKR
#define wrtblki WRTBLKI
#define wrtblkp WRTBLKP
#define wrtblkr WRTBLKR
#define skip    SKIP
#define fcopy   FCOPY
#elif defined __sun || defined __sgi || defined __osf__ || defined __uxpv__ || defined __linux || defined _SX
#define openff  openff_
#define closeff closeff_
#define abortff abortff_
#define rdblki  rdblki_
#define rdblkp  rdblkp_
#define rdblkr  rdblkr_
#define wrtblki wrtblki_
#define wrtblkp wrtblkp_
#define wrtblkr wrtblkr_
#define skip    skip_
#define fcopy   fcopy_
#endif

#define BUFSIZE 4096
#define MAXFILESIZE 257

/* definition of file information structure */

typedef struct finfo_st {
	char     fname[MAXFILESIZE];   /* file name */
        char     ftype[4];             /* file type */
        FILE     *fp;                  /* file identifier */
} FILEINFO;

void openff( FILEINFO **, fpchar, fpchar, fpchar, int, int, int );
void closeff( FILEINFO ** );
void abortff( FILEINFO ** );
void rdblki( int64 *, int64 *, int64 *, FILEINFO **, int64 * , int64 * );
void rdblkp( int64 *, int64 *, int64 *, FILEINFO **, int64 * , int64 * );
void rdblkr( float64 *, int64 *, int64 *, FILEINFO **, int64 *, int64 * );
void wrtblki( int64 *, int64 *, int64 *, FILEINFO **, int64 * );
void wrtblkp( int64 *, int64 *, int64 *, FILEINFO **, int64 * );
void wrtblkr( float64 *, int64 *, int64 *, FILEINFO **, int64 * );
void skip( FILEINFO **, int64 *, int64 * );
void fcopy( FILE ** , FILE ** );

/*
  ------------------------------------------------------------------------------
*/

void openff( FILEINFO ** unit, fpchar file, fpchar mode, fpchar type, 
             int flen, int mlen, int tlen )
{
    char *p, *cfile, *cmode, *ctype;
    FILE *fp;

    /* Allocate memory for FILEINFO structure */

    if (((*unit) = (FILEINFO *) malloc(sizeof(FILEINFO))) == NULL)
    {
       printf("Error unable to allocate memory in openff \n");
       abort();
    }

    /* convert fortran CHARACTERs to c chars */

#ifdef _CRAY
    flen = _fcdlen(file);
    cfile = ( char *) malloc(flen+1);
    strncpy(cfile, _fcdtocp(file), flen);
    cfile[flen] = '\0';
    mlen = _fcdlen(mode);
    cmode = ( char *) malloc(mlen+1);
    strncpy(cmode,  _fcdtocp(mode), mlen);
    cmode[mlen] = '\0';
    tlen = _fcdlen(type);
    ctype = ( char *) malloc(tlen+1);
    strncpy(ctype,  _fcdtocp(type), tlen);
    ctype[tlen] = '\0';
#else
    cfile = ( char *) malloc(flen+1);
    strncpy(cfile, file, flen);
    cfile[flen] = '\0';
    cmode = ( char *) malloc(mlen+1);
    strncpy(cmode, mode, mlen);
    cmode[mlen] = '\0';
    ctype = ( char *) malloc(tlen+1);
    strncpy(ctype, type, tlen);
    ctype[tlen] = '\0';
#endif

    /* strip trailing blanks */

    p = cfile+flen-1;
    while(*p == ' ')
    {
       *p = '\0';
       p--;
    }
    p = cmode+mlen-1;
    while(*p == ' ')
    {
       *p = '\0';
       p--;
    }
    p = ctype+tlen-1;
    while(*p == ' ')
    {
       *p = '\0';
       p--;
    }

    /* open file */

    if ((fp = fopen(cfile, cmode)) == NULL)
    {
       printf("Error opening file %s \n",cfile);
       perror("fopen error");
       abort();
    }

    (*unit)->fp = fp;
    strcpy((*unit)->fname, cfile);
    strcpy((*unit)->ftype, ctype);

    free(cfile);
    free(cmode);
    free(ctype);

    return;
}
/*
  ------------------------------------------------------------------------------
*/
void closeff( FILEINFO ** unit )
{
    int istat;

    istat = fclose((*unit)->fp);

    /* Free memory for FILEINFO structure */

    free(*unit);

    if (istat != 0)
    {
       printf("Error closing file \n");
       abort();
    }
    return;
}
/*
  ------------------------------------------------------------------------------
*/
void abortff( FILEINFO ** unit )
{
    int istat;

    istat = fclose((*unit)->fp);

    /* Free memory for FILEINFO structure */

    free(*unit);

    if (istat != 0)
       printf("Error closing file \n");
    abort();
    return;
}
/*
  ------------------------------------------------------------------------------
*/
void rdblki( int64 * a, int64 * n1, int64 * n2, FILEINFO ** unit, int64 * pos, int64 * ieof )
{
    int ierr=0, nn;
    char *ftype;
    int64 *buf64;

    *ieof=0;

    if ((int) *n2 == 0) return;
    if (*n2 > *n1)
    {
       printf("*** ERROR Array size = %d size of data to be read = %d \n",
              (int) *n1,(int) *n2);
       ierr=1;
    }
    if ((int) *n2 < 0)
    {
       printf("*** ERROR Negative length read requested \n");
       ierr=1;
    }
    if (ierr != 0) abortff(unit);

    *pos = *pos + *n2;
    ftype = (*unit)->ftype;
    if ((strcmp(ftype, "IE4") == 0) || (strcmp(ftype, "IS4") == 0))
    {
       nn = (((int) *n2)+1)/2;
       if ( (buf64 = malloc (nn*8)) == NULL )
       {
          printf("Error unable to allocate memory for buf64 in rdblki nn = %d \n", (int) nn);
          abortff(unit);
       }

       ierr = fread(buf64, 4, (size_t) *n2, (*unit)->fp);
       if (ierr != (int) *n2)
       {
          if ( ! feof((*unit)->fp) )
          {
             printf("Error reading file \n");
             abortff(unit);
          }
          else
             *ieof=-1;
       }
       if (strcmp(ftype, "IS4") == 0)
          swap_bytes(buf64, 4, (int) *n2);

#ifdef _CRAYNONIEEE
       i4_to_c8(buf64, a, (int) *n2);
#else
       i4_to_i8(buf64, a, (int) *n2);
#endif

       free(buf64);
    }
    else
    {
       ierr = fread(a, 8, (size_t) *n2, (*unit)->fp);
       if (ierr != (int) *n2)
       {
          if ( ! feof((*unit)->fp) )
          {
             printf("Error reading file \n");
             abortff(unit);
          }
          else
             *ieof=-1;
       }
#ifdef LITTLE__ENDIAN
       if (strcmp(ftype, "IS8") == 0 || strcmp(ftype, "CR8") == 0)
#else
       if (strcmp(ftype, "IS8") == 0)
#endif
          swap_bytes(a, 8, (int) *n2);
    }
    return;
}
/*
  ------------------------------------------------------------------------------
*/
void rdblkp( int64 * a, int64 * n1, int64 * n2, FILEINFO ** unit, int64 * pos, int64 * ieof )
{
    int ierr=0;
    char *ftype;

    *ieof=0;

    if ((int) *n2 == 0) return;
    if (*n2 > *n1)
    {
       printf("*** ERROR Array size = %d size of data to be read = %d \n",
              (int) *n1,(int) *n2);
       ierr=1;
    }
    if ((int) *n2 < 0)
    {
       printf("*** ERROR Negative length read requested \n");
       ierr=1;
    }
    if (ierr != 0) abortff(unit);

    ftype = (*unit)->ftype;
    if ((strcmp(ftype, "IE4") == 0) || (strcmp(ftype, "IS4") == 0))
       *pos = *pos + (*n2)*2;
    else
       *pos = *pos + *n2;

    ierr = fread(a, 8, (size_t) *n2, (*unit)->fp);
    if (ierr != (int) *n2)
    {
       if ( ! feof((*unit)->fp) )
       {
          printf("Error reading file \n");
          abortff(unit);
       }
       else
          *ieof=-1;
    }
    return;
}
/*
  ------------------------------------------------------------------------------
*/
void rdblkr( float64 * a, int64 * n1, int64 * n2, FILEINFO ** unit, int64 * pos, int64 * ieof )
{
    int ierr=0, nn;
    char *ftype;
    float64 *buf64;

    *ieof=0;

    if ((int) *n2 == 0) return;
    if (*n2 > *n1)
    {
       printf("*** ERROR Array size = %d size of data to be read = %d \n",
              (int) *n1,(int) *n2);
       ierr=1;
    }
    if ((int) *n2 < 0)
    {
       printf("*** ERROR Negative length read requested \n");
       ierr=1;
    }
    if (ierr != 0) abortff(unit);

    *pos = *pos + *n2;
    ftype = (*unit)->ftype;
    if ((strcmp(ftype, "IE4") == 0) || (strcmp(ftype, "IS4") == 0))
    {
       nn = (((int) *n2)+1)/2;
       if ( (buf64 = malloc (nn*8)) == NULL )
       {
          printf("Error unable to allocate memory for buf64 in rdblkr nn = %d \n", nn);
          abortff(unit);
       }

       ierr = fread(buf64, 4, (size_t) *n2, (*unit)->fp);
       if (ierr != (int) *n2)
       {
          if ( ! feof((*unit)->fp) )
          {
             printf("Error reading file \n");
             abortff(unit);
          }
          else
             *ieof=-1;
       }
       if (strcmp(ftype, "IS4") == 0)
          swap_bytes(buf64, 4, (int) *n2);

#ifdef _CRAYNONIEEE
       r4_to_c8(buf64, a, (int) *n2);
#else
       r4_to_r8(buf64, a, (int) *n2);
#endif

       free(buf64);
    }
#ifdef _CRAYNONIEEE
    else if ((strcmp(ftype, "IE8") == 0) || (strcmp(ftype, "IS8") == 0))
#else
    else if ((strcmp(ftype, "CR8") == 0))
#endif
    {
       if ( (buf64 = malloc ((int) *n2*8)) == NULL )
       {
          printf("Error unable to allocate memory for buf64 in rdblkr *n2 = %d \n", (int) *n2);
          abortff(unit);
       }

       ierr = fread(buf64, 8, (size_t) *n2, (*unit)->fp);
       if (ierr != (int) *n2)
       {
          if ( ! feof((*unit)->fp) )
          {
             printf("Error reading file \n");
             abortff(unit);
          }
          else
             *ieof=-1;
       }
#ifdef _CRAYNONIEEE
       if (strcmp(ftype, "IS8") == 0)
          swap_bytes(buf64, 8, (int) *n2);

       r8_to_c8(buf64, a, (int) *n2);
#else
       c8_to_r8(buf64, a, (int) *n2);
#endif

       free(buf64);
    }
    else
    {
       ierr = fread(a, 8, (size_t) *n2, (*unit)->fp);
       if (ierr != (int) *n2)
       {
          if ( ! feof((*unit)->fp) )
          {
             printf("Error reading file \n");
             abortff(unit);
          }
          else
             *ieof=-1;
       }
       if (strcmp(ftype, "IS8") == 0)
          swap_bytes(a, 8, (int) *n2);
    }
    return;
}
/*
  ------------------------------------------------------------------------------
*/
void wrtblki( int64 * a, int64 * n1, int64 * n2, FILEINFO ** unit, int64 * pos )
{
    int ierr=0, nn;
    char *ftype;
    int64 *buf64;

    if ((int) *n2 == 0) return;
    if (*n2 > *n1)
    {
       printf("*** ERROR Array size = %d size of data to be written = %d \n",
              (int) *n1,(int) *n2);
       ierr=1;
    }
    if ((int) *n2 < 0)
    {
       printf("*** ERROR Negative length write requested \n");
       ierr=1;
    }
    if (ierr != 0) abortff(unit);

    *pos = *pos + *n2;
    ftype = (*unit)->ftype;
    if ((strcmp(ftype, "IE4") == 0) || (strcmp(ftype, "IS4") == 0))
    {
       nn = (((int) *n2)+1)/2;
       if ( (buf64 = malloc (nn*8)) == NULL )
       {
          printf("Error unable to allocate memory for buf64 in wrtblki nn = %d \n", nn);
          abortff(unit);
       }

#ifdef _CRAYNONIEEE
       c8_to_i4(a, buf64, (int) *n2);
#else
       i8_to_i4(a, buf64, (int) *n2);
#endif
       if (strcmp(ftype, "IS4") == 0)
          swap_bytes(buf64, 4, (int) *n2);

       ierr = fwrite(buf64, 4, (size_t) *n2, (*unit)->fp);
       if (ierr != (int) *n2)
       {
          printf("Error reading file \n");
          abortff(unit);
       }

       free(buf64);
    }
    else
    {
#ifdef LITTLE__ENDIAN
       if (strcmp(ftype, "IS8") == 0 || strcmp(ftype, "CR8") == 0)
#else
       if (strcmp(ftype, "IS8") == 0)
#endif
          swap_bytes(a, 8, (int) *n2);

       ierr = fwrite(a, 8, (size_t) *n2, (*unit)->fp);
       if (ierr != (int) *n2)
       {
          printf("Error writing file \n");
          abortff(unit);
       }

#ifdef LITTLE__ENDIAN
       if (strcmp(ftype, "IS8") == 0 || strcmp(ftype, "CR8") == 0)
#else
       if (strcmp(ftype, "IS8") == 0)
#endif
          swap_bytes(a, 8, (int) *n2);
    }

    return;
}
/*
  ------------------------------------------------------------------------------
*/
void wrtblkp( int64 * a, int64 * n1, int64 * n2, FILEINFO ** unit, int64 * pos )
{
    int ierr=0;
    char *ftype;

    if ((int) *n2 == 0) return;
    if (*n2 > *n1)
    {
       printf("*** ERROR Array size = %d size of data to be written = %d \n",
              (int) *n1,(int) *n2);
       ierr=1;
    }
    if ((int) *n2 < 0)
    {
       printf("*** ERROR Negative length write requested \n");
       ierr=1;
    }
    if (ierr != 0) abortff(unit);

    ftype = (*unit)->ftype;
    if ((strcmp(ftype, "IE4") == 0) || (strcmp(ftype, "IS4") == 0))
       *pos = *pos + (*n2)*2;
    else
       *pos = *pos + *n2;

    ierr = fwrite(a, 8, (size_t) *n2, (*unit)->fp);
    if (ierr != (int) *n2)
    {
       printf("Error writing file \n");
       abortff(unit);
    }

    return;
}
/*
  ------------------------------------------------------------------------------
*/
void wrtblkr( float64 * a, int64 * n1, int64 * n2, FILEINFO ** unit, int64 * pos )
{
    int ierr=0, nn;
    char *ftype;
    float64 *buf64;

    if ((int) *n2 == 0) return;
    if (*n2 > *n1)
    {
       printf("*** ERROR Array size = %d size of data to be written = %d \n",
              (int) *n1,(int) *n2);
       ierr=1;
    }
    if ((int) *n2 < 0)
    {
       printf("*** ERROR Negative length write requested \n");
       ierr=1;
    }
    if (ierr != 0) abortff(unit);

    *pos = *pos + *n2;
    ftype = (*unit)->ftype;
    if ((strcmp(ftype, "IE4") == 0) || (strcmp(ftype, "IS4") == 0))
    {
       nn = (((int) *n2)+1)/2;
       if ( (buf64 = malloc (nn*8)) == NULL )
       {
          printf("Error unable to allocate memory for buf64 in wrtblkr nn = %d \n", nn);
          abortff(unit);
       }

#ifdef _CRAYNONIEEE
       c8_to_r4(a, buf64, (int) *n2);
#else
       r8_to_r4(a, buf64, (int) *n2);
#endif
       if (strcmp(ftype, "IS4") == 0)
          swap_bytes(buf64, 4, (int) *n2);

       ierr = fwrite(buf64, 4, (size_t) *n2, (*unit)->fp);
       if (ierr != *n2)
       {
          printf("Error reading file \n");
          abortff(unit);
       }

       free(buf64);
    }
#ifdef _CRAYNONIEEE
    else if ((strcmp(ftype, "IE8") == 0) || (strcmp(ftype, "IS8"))
#else
    else if ((strcmp(ftype, "CR8") == 0))
#endif
    {
       if ( (buf64 = malloc ((int) *n2*8)) == NULL )
       {
          printf("Error unable to allocate memory for buf64 in wrtblkr *n2 = %d \n", (int) *n2);
          abortff(unit);
       }

#ifdef _CRAYNONIEEE
       c8_to_r8(a, buf64, (int) *n2);
       if (strcmp(ftype, "IS8") == 0)
          swap_bytes(buf64, 8, (int) *n2);
#else
#ifdef _CRAY
       r8_to_c8(a, buf64, (int) *n2);
#else
       printf("Error cannot write CRAY numbers on this machine\n");
       abortff(unit);
#endif
#endif

       ierr = fwrite(buf64, 8, (size_t) *n2, (*unit)->fp);
       if (ierr != *n2)
       {
          printf("Error reading file \n");
          abortff(unit);
       }

       free(buf64);
    }
    else
    {
       if (strcmp(ftype, "IS8") == 0)
          swap_bytes(a, 8, (int) *n2);

       ierr = fwrite(a, 8, (size_t) *n2, (*unit)->fp);
       if (ierr != (int) *n2)
       {
          printf("Error writing file \n");
          abortff(unit);
       }

       if (strcmp(ftype, "IS8") == 0)
          swap_bytes(a, 8, (int) *n2);
    }

    return;
}
/*
  ------------------------------------------------------------------------------
*/
void skip( FILEINFO ** unit, int64 * curpos, int64 * newpos )
{
    int istat, size;
    char *ftype;

    ftype = (*unit)->ftype;
    if ((strcmp(ftype, "IE4") == 0) || (strcmp(ftype, "IS4") == 0))
       size = 4;
    else
       size = 8;

/*    istat = fseek((*unit)->fp, (long) size * ( *newpos - *curpos ), SEEK_CUR); */
    istat = fseek((*unit)->fp, size * ( *newpos - 1 ), SEEK_SET);

    if (istat != 0)
    {
       printf("Error in skip \n");
       perror("fseek error");
       abortff(unit);
    }
    *curpos = *newpos;

    return;
}
/*
  ------------------------------------------------------------------------------
*/
void fcopy( FILE ** inunit, FILE ** outunit)
{
/* make a copy of input file */

    char c[BUFSIZE];
    int numr, numw, istat;
    long pos;

    pos = ftell(*inunit);
    rewind(*inunit);

    while ((numr = fread(c, 1, BUFSIZE, *inunit)) == BUFSIZE)
       numw = fwrite(c, 1, BUFSIZE, *outunit);
    numw = fwrite(c, 1, numr, *outunit);

    istat = fseek(*inunit, pos, SEEK_SET);
    rewind(*outunit);

    return;
}
