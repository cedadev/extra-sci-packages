#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef _CRAY
#include <fortran.h>
typedef _fcd fpchar;
#else
typedef char *fpchar;
#endif

#if defined _CRAY || defined VAX || defined IBM
#define iftype   IFTYPE
#elif defined __sun || defined __sgi || defined __osf__ || defined __uxpv__ || defined __linux || defined _SX
#define iftype   iftype_
#endif

int  iftype(fpchar, int);

/*
  ------------------------------------------------------------------------------
*/
int iftype(fpchar file, int flen)
{
    char *p, *cfile;
    FILE *unit;
    int nbytes, iret, head[2];

#ifdef _CRAY
    flen = _fcdlen(file);
    cfile = ( char *) malloc(flen+1);
    strncpy(cfile, _fcdtocp(file), flen);
    cfile[flen] = '\0';
#else
    cfile = ( char *) malloc(flen+1);
    strncpy(cfile, file, flen);
    cfile[flen] = '\0';
#endif

    /* strip blanks */

    p = cfile;
    while(*p)
    {
       if (*p == ' ') *p = '\0';
       p++;
    }

    unit = fopen(cfile, "r");
    if (unit == NULL)
    {
       printf("Error opening file %s in iftype \n",cfile);
       abort();
    }

    nbytes = fread( head, sizeof(int), 2, unit);
    if ( ferror(unit) )
    {
       printf("Error reading file %s in iftype \n",cfile);
       abort();
    }
    if ( feof(unit) )
    {
       printf("End of file %s reached in iftype \n",cfile);
       abort();
    }

    if ( head[1] == 1 || head[1] == 2 )
       iret = 0;
    else
       iret = 1;
 
    if ( fclose(unit) )
    {
       printf("Error closing file %s in iftype \n",cfile);
       abort();
    }

    return iret;
}
