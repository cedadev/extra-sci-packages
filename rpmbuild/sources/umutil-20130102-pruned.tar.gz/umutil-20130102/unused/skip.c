#include <stdio.h>

void skip_(int unit, int curpos, int newpos)
{
   printf("In skip_\n");
}

void skip64_(int unit, long long curpos, long long newpos)
{
   printf("In skip64_\n");
}

