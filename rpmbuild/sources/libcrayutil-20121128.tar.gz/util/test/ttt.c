#include <stdio.h>

#define SHORT16
#define INT32
#if defined __alpha
#define LONG64
#else
#define LONG32
#define LONGLONG64
#endif

typedef short int int16;
typedef int int32;
#ifdef LONG64
typedef long int int64;
#else
typedef long long int int64;
#endif

int main ()
{
  int i;
  unsigned char buf[8];
  int16 *i16, j16[4];
  int32 *i32, j32[2];
  int64 *i64, j64[1];
  FILE *fp;

  buf[0]=0;
  buf[1]=1;
  buf[2]=2;
  buf[3]=3;
  buf[4]=4;
  buf[5]=5;
  buf[6]=6;
  buf[7]=7;

  i16 = ((int16 *) buf);
  i32 = ((int32 *) buf);
  i64 = ((int64 *) buf);

  printf("buf = ");
  for (i=0; i<8; i++)
     printf("0x%.2x ",buf[i]);
  printf("\n");

  printf("i16 = ");
  for (i=0; i<4; i++)
     printf("0x%.4x ",i16[i]);
  printf("\n");

  printf("i32 = ");
  for (i=0; i<2; i++)
     printf("0x%.8x ",i32[i]);
  printf("\n");

#ifdef LONG64
  printf("i64 = 0x%.16lx \n",i64[0]);
#else
  printf("i64 = 0x%.16llx \n",i64[0]);
#endif

  fp = fopen("sunout1","w");
  fwrite(buf, 1, 8, fp);
  fwrite(i16, 2, 4, fp);
  fwrite(i32, 4, 2, fp);
  fwrite(i64, 8, 1, fp);
  fclose(fp);

  for (i=0; i<4; i++)
     j16[i]=i16[i];
  for (i=0; i<2; i++)
     j32[i]=i32[i];
  j64[0]=i64[0];

  swap_bytes(j16, 2, 4);
  swap_bytes(j32, 4, 2);
  swap_bytes(j64, 8, 1);

  printf("j16 = ");
  for (i=0; i<4; i++)
     printf("0x%.4x ",j16[i]);
  printf("\n");

  printf("j32 = ");
  for (i=0; i<2; i++)
     printf("0x%.8x ",j32[i]);
  printf("\n");

#ifdef LONG64
  printf("j64 = 0x%.16lx \n",j64[0]);
#else
  printf("j64 = 0x%.16llx \n",j64[0]);
#endif

  return 0;
}
