#if !defined(COS_HDR)
#define COS_HDR

#ifdef _CRAY
  #include <fortran.h>
  typedef _fcd fpchar;
#else
  typedef char *fpchar;
#endif

#if defined _CRAY
  #if defined _CRAYMPP
    #define SHORT32
    #define INT64
    #define FLOAT32
  #else
    #define SHORT64
    #define INT64
    #define FLOAT64
  #endif
#else
  #define SHORT16
  #define INT32
  #define FLOAT32
#endif

#define DOUBLE64
#if defined _CRAY || defined __alpha
  #define LONG64
#else
  #define LONG32
  #define LONGLONG64
#endif

#ifdef SHORT16
  typedef short int int16;
  typedef unsigned short int uint16;
#endif
#ifdef INT32
  typedef int int32;
  typedef unsigned int uint32;
#endif
#ifdef SHORT32
  typedef short int int32;
  typedef unsigned short int uint32;
#endif
#ifdef FLOAT32
  typedef float float32;
#endif
#ifdef DOUBLE64
  typedef double float64;
#endif
#ifdef LONG64
  typedef long int int64;
  typedef unsigned long int uint64;
#else
  typedef long long int int64;
  typedef unsigned long long int uint64;
#endif

#if defined __alpha
#define LITTLE_ENDIAN
#else
#define BIG_ENDIAN
#endif

#ifdef _CRAY
  #ifndef _CRAYIEEE
    #define _CRAYNONIEEE
  #endif
#endif

#ifdef _CRAY
  #ifndef _CRAYMPP
    #define _CRAYPVP
  #endif
#endif

#define CBCW    0   /* COS block control word */
#define CEOR    010 /* COS end of record      */
#define CEOF    016 /* COS end of file        */
#define CEOD    017 /* COS end of data        */

#define CRAYWORD 8     /* Size of Cray word in bytes    */
#define BLOCKSIZE 4096 /* Size of Cray block in bytes   */
#if defined _CRAY || defined __alpha     /* Size of machine word in bytes */
#define WORDSIZE 8
#else
#define WORDSIZE 4
#endif

#define MINSEXP32  0x3f6b   /* min valid (translatable subnormal) 
                               Cray masked exponent for IEEE 32 bit f.p. */
#define MINEXP32   0x3f83   /* min valid (translatable normal) 
                               Cray masked exponent for IEEE 32 bit f.p. */
#define MAXEXP32   0x4080   /* max valid (translatable) 
                               Cray masked exponent for IEEE 32 bit f.p. */
#define MINSEXP64  0x3bce   /* min valid (translatable subnormal) 
                               Cray masked exponent for IEEE 64 bit f.p. */
#define MINEXP64   0x3c03   /* min valid (translatable normal) 
                               Cray masked exponent for IEEE 64 bit f.p. */
#define MAXEXP64   0x4400   /* max valid (translatable) 
                               Cray masked exponent for IEEE 64 bit f.p. */

#define MINCEXP    0x2003   /* min valid Cray masked exponent */
#define MAXCEXP    0x5ffe   /* max valid Cray masked exponent */

#define MINI32EXP  1        /* min valid 32 bit IEEE masked exponent */
#define MAXI32EXP  254      /* max valid 32 bit IEEE masked exponent */
#define MINI64EXP  1        /* min valid 64 bit IEEE masked exponent */
#define MAXI64EXP  2046     /* max valid 64 bit IEEE masked exponent */

#define CBIAS      040000      /* Cray f.p. exponent bias */
#define I32BIAS    0177        /* IEEE 32 bit f.p. exponent bias */
#define I64BIAS    01777       /* IEEE 64 bit f.p. exponent bias */

#define CSIGNMASK  0x80        /* Mask to get 1st of 8 bits */
#define CSIGNMASK1 0x80000000  /* Mask to get 1st of 32 bits */
#define I32_NAN    0x7fffffff
#define I32_INFP   0x7f800000
#define I32_INFN   0xff800000
#define I32_ZEROP  0x00000000
#define I32_ZERON  0x80000000
#ifdef LONG64
#define CSIGNMASK2 0x8000000000000000l  /* Mask to get 1st of 64 bits */
#define I64_NAN    0x7fffffffffffffffl
#define I64_INFP   0x7ff0000000000000l
#define I64_INFN   0xfff0000000000000l
#else
#define CSIGNMASK2 0x8000000000000000ll /* Mask to get 1st of 64 bits */
#define I64_NAN    0x7fffffffffffffffll
#define I64_INFP   0x7ff0000000000000ll
#define I64_INFN   0xfff0000000000000ll
#endif

#if defined _CRAY
#define cosopen COSOPEN
#define cosclose COSCLOSE
#define cosrewind COSREWIND
#define cosbackspace COSBACKSPACE
#define cosread COSREAD
#define swapbytes SWAPBYTES
#define c8tor4 C8TOR4
#define c8toi4 C8TOI4
#define c8tol4 C8TOL4
#define c8tor8 C8TOR8
#define c8toi8 C8TOI8
#define c8tol8 C8TOL8
#elif defined __sun || defined __sgi || defined __alpha || defined __uxpv__
#define cosopen cosopen_
#define cosclose cosclose_
#define cosrewind cosrewind_
#define cosbackspace cosbackspace_
#define cosread cosread_
#define swapbytes swapbytes_
#define c8tor4 c8tor4_
#define c8toi4 c8toi4_
#define c8tol4 c8tol4_
#define c8tor8 c8tor8_
#define c8toi8 c8toi8_
#define c8tol8 c8tol8_
#endif

/* definition of a cosfile */

typedef struct {
	char            *fname;   /* file name                         */
	FILE            *fp;      /* current file                      */
	unsigned long   fwi;      /* forward index of current bcw/rcw  */
	unsigned long   pri;      /* backward index of current bcw/rcw */
} COSFILE;

/* Routines callable from C */

COSFILE *cos_open (char *, char *);
int cos_close (COSFILE *);
int cos_rewind (COSFILE *);
int cos_backspace (COSFILE *);
int cos_read (COSFILE *, void *, int, int *);
void swap_bytes(void *, int, int);
int c8_to_r4(void *, void *, int);
int c8_to_i4(void *, void *, int);
int c8_to_l4(void *, void *, int);
int c8_to_r8(void *, void *, int);
int c8_to_i8(void *, void *, int);
int c8_to_l8(void *, void *, int);

/* Routines callable from Fortran */

void cosopen (COSFILE **, fpchar, fpchar, int *, long, long);
void cosclose (COSFILE **, int *);
void cosrewind (COSFILE **, int *);
void cosbackspace (COSFILE **, int *);
void cosread (COSFILE **, void *, int *, int *, int *);
void swapbytes(void *, int *, int *);
void c8tor4(void *, void *, int *, int *);
void c8toi4(void *, void *, int *, int *);
void c8tol4(void *, void *, int *, int *);
void c8tor8(void *, void *, int *, int *);
void c8toi8(void *, void *, int *, int *);
void c8tol8(void *, void *, int *, int *);
#ifdef _CRAY
int CRY2CRI(int *, int *, void *, int *, void *, int *, int *, int *);
#endif

#endif
