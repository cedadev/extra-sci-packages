#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "util.h"

#define _NO_PBGET

#ifdef _CRAY
#include <fortran.h>
typedef _fcd fpchar;
#else
typedef char *fpchar;
#endif

#if _INT_SIZE == 8      /* Size of machine word in bytes */
#define WORDSIZE 8
#else
#define WORDSIZE 4
#endif

#if __FORT_SYMBOL == _FS_UC
#define rdhead RDHEAD
#define pbget PBGET
#elif __FORT_SYMBOL == _FS_LC_
#define rdhead rdhead_
#define pbget pbget_
#endif

#if defined __alpha || _MIPS_SZLONG == 64 || defined __64BIT__ || defined _LP64 || defined __LP64__
#define long int
#endif

void rdhead(fpchar , fpchar , INTEGER *, long , long );
#ifndef _NO_PBGET
void pbget(FILE ** , char * , INTEGER *, INTEGER *, INTEGER * );

static long file_read(char *, long , void *);
long readprod( char *, char * , long * , 
               long (*read_func)(char *, long , void *), void * );
#endif
/*
  ------------------------------------------------------------------------------
*/
void rdhead(fpchar file, fpchar head, INTEGER *offset, long flen, long hlen)
/*
    Called as a FORTRAN subroutine:

      CALL RDHEAD(FILE,HEAD,OFFSET)

      file       = input grib filename
      head       = to contain grib header
      offset     = byte offset to extract header

*/
{
    char *p, *cfile, *chead;
    FILE *unit;
    int nbytes, ierr;

#ifdef _CRAY
    flen = _fcdlen(file);
    cfile = ( char *) malloc(flen+1);
    strncpy(cfile, _fcdtocp(file), flen);
    cfile[flen] = '\0';
    hlen = _fcdlen(head);
#else
    cfile = ( char *) malloc(flen+1);
    strncpy(cfile, file, flen);
    cfile[flen] = '\0';
#endif

    /* strip blanks */

    p = cfile;
    while(*p)
    {
       if (*p == ' ') *p = '\0';
       p++;
    }

    unit = fopen(cfile, "r");
    if (unit == NULL)
    {
       printf("Error opening file %s in rdhead \n",cfile);
       abort();
    }

    chead = ( char *) malloc(hlen+1);

    fseek( unit, *offset, SEEK_SET);
    nbytes = fread( chead, 1, hlen, unit);
    if ( ferror(unit) )
    {
       printf("Error reading file %s in rdhead \n",cfile);
       abort();
    }
    if ( feof(unit) )
    {
       printf("End of file %s reached in rdhead \n",cfile);
       abort();
    }

    ierr = fclose(unit);
    if (ierr != 0)
    {
       printf("Error closing file %s in rdhead \n",cfile);
       abort();
    }

#ifdef _CRAY
    strncpy(_fcdtocp(head), chead, hlen);
#else
    strncpy(head, chead, hlen);
#endif
    
    return;
}
#ifndef _NO_PBGET
/*
  ------------------------------------------------------------------------------
*/
void pbget(FILE ** stream, char * buffer, INTEGER * buffsize, 
           INTEGER * readsize, INTEGER * status)
/*
    Called as a FORTRAN subroutine:

        CALL PBGET( KUNIT, KARRAY, KINLEN, KOUTLEN, IRET )

    stream        = file pointer returned from PBOPEN

    buffer        = buffer big enough to hold the product

    buffsize      = size of the buffer on input

    readsize      = size in BYTES of the product read. 
                    If the end-of-file is hit, the value is returned 
                    unchanged (ie. when the function return code is -1).

    status:

        0  if a product has been successfully read

       -1  if end-of-file is hit before a product is read

       -2  if there is an error in the file-handling 
           (eg. if the file contains a truncated product)

       -3  if the size of buffer is not sufficient for the product

*/
{
long length;
long holdsize = *buffsize;
int j;

    length =  readnext(buffer, &holdsize, file_read, *stream);
    *readsize = (INTEGER) abs( holdsize );

    if (length == 0)
    {
         /* Fill up remaining bits of word with 0's */

         if ( *readsize % WORDSIZE != 0 ) 
            for ( j=0; j < WORDSIZE - (*readsize % WORDSIZE); j++)
                buffer[*readsize+j]=0; 
    }

    return;

}
/*
  ------------------------------------------------------------------------------
*/
static long file_read(char * buff, long leng, void * file)
/*    
    buff = buffer to fill,
    leng = size of buff in bytes,
    file = FILE *.

    Returns the number of bytes read.
    On EOF, returns negative value for number of bytes read .
*/
{
long nbytes;

    nbytes = (long) fread( buff, 1, leng, (FILE *) file);

/* If EOF, return negative number of bytes read */

    if ( feof((FILE *) file ) )
    {
        clearerr( (FILE *) file );
        return (-nbytes);
    }

    return nbytes;
}
#endif
