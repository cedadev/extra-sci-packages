#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "util.h"

#ifdef _CRAY
#include <fortran.h>
typedef _fcd fpchar;
#else
typedef char *fpchar;
#endif

#if __FORT_SYMBOL == _FS_UC
#define icopy   ICOPY
#define imove   IMOVE
#define idel    IDEL
#define isyscom ISYSCOM
#define pabort  PABORT
#elif __FORT_SYMBOL == _FS_LC_
#define icopy   icopy_
#define imove   imove_
#define idel    idel_
#define isyscom isyscom_
#define pabort  pabort_
#endif

#define BUFSIZE 4096

/*
    Copy file infile to a new file outfile

    Called as a FORTRAN function:

      ISTAT = ICOPY(INFILE,OUTFILE)
*/
INTEGER icopy( fpchar, fpchar, long, long );
/*
    Move file infile to file outfile

    Called as a FORTRAN function:

      ISTAT = IMOVE(INFILE,OUTFILE)
*/
INTEGER imove( fpchar, fpchar, long, long );
/*
    Delete file

    Called as a FORTRAN function:

      ISTAT = IDEL(FILE)
*/
INTEGER idel( fpchar, long );
/*
    Run system command

    Called as a FORTRAN function:

      ISTAT = ISYSCOM(COMMAND)
*/
INTEGER isyscom( fpchar, long );
/*
    Abort program

    Called as a FORTRAN subroutine:

      CALL PABORT()
*/
void pabort( void );

INTEGER icopy( fpchar infile, fpchar outfile, long flen1, long flen2)
{
    char *p, *cinfile, *coutfile;
    FILE *inunit, *outunit;
    char c[BUFSIZE];
    int numr, numw, istat;

    /* convert Fortran characters to c chars */

#ifdef _CRAY
    flen1 = _fcdlen(infile);
    cinfile = ( char *) malloc(flen1+1);
    strncpy(cinfile, _fcdtocp(infile), flen1);
    cinfile[flen1] = '\0';
    flen2 = _fcdlen(outfile);
    coutfile = ( char *) malloc(flen2+1);
    strncpy(coutfile, _fcdtocp(outfile), flen2);
    coutfile[flen2] = '\0';
#else
    cinfile = ( char *) malloc(flen1+1);
    strncpy(cinfile, infile, flen1);
    cinfile[flen1] = '\0';
    coutfile = ( char *) malloc(flen2+1);
    strncpy(coutfile, outfile, flen2);
    coutfile[flen2] = '\0';
#endif

    /* strip trailing blanks */

    p = cinfile+flen1-1;
    while(*p == ' ')
    {
       *p = '\0';
       p--;
    }
    p = coutfile+flen2-1;
    while(*p == ' ')
    {
       *p = '\0';
       p--;
    }

    /* open files */

    inunit = fopen(cinfile, "r");
    if (inunit == NULL)
    {
       printf("Error opening file %s in fcopy \n",cinfile);
       return ((INTEGER) 1);
    }
    outunit = fopen(coutfile, "w");
    if (outunit == NULL)
    {
       printf("Error opening file %s in fcopy \n",coutfile);
       return ((INTEGER) 1);
    }

    /* make a copy of input file */

    while ((numr = fread(c, 1, BUFSIZE, inunit)) == BUFSIZE)
       numw = fwrite(c, 1, BUFSIZE, outunit);
    numw = fwrite(c, 1, numr, outunit);

    /* close files */

    istat = fclose(inunit);
    if (istat != 0)
    {
       printf("Error closing file %s in fcopy \n",cinfile);
       return ((INTEGER) istat);
    }
    istat = fclose(outunit);
    if (istat != 0)
    {
       printf("Error closing file %s in fcopy \n",coutfile);
       return ((INTEGER) istat);
    }

    return ((INTEGER) 0);
}

INTEGER imove( fpchar infile, fpchar outfile, long flen1, long flen2)
{
    char *p, *cinfile, *coutfile;

    /* convert Fortran characters to c chars */

#ifdef _CRAY
    flen1 = _fcdlen(infile);
    cinfile = ( char *) malloc(flen1+1);
    strncpy(cinfile, _fcdtocp(infile), flen1);
    cinfile[flen1] = '\0';
    flen2 = _fcdlen(outfile);
    coutfile = ( char *) malloc(flen2+1);
    strncpy(coutfile, _fcdtocp(outfile), flen2);
    coutfile[flen2] = '\0';
#else
    cinfile = ( char *) malloc(flen1+1);
    strncpy(cinfile, infile, flen1);
    cinfile[flen1] = '\0';
    coutfile = ( char *) malloc(flen2+1);
    strncpy(coutfile, outfile, flen2);
    coutfile[flen2] = '\0';
#endif

    /* strip trailing blanks */

    p = cinfile+flen1-1;
    while(*p == ' ')
    {
       *p = '\0';
       p--;
    }
    p = coutfile+flen2-1;
    while(*p == ' ')
    {
       *p = '\0';
       p--;
    }

    return ((INTEGER) rename(cinfile,coutfile));    /* move input file to output file */
}

INTEGER idel( fpchar file, long flen)
{
    char *p, *cfile;

    /* convert Fortran characters to c chars */

#ifdef _CRAY
    flen = _fcdlen(file);
    cfile = ( char *) malloc(flen+1);
    strncpy(cfile, _fcdtocp(file), flen);
    cfile[flen] = '\0';
#else
    cfile = ( char *) malloc(flen+1);
    strncpy(cfile, file, flen);
    cfile[flen] = '\0';
#endif

    /* strip trailing blanks */

    p = cfile+flen-1;
    while(*p == ' ')
    {
       *p = '\0';
       p--;
    }

    return ((INTEGER) remove(cfile));    /* delete file */
}

INTEGER isyscom( fpchar command, long len)
{
    char *ccommand;

    /* convert Fortran characters to c chars */

#ifdef _CRAY
    len = _fcdlen(command);
    ccommand = ( char *) malloc(len+1);
    strncpy(ccommand, _fcdtocp(command), len);
    ccommand[len] = '\0';
#else
    ccommand = ( char *) malloc(len+1);
    strncpy(ccommand, command, len);
    ccommand[len] = '\0';
#endif

    return ((INTEGER) system(ccommand));    /* run system command */
}

void pabort( void )
{
    abort();
}
