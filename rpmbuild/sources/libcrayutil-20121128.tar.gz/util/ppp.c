#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main (int argc, char *argv[])
{
  float f[4];
  unsigned long ladd;
  char cadd[19];

  printf("f = %p \n",f);
  printf("f+1 = %p \n",f+1);
  printf("f+2 = %p \n",f+2);
  printf("f+3 = %p \n",f+3);

  sprintf(cadd, "%p", f);
  ladd = strtoul(cadd, (char **) NULL, 16);
  printf("ladd = %ld %lu 0x%8.8x 8*(ladd/8) = %ld %lu 0x%8.8x \n",
          ladd,ladd,ladd,8*(ladd/8),8*(ladd/8),8*(ladd/8));

  sprintf(cadd, "%p", f+1);
  ladd = strtoul(cadd, (char **) NULL, 16);
  printf("ladd = %ld %lu 0x%8.8x 8*(ladd/8) = %ld %lu 0x%8.8x \n",
          ladd,ladd,ladd,8*(ladd/8),8*(ladd/8),8*(ladd/8));

  return EXIT_SUCCESS;
}

