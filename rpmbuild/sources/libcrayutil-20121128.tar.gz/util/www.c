#include <stdio.h>

int main ()
{
  short int a;
  int b;
  long int c;
  long long int d;
  char e;
  float f;
  double g;
  long double h;

  printf("Size of char is %ld %ld bytes \n",sizeof(e),sizeof(&e));
  printf("Size of short int is %ld %ld bytes \n",sizeof(a),sizeof(&a));
  printf("Size of int is %ld %ld bytes \n",sizeof(b),sizeof(&b));
  printf("Size of long int is %ld %ld bytes \n",sizeof(c),sizeof(&c));
  printf("Size of long long int is %ld %ld bytes \n",sizeof(d),sizeof(&d));
  printf("Size of float is %ld %ld bytes \n",sizeof(f),sizeof(&f));
  printf("Size of double is %ld %ld bytes \n",sizeof(g),sizeof(&g));
  printf("Size of long double is %ld %ld bytes \n",sizeof(h),sizeof(&h));

  return 0;
}
