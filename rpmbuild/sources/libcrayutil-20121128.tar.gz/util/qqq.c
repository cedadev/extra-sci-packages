#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main (int argc, char *argv[])
{
  float rbuf[4];
  double d1, d2, d3;
  double *r64;

  int ibuf[4];
  long long e1, e2, e3;
  long long *i64;

  d1=90.0;
  d2=180.0;

  memcpy(rbuf,&d1,8);
  memcpy(rbuf+2,&d2,8);

  printf("rbuf = %p \n",rbuf);
  printf("rbuf+1 = %p \n",rbuf+1);
  printf("rbuf+2 = %p \n",rbuf+2);
  printf("rbuf+3 = %p \n",rbuf+3);
  printf("rbuf[0] = %f 0x%8.8x \n",rbuf[0],*((int *) rbuf));
  printf("rbuf[0] = %f 0x%8.8x \n",rbuf[1],*((int *) (rbuf+1)));
  printf("rbuf[0] = %f 0x%8.8x \n",rbuf[2],*((int *) (rbuf+2)));
  printf("rbuf[0] = %f 0x%8.8x \n",rbuf[3],*((int *) (rbuf+3)));

  r64 = (double *) rbuf;
  printf("r64 = %p \n",r64);
#ifdef __alpha
  printf("*r64 = %f 0x%16.16lx\n",*r64,*((long *)r64));
#else
  printf("*r64 = %f 0x%16.16llx\n",*r64,*((long long *)r64));
#endif
  d3 = *r64;
  printf("d3 = %f \n",d3);

  r64 = (double *) (rbuf+1);
  printf("r64 = %p \n",r64);
#ifdef __alpha
  printf("*r64 = %f 0x%16.16lx\n",*r64,*((long *)r64));
#else
  printf("*r64 = %f 0x%16.16llx\n",*r64,*((long long *)r64));
#endif
  d3 = *r64;
  printf("d3 = %f \n",d3);

  r64 = (double *) (rbuf+2);
  printf("r64 = %p \n",r64);
#ifdef __alpha
  printf("*r64 = %f 0x%16.16lx\n",*r64,*((long *)r64));
#else
  printf("*r64 = %f 0x%16.16llx\n",*r64,*((long long *)r64));
#endif
  d3 = *r64;
  printf("d3 = %f \n",d3);

  e1=7;
  e2=576;

  memcpy(ibuf,&e1,8);
  memcpy(ibuf+2,&e2,8);

  printf("ibuf = %p \n",ibuf);
  printf("ibuf+1 = %p \n",ibuf+1);
  printf("ibuf+2 = %p \n",ibuf+2);
  printf("ibuf+3 = %p \n",ibuf+3);
  printf("ibuf[0] = %d 0x%8.8x \n",ibuf[0],ibuf[0]);
  printf("ibuf[1] = %d 0x%8.8x \n",ibuf[1],ibuf[1]);
  printf("ibuf[2] = %d 0x%8.8x \n",ibuf[2],ibuf[2]);
  printf("ibuf[3] = %d 0x%8.8x \n",ibuf[3],ibuf[3]);

#ifdef __alpha
  i64 = (long *) ibuf;
  printf("i64 = %p \n",i64);
  printf("*i64 = %ld 0x%16.16lx\n",*i64,*i64);
  e3 = *i64;
  printf("e3 = %ld \n",e3);

  i64 = (long *) (ibuf+1);
  printf("i64 = %p \n",i64);
  printf("*i64 = %ld 0x%16.16lx\n",*i64,*i64);
  e3 = *i64;
  printf("e3 = %ld \n",e3);

  i64 = (long *) (ibuf+2);
  printf("i64 = %p \n",i64);
  printf("*i64 = %ld 0x%16.16lx\n",*i64,*i64);
  e3 = *i64;
  printf("e3 = %ld \n",e3);
#else
  i64 = (long long *) ibuf;
  printf("i64 = %p \n",i64);
  printf("*i64 = %lld 0x%16.16llx\n",*i64,*i64);
  e3 = *i64;
  printf("e3 = %lld \n",e3);

  i64 = (long long *) (ibuf+1);
  printf("i64 = %p \n",i64);
  printf("*i64 = %lld 0x%16.16llx\n",*i64,*i64);
  e3 = *i64;
  printf("e3 = %lld \n",e3);

  i64 = (long long *) (ibuf+2);
  printf("i64 = %p \n",i64);
  printf("*i64 = %lld 0x%16.16llx\n",*i64,*i64);
  e3 = *i64;
  printf("e3 = %lld \n",e3);
#endif

  return EXIT_SUCCESS;
}

