#include <string.h>

void bcopy(const void *s1, void *s2, size_t n)
{
   memmove(s2, s1, n);
}

int bcmp(const void *s1, void *s2, size_t n)
{
   if (memcmp(s1, s2, n) == 0)
      return 0;
   else
      return 1;
}

void bzero(void *s, size_t n)
{
   memset(s, 0, n);
}

