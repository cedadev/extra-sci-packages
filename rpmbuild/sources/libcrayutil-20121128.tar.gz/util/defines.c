#include <stdio.h>

int main ()
{
#ifdef unix
   printf("unix is defined\n");
#endif
#ifdef __unix
   printf("__unix is defined\n");
#endif
#ifdef linux
   printf("linux is defined\n");
#endif
#ifdef LINUX
   printf("LINUX is defined\n");
#endif
#ifdef __linux
   printf("__linux is defined\n");
#endif
#ifdef sun
   printf("sun is defined\n");
#endif
#ifdef __sun
   printf("__sun is defined\n");
#endif
#ifdef sgi
   printf("sgi is defined\n");
#endif
#ifdef __sgi
   printf("__sgi is defined\n");
#endif
#ifdef mips
   printf("mips is defined\n");
#endif
#ifdef __mips
   printf("__mips is defined\n");
#endif
#ifdef __ICC
   printf("__ICC is defined\n");
#endif
#ifdef __ECC
   printf("__ECC is defined\n");
#endif
#ifdef ia64
   printf("ia64 is defined\n"); /* Altix ecc */
#endif
#ifdef __ia64__
   printf("__ia64__ is defined\n"); /* Altix gcc/ecc */
#endif
#ifdef __x86_64__
   printf("__x86_64__ is defined\n");
#endif
#ifdef __x86_64
   printf("__x86_64 is defined\n");
#endif
#ifdef amd64
   printf("amd64 is defined\n");
#endif
#ifdef __amd64
   printf("__amd64 is defined\n");
#endif
#ifdef __amd64__
   printf("__amd64__ is defined\n");
#endif
#ifdef  _M_IA64
   printf(" _M_IA64 is defined\n"); /* Altix ecc 7.1 not 8.0 */
#endif
#ifdef __i386
   printf("__i386 is defined\n");
#endif
#ifdef __i386__
   printf("__i386__ is defined\n");
#endif
#ifdef i386
   printf("i386 is defined\n");
#endif
#ifdef ia32
   printf("ia32 is defined\n");
#endif
#ifdef __ia32__
   printf("__ia32__ is defined\n");
#endif
#ifdef __x86_32__
   printf("__x86_32__ is defined\n");
#endif
#ifdef  _M_IA32
   printf(" _M_IA32 is defined\n");
#endif
#ifdef CRAY
   printf("CRAY is defined\n");
#endif
#ifdef cray
   printf("cray is defined\n");
#endif
#ifdef _CRAY
   printf("_CRAY is defined\n");
#endif
#ifdef _CRAYMPP
   printf("_CRAYMPP is defined\n");
#endif
#ifdef CRAYX1
   printf("CRAYX1 is defined\n");
#endif
#ifdef CRAYX2
   printf("CRAYX2 is defined\n");
#endif
#ifdef __crayx1
   printf("__crayx1 is defined\n");
#endif
#ifdef __crayx2
   printf("__crayx2 is defined\n");
#endif
#ifdef CRAYXD1
   printf("CRAYXD1 is defined\n");
#endif
#ifdef CRAYXT3
   printf("CRAYXT3 is defined\n");
#endif
#ifdef CRAYXT4
   printf("CRAYXT4 is defined\n");
#endif
#ifdef __alpha
   printf("__alpha is defined\n");
#endif
#ifdef _MIPS_SZLONG
   printf("_MIPS_SZLONG = %d is defined\n",_MIPS_SZLONG); /* SGI -n32,-o32 =32 -64 =64 */
#endif
#ifdef  __64BIT__
   printf("__64BIT__ is defined\n"); /* IBM cc_r -q64 */
#endif
#ifdef  __arch64__
   printf("__arch64__ is defined\n");
#endif
#ifdef  __LP64__
   printf("__LP64__ is defined\n"); /* Altix gcc/ecc */
#endif
#ifdef  _LP64
   printf("_LP64 is defined\n"); /* Sun cc -xarch=v9, Altix ecc, IBM cc_r -q64 */
#endif
#ifdef  __LP32__
   printf("__LP32__ is defined\n");
#endif
#ifdef  _LP32
   printf("_LP32 is defined\n");
#endif
#ifdef  __sparcv9
   printf("__sparcv9 is defined\n"); /* Sun cc -xarch=v9 */
#endif
#ifdef  __GNUC__
   printf("__GNUC__ is defined %d\n",__GNUC__);
#endif
#ifdef  __WORDSIZE
   printf("__WORDSIZE is defined %d\n",__WORDSIZE);
#endif
#ifdef  __i486__
   printf("__i486__ is defined\n");
#endif
#ifdef  __pentium__
   printf("__pentium__ is defined\n");
#endif
#ifdef  __pentiumpro__
   printf("__pentiumpro__ is defined\n");
#endif
#ifdef  __pentium4__
   printf("__pentium4__ is defined\n");
#endif
#ifdef  __k8__
   printf("__k8__ is defined\n");
#endif
#ifdef  __k6__
   printf("__k6__ is defined\n");
#endif
#ifdef  __athlon__
   printf("__athlon__ is defined\n");
#endif
#ifdef  ppc
   printf("ppc is defined\n");
#endif
#ifdef  __ppc__
   printf("__ppc__ is defined\n");
#endif
#ifdef  __ppc64__
   printf("__ppc64__ is defined\n");
#endif
#ifdef  ppc64
   printf("ppc64 is defined\n");
#endif
#ifdef  __BIG_ENDIAN__
   printf("__BIG_ENDIAN__ is defined\n");
#endif
#ifdef  __LITTLE_ENDIAN__
   printf("__LITTLE_ENDIAN__ is defined\n");
#endif
#ifdef  APPLE
   printf("APPLE is defined\n");
#endif
#ifdef  __APPLE__
   printf("__APPLE__ is defined\n");
#endif
#ifdef  MACH
   printf("MACH is defined\n");
#endif
#ifdef  __MACH__
   printf("__MACH__ is defined\n");
#endif

  return 0;
}
